/////////////////////////////////////////////////////////////////////////////////////////////////////////

#define LX  0.0      // Total X length in m 
#define LY  0.0      // Total Y length in m 
#define LZ  0.0      // Total Z length in m 
#define OX  0.0      // Origin X in m 
#define OY  0.0      // Origin Y in m 
#define OZ  0.0      // Origin Z in m Top Down (sea ->0)

/////////////////////////////////////////////////////////////////////////////////////////////////////////
#define Width	72   // width of the abs

#define Nx1   (7)
#define Ny1   (800 + 2*Width)
#define Nz1   (400 + 2*Width)

/////////////////////////////////////////////////////////////////////////////////////////////////////////

#define dx        (12.5)     // Spatial Increment 
#define dz        (12.5)     // Spatial Increment
#define dt        (0.002)    // Temporal Increment 
#define Duration  (6.0)    //  Run Time

/////////////////////////////////////////////////////////////////////////////////////////////////////////

#define vdrop 		0.75                      // vdrop decreases velocity on edge 1 is  off
#define randvalue	0.20                      // deivation +/- of max_vel in random boundaries 0 is off
#define lambda		(1.0/16.0/Width/Width) // lambda function is just rule of thumb, set to 0 for no bc
#define sscale          (1e+2)                    // scale source by this amount

/////////////////////////////////////////////////////////////////////////////////////////////////////////

#define input1  "../Model/VP.bin"     // Input v-p file
#define input2  "../Model/DEN.bin"    // Input density file
#define input6  "../Model/dricker20Hz"    // source time function
#define input7  "../Model/source"    // source locations
#define input8  "../Model/streamer"    // station loactions

/////////////////////////////////////////////////////////////////////////////////////////////////////////

#define output1              "station"   // source time function
#define output2              "volume"   // source time function
#define no_snaps             1.0     // take snapshot every no_snaps seconds
#define LR                   2       // downgrade image resolution  by factor

/////////////////////////////////////////////////////////////////////////////////////////////////////////
