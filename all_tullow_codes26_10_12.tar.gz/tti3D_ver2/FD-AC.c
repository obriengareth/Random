//  Gareth O'Brien 20/7/2012
// -- Include intrinsic C calls --
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<time.h>
#include"mpi.h"
#include"PARAMETERS.h"
#include"DEFS.h"

//  MAIN CONTROL LOOP
main(int argc ,char *argv[])
{
 int i,j,k;
 double start,finish;
 double startA,finishA;
 char command[50];

// Starting MPI calls and redefining new communicator
  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);

// command line arguements
  if( argc != 1 )
  {
    printf("INCORRECT USAGE - exe par_file\n");
    MPI_Finalize();  exit(1);
  }

// sorting out mpi domain 
  dims[0]    = size;
  periods[0] = 1;
  reorder    = 1;

  MPI_Cart_create(MPI_COMM_WORLD, ndims, dims, periods, reorder, &new_comm);  
  MPI_Comm_rank(new_comm, &my_rank);
  MPI_Comm_size(new_comm, &my_size);
  startA=MPI_Wtime();

  create_mpi_data_type();

  Max_Time=ceil(Duration/dt);

  if(my_rank==0)
  {
    printf("--------------------------------------------------------\n");
    printf("Acoustic multi-shot code \n");
    printf("--------------------------------------------------------\n");
  }

// building the inputting the model
  build6();

// Initialising the sources
  source_routine();

// building absorbing and random boundaries
  absorb_fn();

  //NumSource=12;
  if(my_rank==0)
  {  
   for(shot_no=0; shot_no<NumSource; shot_no++)
   {
     printf("  making directory Shot%d \n",shot_no);
     sprintf(command,"mkdir Shot%d",shot_no);
     system(command);
   }
  }

// outputting the velocity model for QC
  output_velmodel();

// writing out some initial parameters
  if(my_rank==0)
  {
    printf("--------------------------------------------------------\n");
    printf("Spatial Sampling\n");
    printf("Nx = %d; NxT = %d; Ny = %d; Nz = %d;\n",Nx,my_size*Nx,Ny,Nz);
    printf("Nxx = %d; NxxT = %d; Nyy = %d; Nzz = %d;\n",Nxx,Nxx*my_size,Nyy,Nzz);
    printf("lrX=%d; lrX=%d; lrY=%d; lrZ=%d; lr=%d;\n",lr_countx,lr_countx*my_size,lr_county,lr_countz,lr_count);
    printf("Free surface at %d\n",Nz-Width);

    printf("Number of MPI processes %d\n",my_size);
    printf("Number of Time Steps %d\n",Max_Time);
    printf("Number of cores %d\n",my_size);
    printf("Number of Volume Snaps %d\n",no_snap);
    printf("--------------------------------------------------------\n");
    printf("------------------------------------------\n");
    printf("--------------ERROR CHECKS----------------\n");
    printf("------------------------------------------\n");

    printf("CFL Stability Max Vel=%lf\n",max_vel);
    printf("CFL Stability dt < 0.4 dx/max_vel\n");
    printf("CFL Stability %lf < %lf\n",dt,dx/max_vel*0.4);

    printf("REQUIRE 5 grid points per minimum wavelength for near field propagation\n");
    printf("--------------------------------------------------------\n");

  }

/////////////////////////////////////////////////////////////////////////////////////////////////
// holding all until ready for main iteration loop
 MPI_Barrier(new_comm);
 double alpha1=4.5*dx;

 for(shot_no=74; shot_no<NumSource; shot_no++)
 {
  start=MPI_Wtime();

  if(my_rank==0)
  printf("\n ... shooting shot number %d \n",shot_no);

// building absorbing and random boundaries
  absorb_fn();

// Sorting out the output trace files and locations
  trace_files();

// zeroing stress, velocity and source for new shot
// double loop cause bug - wont zero unless its there?
  for(i=0; i<Nx; i++)
  {
  for(j=0; j<Ny; j++)
  {
  for(k=0; k<Nz; k++)
  {
   stress[i][j][k][0] = 0.0 ;
   stress[i][j][k][1] = 0.0 ;
   u[i][j][k][0] = 0.0 ;
   u[i][j][k][1] = 0.0 ;
   u[i][j][k][2] = 0.0 ;

   gauss[i][j][k]=dens[i][j][k]*Gauss( dx*(xsource[shot_no]-i-Nx*my_rank),dx*(ysource[shot_no]-j),dz*(zsource[shot_no]-k),alpha1);
  }
  }
  }
  for(i=0; i<Nxx; i++)
  {
  for(j=0; j<Nyy; j++)
  {
  for(k=0; k<Nzz; k++)
  {
   stress[i][j][k][0] = 0.0 ;
   stress[i][j][k][1] = 0.0 ;
   u[i][j][k][0] = 0.0 ;
   u[i][j][k][1] = 0.0 ;
   u[i][j][k][2] = 0.0 ;
  }
  }
  }
  MPI_Barrier(new_comm);


// Main evolution of the system
  count_snaps=0;
  for(time1=0; time1<=Max_Time; time1++)
  {
   // sending halo regions
   transfer_stress();

   // stress diff
   update_velocity();

   // sending halo regions
   transfer_vel();

   // vel diff
   update_stress();

   // Output snapshots
/*   if( (dt*(count_snaps+1)*Max_Time/no_snap-0.5*dt) < dt*time1 && dt*time1 < dt*(count_snaps+1)*Max_Time/no_snap +0.5*dt )
   {
    wavefield();

    if(my_rank==0)
    printf("\t taking snaphot %d of %d at %lf\n",count_snaps,no_snap,time1*dt);

    count_snaps=count_snaps+1;
   }*/

   if(my_rank==0 && time1%500==0)
   printf("\t 3D TTI Code: Time step=%lf\n",time1*dt);

// Output trace files
   
   write_trace();

  }
// leaving time loop
////////////////////////////////////////////////////////////////////////////

 close_trace();

 MPI_Barrier(new_comm);
 if(count_snaps>0 && my_rank==0)
 {
  //merge_wavefield();
 }
 MPI_Barrier(new_comm);

 finish=MPI_Wtime();
 //if(my_rank==0)
 //printf(" Time for shot %d is %lf minutes \n",shot_no,(finish-start)/60);

 if(my_rank==0)
 printf(" finished shot %d on node %d in %lf minutes\n",shot_no,my_rank,(finish-start)/60);

 } // finishing shot no

 finishA=MPI_Wtime();
 if(my_rank==0)
 printf(" Time for run on node %d is %lf minutes \n",my_rank,(finishA-startA)/60);

 //if(my_rank==0)
 //convert_traces_su();

 MPI_Finalize();

}          // End of main


