
// Outputs snap shots of the wavefield ever snap_freq time steps
void wavefield()
{
 int i,j,k;
 char file_name[50];
 FILE *output;

 sprintf(file_name,"Shot%d/TEMP%d_%d",shot_no,count_snaps,my_rank);
 if(( output= fopen(file_name,"w")) ==NULL )
 {
   printf("Error 301 opening snap file on node %d at time %d\n",my_rank,time1);
   MPI_Finalize();
   exit(0);
 }

 for(i=order; i<Nx+order; i=i+LR)
 {
 for(j=order; j<Ny+order; j=j+LR)
 { 
 for(k=order; k<Nz+order; k=k+LR)
 {
   fprintf(output,"%e %e %e %e\n",u[i][j][k][0],u[i][j][k][1],u[i][j][k][2],(stress[i][j][k][0]+stress[i][j][k][1]) );
   //fprintf(output,"%e %e %e %e\n",1.0*ranf(),2.0*ranf(),3.0*ranf(),4.0*ranf() );
   //fprintf(output,"%e %e %e %e\n",R[i][j][k][0],R[i][j][k][1],R[i][j][k][2],(velp[i-order][j-order][k-order]) );
 }
 }
 }
 fclose(output);

}

// merging temp files from individual nodes
void merge_wavefield()
{
 int i,j,n,l;
 double a,b,c,d,aa[4];
 char file_name[50];
 FILE *output,*input[my_size];

for(n=0; n<no_snap; n++)
{
    sprintf(file_name,"Shot%d/%s%d",shot_no,output2,n);
    if(( output = fopen(file_name,"w")) ==NULL )
    {
       printf("Error 4004 opening snap file on node %d at time %d\n",my_rank,time1);
       MPI_Finalize();
       exit(0);
    }
    for(j=0; j<my_size; j++)
    {
        sprintf(file_name,"Shot%d/TEMP%d_%d",shot_no,n,j);
	if(( input[j] = fopen(file_name,"r")) ==NULL )
        {
          printf("Error 3456 merging file %s on node %d\n",file_name,j);
          MPI_Finalize();
          exit(0);
        }

      for(i=0;i<lr_count; i++)
      {
        fscanf(input[j],"%lf %lf %lf %lf\n",&a,&b,&c,&d);
	aa[0]=a; aa[1]=b;  aa[2]=c; aa[3]=d;
        fwrite(&aa, sizeof(double), 4, output);
      }

    }

    for(i=0; i<my_size; i++)
    {
      sprintf(file_name,"Shot%d/TEMP%d_%d",shot_no,n,i);
      remove(file_name);
    }
    fclose(output);
}

}    // end of routine


////////////////////////////////////////////////////////////////////////////////////////////////////
// Output Velocity Model
void output_velmodel()
{
   int i,j,k,n,l;
   double a,b,c,aa[1],dd;
   char file_name[50];
   FILE *output,*input[my_size];

 if(my_rank==0)
 printf("Writing out velocity model used for RTM\n");

// writing out vel on individual codes
 sprintf(file_name,"TEMP_VEL_%d",my_rank);
 if(( output= fopen(file_name,"w")) ==NULL )
 {
   printf("Error 1235 opening snap file on node %d at time %d\n",my_rank,time1);
   MPI_Finalize();
   exit(0);
 }

 for(i=0; i<Nx; i=i++)
 {
 for(j=0; j<Ny; j=j++)
 {
 for(k=0; k<Nz; k=k++)
 {
     fprintf(output,"%e \n",velp[i][j][k]);

     //fprintf(output,"%e\n",gauss[i][j][k]);
     //fprintf(output,"%e \n",dr44dy[i][j][k] );
     //fprintf(output,"%e \n",R[i+order][j+order][k+order][4]);
     //fprintf(output,"%e \n",dxx[i]*dyy[j]*dzz[k]);
     //fprintf(output,"%e\n",dens[i][j][k]);

 }
 }
 }
 fclose(output);

 MPI_Barrier(new_comm);

 // combining all core outs into single file
 if(my_rank==0)
 {
    sprintf(file_name,"INOUT_VP");
    if(( output = fopen(file_name,"w")) ==NULL )
    {
       printf("Error 1234 opening snap file on node %d\n",my_rank);
       MPI_Finalize();
       exit(0);
    }
    for(j=0; j<my_size; j++)
    {

      sprintf(file_name,"TEMP_VEL_%d",j);
      if(( input[j] = fopen(file_name,"r")) ==NULL )
      {
          printf("Error 1212 merging file %s on node %d\n",file_name,j);
          MPI_Finalize();
          exit(0);
      }

      for(i=0;i<Nx*Ny*Nz; i++)
      {
        fscanf(input[j],"%lf \n",&a);
	aa[0]=a; //aa[1]=b;  aa[2]=c;
        fwrite(&aa, sizeof(double), 1, output);
      }

    }

    for(i=0; i<my_size; i++)
    {
      sprintf(file_name,"TEMP_VEL_%d",i);
      remove(file_name);
    }
    fclose(output);
  }

}

////////////////////////////////////////////////////////////////////////////////////////////////////

