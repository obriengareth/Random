/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
/*
void read_par_file(char *argv[])
{
  int c,count,i;
  double readin[30];
  char string[50],value;
  char file_name[50];
  FILE *input,*tempout;

  sprintf(string,"%s",argv[1]);
  if(( input= fopen(string,"r")) ==NULL )
  {
    printf("Error opening par file on node %d\n",my_rank);
    MPI_Finalize();
    exit(0);
  }

  sprintf(file_name,"TEMP_PAR%d",my_rank);
  if(( tempout= fopen(file_name,"w")) ==NULL )
  {
    printf("Error opening TEMP_FILE file on node %d\n",my_rank);
    MPI_Finalize();
    exit(0);
  }
  count=0;
  while(( c=getc(input))!=EOF)
  {
     value=c;
     if(count==1)
     {
      fprintf(tempout,"%c",value);
      if(value==' ')
      {
        fprintf(tempout,"\n");
     }
     }
     if(value=='=')
     {
       count=1;
     }
     if(value==' ')
     {
       count=0;
     }
  }
  fclose(input);
  fclose(tempout);

  sprintf(file_name,"TEMP_PAR%d",my_rank);
  if(( input= fopen(file_name,"r")) ==NULL )
  {
     printf("Error opening file on node %d\n",my_rank);
     MPI_Finalize();
     exit(0);
  }

  fscanf(input,"%d\n",&model_option);

  fscanf(input,"%lf\n",&LX);
  fscanf(input,"%lf\n",&LY);
  fscanf(input,"%lf\n",&LZ);

  fscanf(input,"%lf\n",&OX);
  fscanf(input,"%lf\n",&OY);
  fscanf(input,"%lf\n",&OZ);

  fscanf(input,"%lf\n",&dx);
  fscanf(input,"%lf\n",&dz);
  fscanf(input,"%lf\n",&dt);
  fscanf(input,"%lf\n",&Duration);

  fscanf(input,"%s\n",&input1);
  fscanf(input,"%s\n",&input2);
  fscanf(input,"%s\n",&input3);
  fscanf(input,"%s\n",&input4);
  fscanf(input,"%s\n",&input5);


  fclose(input);

  remove(file_name);


if(my_rank==0)
{
  printf("------------------------------------\n");
  printf("-- model_option \t=%d\n",model_option);

  printf("-- Lx \t\t=%lf\n",LX);
  printf("-- Ly \t\t=%lf\n",LY);
  printf("-- Lz \t\t=%lf\n",LZ);

  printf("-- Ox \t\t=%lf\n",OX);
  printf("-- Oy \t\t=%lf\n",OY);
  printf("-- Oz \t\t=%lf\n",OZ);

  printf("-- dx \t\t=%lf\n",dx);
  printf("-- dz \t\t=%lf\n",dz);
  printf("-- dt \t\t=%lf\n",dt);
  printf("-- Max_Time \t=%lf\n",Duration);

  printf("input1 \t\t=%s\n",input1);
  printf("input2 \t\t=%s\n",input2);
  printf("input3 \t\t=%s\n",input3);
  printf("input4 \t\t=%s\n",input4);
  printf("input5 \t\t=%s\n",input5);

  printf("------------------------------------\n");

}


}*/


/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
int *alloc1d_int(int n1)
{
 int *dummy;

 dummy=(int *) calloc(n1,sizeof(int ));
 if (dummy==NULL)
 {
    printf(" Could not allocate memory 1 1d int\n");MPI_Finalize();
    exit(1);
 }
  return dummy;

}

void free_array1d_int(int *a)
{
 free(a);
}


double ****alloc4d(int n1,int n2,int n3,int n4)
{
  int i,j,k;
  double ****dummy;

 dummy=(double ****) calloc(n1,sizeof(double ***));
 if (dummy==NULL)
 {
    printf(" Could not allocate memory 1 4d\n");
    exit(1);
 }
 for(i=0; i<n1; i++)
 {
    dummy[i]=(double ***) calloc(n2,sizeof(double **));
    if (dummy[i]==NULL)
    {
      printf(" Could not allocate memory 2 4d \n");
      exit(1);
    }
  for(j=0; j<n2; j++)
  {
     dummy[i][j]=(double **) calloc(n3,sizeof(double *));
     if (dummy[i][j]==NULL)
     {
      printf(" Could not allocate memory 3 4d\n");
      exit(1);
     }
   for(k=0; k<n3; k++)
   {
     dummy[i][j][k]=(double *) calloc(n4,sizeof(double ));
     if (dummy[i][j][k]==NULL)
     {
       printf(" Could not allocate memory 4 4d\n");
       exit(1);
     }
   } //k
  }  //j
 }   //i 


/* dummy=(double ****) malloc(n1*sizeof(*dummy));
 if (dummy==NULL)
 {
    printf(" Could not allocate memory 1 4d\n");
    exit(1);
 }
 for(i=0; i<n1; i++)
 {
    dummy[i]=(double ***) malloc(n2*sizeof(*dummy));
    if (dummy[i]==NULL)
    {
      printf(" Could not allocate memory 2 4d \n");
      exit(1);
    }
  for(j=0; j<n2; j++)
  {
     dummy[i][j]=(double **) malloc(n3*sizeof(*dummy));
     if (dummy[i][j]==NULL)
     {
      printf(" Could not allocate memory 3 4d\n");
      exit(1);
     }
   for(k=0; k<n3; k++)
   {
     dummy[i][j][k]=(double *) malloc(n4*sizeof(*dummy));
     if (dummy[i][j][k]==NULL)
     {
       printf(" Could not allocate memory 4 4d\n");
       exit(1);
     }
   } //k
  }  //j
 }   //i
*/

   return dummy;
}  //end function

/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////

double *alloc1d(int n1)
{
 double *dummy;

 dummy=(double *) calloc(n1,sizeof(double ));
 if (dummy==NULL)
 {
    printf(" Could not allocate memory v_1d \n");MPI_Finalize();
    exit(1);
 }
  return dummy;

}

/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////

double ***alloc3d(int n1,int n2,int n3)
{
  int i,j;
  double ***dummy;

 dummy=(double ***) calloc(n1,sizeof(double **));
 if (dummy==NULL)
 {
    printf(" Could not allocate memory 1 3d\n");
    exit(1);
 }
 for(i=0; i<n1; i++)
 {
   dummy[i]=(double **) calloc(n2,sizeof(double *));
   if (dummy[i]==NULL)
   {
      printf(" Could not allocate memory 2 3d\n");
      exit(1);
   }
   for(j=0; j<n2; j++)
   {
    dummy[i][j]=(double *) calloc(n3,sizeof(double ));
    if (dummy[i][j]==NULL)
    {
      printf(" Could not allocate memory 3 3d\n");
      exit(1);
    }
   }
}

  return dummy;

}

void free_array3d(double ***a)
{
 int i,j;
 for(i=0; i<Nx; i++)
 {
   for(j=0; j<Nz; j++)
    free(a[i][j]);
    free(a[i]);
 }
 free(a);

}

/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
// Locates the node given the coordinate
int locate_node(int coord)
{
 int i,node;

 for(i=0; i<my_size; i++)
 {
   if( coord < ((Nx)*i+Nx) && coord >= (Nx*i) )
   {
     node=i;
   }
 }
 return node;

}

/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////

double ranf()
{
const int ia=16807,ic=2147483647,iq=127773,ir=2836;
int il,ih,it;
double rc;
int t1,t2,t3,t4,t5,t6;
time_t ts,tp;
struct tm t;
int iseed;

/* Initial seed from the system time and and forced to be odd */

ts = time(&tp);
t  = *gmtime(&tp);
t1 = t.tm_sec+2*my_rank;
t2 = t.tm_min+3*my_rank;
t3 = t.tm_hour;
t4 = t.tm_mday;
t5 = t.tm_mon;
t6 = t.tm_year;
iseed = t6+70*(t5+2*my_rank+12*(t4+31*(t3+23*(t2+59*t1))));
iseed=iseed*drand48();
ih = iseed/iq;
il = iseed%iq;
it = ia*il-ir*ih;
if (it > 0)
  {
  iseed = it;
  }
else
  {
iseed = ic+it;
  }
rc = ic;
return iseed/rc;
}

/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
