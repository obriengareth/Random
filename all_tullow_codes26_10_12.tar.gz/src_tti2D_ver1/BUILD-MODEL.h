/////////////////////////////////////////////////////////////


/// loading in four model files
void build(double theta[Nx+2][Nzz])
{
  int i,ii,j,n;
  float aa;
  char file_name[50];
  FILE *input;


/// Opening and writing in model VP

 max_vel=0.0;
 sprintf(file_name,"%s",input1);
 if(( input = fopen(file_name,"r"))==NULL )
 {
     printf("No VP FILE on node %d: Defaulting to homogenous VP=%lf\n",my_rank,vp);
     max_vel=vp;
 }
 else if(( input = fopen(file_name,"r"))!=NULL )
 {
   for(i=0; i<Nx*my_size; i++)
   {
   for(j=order; j<Nz+order; j++)
   {
      fread(&aa, sizeof(float), 1, input);
      //printf("%d %d %d %f\n",my_rank,i,j,aa);

      if(max_vel<aa)
      max_vel=aa;

      if(locate_node(i)==my_rank )
      {
        ii=i%Nx;
        velp[ii][j]=aa;
      }
   }
   }
   for(i=0; i<Nx; i++)
   {
   for(j=0; j<order; j++)
   {
     velp[i][j]=velp[i][order];
   }
   }
   for(i=0; i<Nx; i++)
   {
   for(j=Nz+order; j<Nzz; j++)
   {
     velp[i][j]=velp[i][Nz+order-1];
   }
   }
   fclose(input); 
 }
/// closing VP input

/// Opening and writing in model density
 sprintf(file_name,"%s",input2);
 if(( input = fopen(file_name,"r"))==NULL )
 {
     printf("No DENSITY FILE on node %d: Defaulting to homogenous density=%lf\n",my_rank,rho);
 }
 else if(( input = fopen(file_name,"r"))!=NULL )
 {
   for(i=0; i<Nx*my_size; i++)
   {
   for(j=order; j<Nz+order; j++)
   {
      fread(&aa, sizeof(float), 1, input);

      if(locate_node(i)==my_rank )
      {
        ii=i%Nx;
        densL[ii][j]=aa;
      }
   }
   }
   for(i=0; i<Nx; i++)
   {
   for(j=0; j<order; j++)
   {
     densL[i][j]=densL[i][order];
   }
   }
   for(i=0; i<Nx; i++)
   {
   for(j=Nz+order; j<Nzz; j++)
   {
     densL[i][j]=densL[i][Nz+order-1];
   }
   }
   fclose(input); 
 }
/// closing dens input

/// Opening and writing in model eps
 sprintf(file_name,"%s",input3);
 if(( input = fopen(file_name,"r"))==NULL )
 {
     printf("No EPS FILE on node %d: Defaulting to homogenous EPS=%lf\n",my_rank,EPS);
 }
 else if(( input = fopen(file_name,"r"))!=NULL )
 {
   for(i=0; i<Nx*my_size; i++)
   {
   for(j=order; j<Nz+order; j++)
   {
      fread(&aa, sizeof(float), 1, input);

      if(locate_node(i)==my_rank )
      {
        ii=i%Nx;
        eps[ii][j]=aa;
      }
   }
   }
   for(i=0; i<Nx; i++)
   {
   for(j=0; j<order; j++)
   {
     eps[i][j]=eps[i][order];
   }
   }
   for(i=0; i<Nx; i++)
   {
   for(j=Nz+order; j<Nzz; j++)
   {
     eps[i][j]=eps[i][Nz+order-1];
   }
   }
   fclose(input); 
 }
/// closing eps input

/// Opening and writing in model delta
 sprintf(file_name,"%s",input4);
 if(( input = fopen(file_name,"r"))==NULL )
 {
     printf("No delta FILE on node %d: Defaulting to homogenous delta=%lf\n",my_rank,DELTA);
 }
 else if(( input = fopen(file_name,"r"))!=NULL )
 {
   for(i=0; i<Nx*my_size; i++)
   {
   for(j=order; j<Nz+order; j++)
   {
      fread(&aa, sizeof(float), 1, input);

      if(locate_node(i)==my_rank )
      {
        ii=i%Nx;
        delta[ii][j]=aa;
      }
   }
   }
   for(i=0; i<Nx; i++)
   {
   for(j=0; j<order; j++)
   {
     delta[i][j]=delta[i][order];
   }
   }
   for(i=0; i<Nx; i++)
   {
   for(j=Nz+order; j<Nzz; j++)
   {
     delta[i][j]=delta[i][Nz+order-1];
   }
   }
   fclose(input); 
 }
/// closing delta input

/// Opening and writing in model theta
 sprintf(file_name,"%s",input8);
 if(( input = fopen(file_name,"r"))==NULL )
 {
     printf("No delta FILE on node %d: Defaulting to homogenous theta=%lf\n",my_rank,0.0);
 }
 else if(( input = fopen(file_name,"r"))!=NULL )
 {
   for(i=0; i<Nx*my_size; i++)
   {
   for(j=order; j<Nz+order; j++)
   {
      fread(&aa, sizeof(float), 1, input);

      if(locate_node(i)==my_rank )
      {
        ii=i%Nx;
        theta[ii+1][j]=aa;
      }
   }
   }
   for(i=0; i<Nx; i++)
   {
   for(j=0; j<order; j++)
   {
     theta[i+1][j]=theta[i+1][order];
   }
   }
   for(i=0; i<Nx; i++)
   {
   for(j=Nz+order; j<Nzz; j++)
   {
     theta[i+1][j]=theta[i+1][Nz+order-1];
   }
   }
   fclose(input); 
 }
/// closing delta input

/////////////////////////////////////////////////////////////////////
  for(i=0; i<Nx; i++)
  {
  for(j=0; j<Nzz; j++)
  {
     if(gauss[i][j]>=0.1)
     eps[i][j]=delta[i][j];
  }
  }

  for(i=0; i<Nx; i++)
  {
  for(j=Nzz-order-1; j<Nzz; j++)
  {
     velp[i][j]=0.0;
     densL[i][j]=1.0;
     eps[i][j]=0.0;
     delta[i][j]=0.0;
     gauss[i][j]=0.0;
     theta[i+1][j]=0.0;

     if(gauss[i][j]>=0.1)
     eps[i][j]=delta[i][j];
  }
  }

  densityU();

/////////////////////////////////////////////////////////////////////
// Building theta cos and sin models

  ctheta2 = alloc2d(Nx+2,Nzz);
  stheta2 = alloc2d(Nx+2,Nzz);
  cstheta = alloc2d(Nx+2,Nzz);

  dxctheta2 = alloc2d(Nx,Nzz);
  dxstheta2 = alloc2d(Nx,Nzz);
  dxcstheta = alloc2d(Nx,Nzz);
  dzctheta2 = alloc2d(Nx,Nzz);
  dzstheta2 = alloc2d(Nx,Nzz);
  dzcstheta = alloc2d(Nx,Nzz);

/*
 for(n=0; n<1; n++)
 {
  for(i=1; i<Nx+1; i++)
  {
  for(j=1; j<Nzz-1; j++)
  {
    ctheta2[i][j] = 0.2*(theta[i][j]+theta[i+1][j]+theta[i-1][j]+theta[i][j+1]+theta[i][j-1]);
  }
  }
  for(i=1; i<Nx+1; i++)
  {
    j=Nzz-1;
    ctheta2[i][j] = 0.25*(theta[i][j]+theta[i+1][j]+theta[i-1][j]+theta[i][j-1]);
  }
  for(i=1; i<Nx+1; i++)
  {
    j=0;
    ctheta2[i][j] = 0.25*(theta[i][j]+theta[i+1][j]+theta[i-1][j]+theta[i][j+1]);
  }
  for(i=0; i<Nx+2; i++)
  {
  for(j=0; j<Nzz; j++)
  {
    theta[i][j] = ctheta2[i][j];
  }
  }
 }*/

  transfer_theta(theta);

  for(i=0; i<Nx+2; i++)
  {
  for(j=0; j<Nzz; j++)
  {
    ctheta2[i][j] = cos(theta[i][j])*cos(theta[i][j]);
    stheta2[i][j] = sin(theta[i][j])*sin(theta[i][j]);
    cstheta[i][j] = cos(theta[i][j])*sin(theta[i][j]);
  }
  }

  double da=0.5/dx,c11;
  c11=da;

  for(i=1; i<Nx+1; i++)
  {
  for(j=1; j<Nzz; j++)
  {
// xx
    dxctheta2[i-1][j] =
          c11*(ctheta2[i][j-1]- ctheta2[i-1][j] + ctheta2[i][j] - ctheta2[i-1][j-1]);
    dxstheta2[i-1][j] =
          c11*(stheta2[i][j-1]- stheta2[i-1][j] + stheta2[i][j] - stheta2[i-1][j-1]);
    dxcstheta[i-1][j] =
          c11*(cstheta[i][j-1]- cstheta[i-1][j] + cstheta[i][j] - cstheta[i-1][j-1]);

// zz
    dzctheta2[i-1][j] = 
           c11*(ctheta2[i][j] - ctheta2[i-1][j-1] + ctheta2[i-1][j] - ctheta2[i][j-1]);
    dzstheta2[i-1][j] =
            c11*(stheta2[i][j] - stheta2[i-1][j-1] + stheta2[i-1][j] - stheta2[i][j-1]);
    dzcstheta[i-1][j] =
            c11*(cstheta[i][j] - cstheta[i-1][j-1] + cstheta[i-1][j] - cstheta[i][j-1]);


  }
  }
  j=0;
  for(i=1; i<Nx+1; i++)
  {

// xx
    dxctheta2[i-1][j] =(- ctheta2[i-1][j] + ctheta2[i][j] )/dx;
    dxstheta2[i-1][j] =(- stheta2[i-1][j] + stheta2[i][j] )/dx; 
    dxcstheta[i-1][j] =(- cstheta[i-1][j] + cstheta[i][j] )/dx;

// zz
    dzctheta2[i-1][j] =
           c11*(ctheta2[i][j+1] - ctheta2[i-1][j] + ctheta2[i-1][j+1] - ctheta2[i][j] );
    dzstheta2[i-1][j] =
            c11*(stheta2[i][j+1] - stheta2[i-1][j] + stheta2[i-1][j+1] - stheta2[i][j]);
    dzcstheta[i-1][j] =
            c11*(cstheta[i][j+1] - cstheta[i-1][j] + cstheta[i-1][j+1] - cstheta[i][j]);

  }

 /* for(i=0; i<Nx; i++)
  {
  for(j=0; j<Nzz; j++)
  {
// xx
    dxctheta2[i][j] =0.0;
    dxstheta2[i][j] =0.0;
    dxcstheta[i][j] =0.0;

// zz
    dzctheta2[i][j] =0.0;
    dzstheta2[i][j] =0.0;
    dzcstheta[i][j] =0.0;


  }
  } */
/////////////////////////////////////////////////////////////////////

}    // End routine

