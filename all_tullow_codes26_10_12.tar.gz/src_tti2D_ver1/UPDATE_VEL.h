/// main routine for diff stress and velocity
/*
  // 4th order rsg
    dsxxdx=da*c1*(stress[0][i][j-1]   -stress[0][i-1][j]   +stress[0][i][j]      -stress[0][i-1][j-1])
          -da*c2*(stress[0][i+1][j-2]-stress[0][i-2][j+1]+stress[0][i+1][j+1]-stress[0][i-2][j-2]);

    dszzdz=da*c1*(stress[1][i][j]      -stress[1][i-1][j-1]+stress[1][i-1][j]   -stress[1][i][j-1])
          -da*c2*(stress[1][i+1][j+1]-stress[1][i-2][j-2]+stress[1][i-2][j+1]-stress[1][i+1][j-2]);

  // 6th order rsg
    dsxxdx=da*c1*(stress[i][j-1][0]   - stress[i-1][j][0]   + stress[i][j][0] -stress[i-1][j-1][0])
            -da*c2*(stress[i+1][j-2][0] - stress[i-2][j+1][0] + stress[i+1][j+1][0]-stress[i-2][j-2][0])
            +da*c3*(stress[i+2][j-3][0] - stress[i-3][j+2][0] + stress[i+2][j+2][0]-stress[i-3][j-3][0]);

    dszzdz=da*c1*(stress[i][j][1]     -stress[i-1][j-1][1]+stress[i-1][j][1]   -stress[i][j-1][1])
          -da*c2*(stress[i+1][j+1][1] -stress[i-2][j-2][1]+stress[i-2][j+1][1] -stress[i+1][j-2][1])
          +da*c3*(stress[i+2][j+2][1] -stress[i-3][j-3][1]+stress[i-3][j+2][1] -stress[i+2][j-3][1]);
*/

// Diff of the velocities to get the stress
void diff_stress(double stress[Nx+2*order][Nzz][2],double u[Nx+2*order][Nzz][2])
{
 int i,j,jj;
 double da=0.5/dx,x1,z1;
 double c11,c22,c33;
 double sxx,szz;
 double ctheta2a,stheta2a,csthetaa;

 c11=da*c1;
 c22=-da*c2;
 c33=da*c3;

if(X_pml[my_rank]==1)
{
////////////////////////////////////////////////////////////////////////////
 for(i=order; i<Nx+order; i++)
 {
 for(j=PMLW; j<Nzz-PMLW; j++)
 {
    // 6th order rsg
    dsxxdx=  c11*(stress[i][j-1][0]   - stress[i-1][j][0]   + stress[i][j][0] -stress[i-1][j-1][0])
            +c22*(stress[i+1][j-2][0] - stress[i-2][j+1][0] + stress[i+1][j+1][0]-stress[i-2][j-2][0])
            +c33*(stress[i+2][j-3][0] - stress[i-3][j+2][0] + stress[i+2][j+2][0]-stress[i-3][j-3][0]);

    dszzdz= c11*(stress[i][j][1]     -stress[i-1][j-1][1]+stress[i-1][j][1]   -stress[i][j-1][1])
           +c22*(stress[i+1][j+1][1] -stress[i-2][j-2][1]+stress[i-2][j+1][1] -stress[i+1][j-2][1])
           +c33*(stress[i+2][j+2][1] -stress[i-3][j-3][1]+stress[i-3][j+2][1] -stress[i+2][j-3][1]);

    dszzdx=  c11*(stress[i][j-1][1]   - stress[i-1][j][1]   + stress[i][j][1] -stress[i-1][j-1][1])
            +c22*(stress[i+1][j-2][1] - stress[i-2][j+1][1] + stress[i+1][j+1][1]-stress[i-2][j-2][1])
            +c33*(stress[i+2][j-3][1] - stress[i-3][j+2][1] + stress[i+2][j+2][1]-stress[i-3][j-3][1]);

    dsxxdz= c11*(stress[i][j][0]     -stress[i-1][j-1][0]+stress[i-1][j][0]   -stress[i][j-1][0])
           +c22*(stress[i+1][j+1][0] -stress[i-2][j-2][0]+stress[i-2][j+1][0] -stress[i+1][j-2][0])
           +c33*(stress[i+2][j+2][0] -stress[i-3][j-3][0]+stress[i-3][j+2][0] -stress[i+2][j-3][0]);

    sxx = 0.25*(stress[i][j-1][0] + stress[i-1][j][0] + stress[i][j][0] + stress[i-1][j-1][0] );
    szz = 0.25*(stress[i][j][1] + stress[i-1][j-1][1] + stress[i-1][j][1] + stress[i][j-1][1] );

    ctheta2a=0.25*(ctheta2[i-order+1][j-1] + ctheta2[i-order][j] + ctheta2[i-order+1][j] + ctheta2[i-order+1][j-1]);
    stheta2a=0.25*(stheta2[i-order+1][j-1] + stheta2[i-order][j] + stheta2[i-order+1][j] + stheta2[i-order+1][j-1]);
    csthetaa=0.25*(cstheta[i-order+1][j-1] + cstheta[i-order][j] + cstheta[i-order+1][j] + cstheta[i-order+1][j-1]);

    u[i][j][0] = u[i][j][0] 
               + dt*( dxctheta2[i-order][j]*sxx + ctheta2a*dsxxdx 
                    + dxstheta2[i-order][j]*szz + stheta2a*dszzdx
                    + dzcstheta[i-order][j]*sxx + csthetaa*dsxxdz
                    - dzcstheta[i-order][j]*szz - csthetaa*dszzdz )/densU[i-order][j]
               + gauss[i-order][j]*sourceX[time1];

    u[i][j][1] = u[i][j][1] 
               + dt*( dxcstheta[i-order][j]*sxx + csthetaa*dsxxdx 
                    - dxcstheta[i-order][j]*szz - csthetaa*dszzdx
                    + dzstheta2[i-order][j]*sxx + stheta2a*dsxxdz
                    + dzctheta2[i-order][j]*szz + ctheta2a*dszzdz )/densU[i-order][j]
               + gauss[i-order][j]*sourceY[time1];

  }
  }
////////////////////////////////////////////////////////////////////////////
 for(i=order; i<Nx+order; i++)
 {
 for(j=Nzz-PMLW; j<Nzz-order; j++)
 {
    // 6th order rsg
    dsxxdx=da*c1*(stress[i][j-1][0]   - stress[i-1][j][0]   + stress[i][j][0] -stress[i-1][j-1][0])
            -da*c2*(stress[i+1][j-2][0] - stress[i-2][j+1][0] + stress[i+1][j+1][0]-stress[i-2][j-2][0])
            +da*c3*(stress[i+2][j-3][0] - stress[i-3][j+2][0] + stress[i+2][j+2][0]-stress[i-3][j-3][0]);

    dszzdz=da*c1*(stress[i][j][1]     -stress[i-1][j-1][1]+stress[i-1][j][1]   -stress[i][j-1][1])
          -da*c2*(stress[i+1][j+1][1] -stress[i-2][j-2][1]+stress[i-2][j+1][1] -stress[i+1][j-2][1])
          +da*c3*(stress[i+2][j+2][1] -stress[i-3][j-3][1]+stress[i-3][j+2][1] -stress[i+2][j-3][1]);

    dszzdx=  c11*(stress[i][j-1][1]   - stress[i-1][j][1]   + stress[i][j][1] -stress[i-1][j-1][1])
            +c22*(stress[i+1][j-2][1] - stress[i-2][j+1][1] + stress[i+1][j+1][1]-stress[i-2][j-2][1])
            +c33*(stress[i+2][j-3][1] - stress[i-3][j+2][1] + stress[i+2][j+2][1]-stress[i-3][j-3][1]);

    dsxxdz= c11*(stress[i][j][0]     -stress[i-1][j-1][0]+stress[i-1][j][0]   -stress[i][j-1][0])
           +c22*(stress[i+1][j+1][0] -stress[i-2][j-2][0]+stress[i-2][j+1][0] -stress[i+1][j-2][0])
           +c33*(stress[i+2][j+2][0] -stress[i-3][j-3][0]+stress[i-3][j+2][0] -stress[i+2][j-3][0]);

    sxx = 0.25*(stress[i][j-1][0] + stress[i-1][j][0] + stress[i][j][0] + stress[i-1][j-1][0] );
    szz = 0.25*(stress[i][j][1] + stress[i-1][j-1][1] + stress[i-1][j][1] + stress[i][j-1][1] );

    ctheta2a=0.25*(ctheta2[i-order+1][j-1]+ctheta2[i-order][j]+ctheta2[i-order+1][j]+ctheta2[i-order+1][j-1]);
    stheta2a=0.25*(stheta2[i-order+1][j-1]+stheta2[i-order][j]+stheta2[i-order+1][j]+stheta2[i-order+1][j-1]);
    csthetaa=0.25*(cstheta[i-order+1][j-1]+cstheta[i-order][j]+cstheta[i-order+1][j]+cstheta[i-order+1][j-1]);

     jj=j-Nzz+PMLW;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

     uxt[i-order][jj][0]=( uxt[i-order][jj][0]/dt - 0.5*dxx[i-order]*uxt[i-order][jj][0] 
                    +( dxctheta2[i-order][j]*sxx + ctheta2a*dsxxdx 
                     + stheta2a*dszzdx + dzcstheta[i-order][j]*sxx  )/densU[i-order][j] )/x1;

     uzt[i-order][jj][0]=( uzt[i-order][jj][0]/dt - 0.5*dzz[j]*uzt[i-order][jj][0]
                    +( dxstheta2[i-order][j]*szz + csthetaa*dsxxdz
                     - dzcstheta[i-order][j]*szz - csthetaa*dszzdz )/densU[i-order][j]  )/z1;

     u[i][j][0] = uxt[i-order][jj][0] + uzt[i-order][jj][0] + gauss[i-order][j]*sourceX[time1];


     uxt[i-order][jj][1]=(uxt[i-order][jj][1]/dt - 0.5*dxx[i-order]*uxt[i-order][jj][1]
                    +( dxcstheta[i-order][j]*sxx + csthetaa*dsxxdx 
                     - csthetaa*dszzdx + dzstheta2[i-order][j]*sxx )/densU[i-order][j] )/x1;

     uzt[i-order][jj][1]=(uzt[i-order][jj][1]/dt - 0.5*dzz[j]*uzt[i-order][jj][1]
                    +( -dxcstheta[i-order][j]*szz + stheta2a*dsxxdz
                    + dzctheta2[i-order][j]*szz + ctheta2a*dszzdz )/densU[i-order][j]  )/z1;

     u[i][j][1] = uxt[i-order][jj][1] + uzt[i-order][jj][1] + gauss[i-order][j]*sourceY[time1];

  }
  }
////////////////////////////////////////////////////////////////////////////
 for(i=order; i<Nx+order; i++)
 {
 for(j=Nzz-order; j<Nzz; j++)
 {
     dsxxdx=0.0;
     dszzdz=0.0;
     dsxxdz=0.0;
     dszzdx=0.0;

     sxx = 0.25*(stress[i][j-1][0] + stress[i-1][j][0] + stress[i][j][0] + stress[i-1][j-1][0] );
     szz = 0.25*(stress[i][j][1] + stress[i-1][j-1][1] + stress[i-1][j][1] + stress[i][j-1][1] );

    ctheta2a=0.25*(ctheta2[i-order+1][j-1]+ctheta2[i-order][j]+ctheta2[i-order+1][j]+ctheta2[i-order+1][j-1]);
    stheta2a=0.25*(stheta2[i-order+1][j-1]+stheta2[i-order][j]+stheta2[i-order+1][j]+stheta2[i-order+1][j-1]);
    csthetaa=0.25*(cstheta[i-order+1][j-1]+cstheta[i-order][j]+cstheta[i-order+1][j]+cstheta[i-order+1][j-1]);

     jj=j-Nzz+PMLW;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

     uxt[i-order][jj][0]=( uxt[i-order][jj][0]/dt - 0.5*dxx[i-order]*uxt[i-order][jj][0] 
                    +( dxctheta2[i-order][j]*sxx + ctheta2a*dsxxdx 
                     + stheta2a*dszzdx + dzcstheta[i-order][j]*sxx  )/densU[i-order][j] )/x1;

     uzt[i-order][jj][0]=( uzt[i-order][jj][0]/dt - 0.5*dzz[j]*uzt[i-order][jj][0]
                    +( dxstheta2[i-order][j]*szz + csthetaa*dsxxdz
                     - dzcstheta[i-order][j]*szz - csthetaa*dszzdz )/densU[i-order][j]  )/z1;

     u[i][j][0] = uxt[i-order][jj][0] + uzt[i-order][jj][0] + gauss[i-order][j]*sourceX[time1];


     uxt[i-order][jj][1]=(uxt[i-order][jj][1]/dt - 0.5*dxx[i-order]*uxt[i-order][jj][1]
                    +( dxcstheta[i-order][j]*sxx + csthetaa*dsxxdx 
                     - csthetaa*dszzdx + dzstheta2[i-order][j]*sxx )/densU[i-order][j] )/x1;

     uzt[i-order][jj][1]=(uzt[i-order][jj][1]/dt - 0.5*dzz[j]*uzt[i-order][jj][1]
                    +( -dxcstheta[i-order][j]*szz + stheta2a*dsxxdz
                    + dzctheta2[i-order][j]*szz + ctheta2a*dszzdz )/densU[i-order][j]  )/z1;

     u[i][j][1] = uxt[i-order][jj][1] + uzt[i-order][jj][1] + gauss[i-order][j]*sourceY[time1];
  }
  }
////////////////////////////////////////////////////////////////////////////
  for(i=order; i<Nx+order; i++)
  {
  for(j=order; j<PMLW; j++)
  {
    // 6th order rsg
    dsxxdx=da*c1*(stress[i][j-1][0]   - stress[i-1][j][0]   + stress[i][j][0] -stress[i-1][j-1][0])
            -da*c2*(stress[i+1][j-2][0] - stress[i-2][j+1][0] + stress[i+1][j+1][0]-stress[i-2][j-2][0])
            +da*c3*(stress[i+2][j-3][0] - stress[i-3][j+2][0] + stress[i+2][j+2][0]-stress[i-3][j-3][0]);

    dszzdz=da*c1*(stress[i][j][1]     -stress[i-1][j-1][1]+stress[i-1][j][1]   -stress[i][j-1][1])
          -da*c2*(stress[i+1][j+1][1] -stress[i-2][j-2][1]+stress[i-2][j+1][1] -stress[i+1][j-2][1])
          +da*c3*(stress[i+2][j+2][1] -stress[i-3][j-3][1]+stress[i-3][j+2][1] -stress[i+2][j-3][1]);
    
    dszzdx=  c11*(stress[i][j-1][1]   - stress[i-1][j][1]   + stress[i][j][1] -stress[i-1][j-1][1])
            +c22*(stress[i+1][j-2][1] - stress[i-2][j+1][1] + stress[i+1][j+1][1]-stress[i-2][j-2][1])
            +c33*(stress[i+2][j-3][1] - stress[i-3][j+2][1] + stress[i+2][j+2][1]-stress[i-3][j-3][1]);

    dsxxdz= c11*(stress[i][j][0]     -stress[i-1][j-1][0]+stress[i-1][j][0]   -stress[i][j-1][0])
           +c22*(stress[i+1][j+1][0] -stress[i-2][j-2][0]+stress[i-2][j+1][0] -stress[i+1][j-2][0])
           +c33*(stress[i+2][j+2][0] -stress[i-3][j-3][0]+stress[i-3][j+2][0] -stress[i+2][j-3][0]);

    sxx = 0.25*(stress[i][j-1][0] + stress[i-1][j][0] + stress[i][j][0] + stress[i-1][j-1][0] );
    szz = 0.25*(stress[i][j][1] + stress[i-1][j-1][1] + stress[i-1][j][1] + stress[i][j-1][1] );

    ctheta2a=0.25*(ctheta2[i-order+1][j-1]+ctheta2[i-order][j]+ctheta2[i-order+1][j]+ctheta2[i-order+1][j-1]);
    stheta2a=0.25*(stheta2[i-order+1][j-1]+stheta2[i-order][j]+stheta2[i-order+1][j]+stheta2[i-order+1][j-1]);
    csthetaa=0.25*(cstheta[i-order+1][j-1]+cstheta[i-order][j]+cstheta[i-order+1][j]+cstheta[i-order+1][j-1]);

     jj=j;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

     uxb[i-order][jj][0]=( uxb[i-order][jj][0]/dt - 0.5*dxx[i-order]*uxb[i-order][jj][0] 
                    +( dxctheta2[i-order][j]*sxx + ctheta2a*dsxxdx 
                     + stheta2a*dszzdx + dzcstheta[i-order][j]*sxx  )/densU[i-order][j] )/x1;

     uzb[i-order][jj][0]=( uzb[i-order][jj][0]/dt - 0.5*dzz[j]*uzb[i-order][jj][0]
                    +( dxstheta2[i-order][j]*szz + csthetaa*dsxxdz
                     - dzcstheta[i-order][j]*szz - csthetaa*dszzdz )/densU[i-order][j]  )/z1;

     u[i][j][0] = uxb[i-order][jj][0] + uzb[i-order][jj][0] + gauss[i-order][j]*sourceX[time1];


     uxb[i-order][jj][1]=(uxb[i-order][jj][1]/dt - 0.5*dxx[i-order]*uxb[i-order][jj][1]
                    +( dxcstheta[i-order][j]*sxx + csthetaa*dsxxdx 
                     - csthetaa*dszzdx + dzstheta2[i-order][j]*sxx )/densU[i-order][j] )/x1;

     uzb[i-order][jj][1]=(uzb[i-order][jj][1]/dt - 0.5*dzz[j]*uzb[i-order][jj][1]
                    +( -dxcstheta[i-order][j]*szz + stheta2a*dsxxdz
                    + dzctheta2[i-order][j]*szz + ctheta2a*dszzdz )/densU[i-order][j]  )/z1;

     u[i][j][1] = uxb[i-order][jj][1] + uzb[i-order][jj][1] + gauss[i-order][j]*sourceY[time1];

  }
  }
  for(i=order; i<Nx+order; i++)
  {
  for(j=0; j<order; j++)
  {
     dsxxdx=0.0;
     dszzdz=0.0;
     dsxxdz=0.0;
     dszzdx=0.0;

     sxx = 0.5*(stress[i-1][j][0] + stress[i][j][0] );
     szz = 0.5*(stress[i][j][1] + stress[i-1][j][1] );

     ctheta2a=0.5*(ctheta2[i-order][j]+ctheta2[i-order+1][j]);
     stheta2a=0.5*(stheta2[i-order][j]+stheta2[i-order+1][j]);
     csthetaa=0.5*(cstheta[i-order][j]+cstheta[i-order+1][j]);

     jj=j;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

     uxb[i-order][jj][0]=( uxb[i-order][jj][0]/dt - 0.5*dxx[i-order]*uxb[i-order][jj][0] 
                    +( dxctheta2[i-order][j]*sxx + ctheta2a*dsxxdx 
                     + stheta2a*dszzdx + dzcstheta[i-order][j]*sxx  )/densU[i-order][j] )/x1;

     uzb[i-order][jj][0]=( uzb[i-order][jj][0]/dt - 0.5*dzz[j]*uzb[i-order][jj][0]
                    +( dxstheta2[i-order][j]*szz + csthetaa*dsxxdz
                     - dzcstheta[i-order][j]*szz - csthetaa*dszzdz )/densU[i-order][j]  )/z1;

     u[i][j][0] = uxb[i-order][jj][0] + uzb[i-order][jj][0] + gauss[i-order][j]*sourceX[time1];


     uxb[i-order][jj][1]=(uxb[i-order][jj][1]/dt - 0.5*dxx[i-order]*uxb[i-order][jj][1]
                    +( dxcstheta[i-order][j]*sxx + csthetaa*dsxxdx 
                     - csthetaa*dszzdx + dzstheta2[i-order][j]*sxx )/densU[i-order][j] )/x1;

     uzb[i-order][jj][1]=(uzb[i-order][jj][1]/dt - 0.5*dzz[j]*uzb[i-order][jj][1]
                    +( -dxcstheta[i-order][j]*szz + stheta2a*dsxxdz
                    + dzctheta2[i-order][j]*szz + ctheta2a*dszzdz )/densU[i-order][j]  )/z1;

     u[i][j][1] = uxb[i-order][jj][1] + uzb[i-order][jj][1] + gauss[i-order][j]*sourceY[time1];
  }
  }

////////////////////////////////////////////////////////////////////////////
}  // outside pml x zone
else if(X_pml[my_rank]==0)
{
////////////////////////////////////////////////////////////////////////////
 for(i=order; i<Nx+order; i++)
 {
 for(j=order; j<Nzz-order; j++)
 {
    // 6th order rsg
    dsxxdx=da*c1*(stress[i][j-1][0]   - stress[i-1][j][0]   + stress[i][j][0] -stress[i-1][j-1][0])
            -da*c2*(stress[i+1][j-2][0] - stress[i-2][j+1][0] + stress[i+1][j+1][0]-stress[i-2][j-2][0])
            +da*c3*(stress[i+2][j-3][0] - stress[i-3][j+2][0] + stress[i+2][j+2][0]-stress[i-3][j-3][0]);

    dszzdz=da*c1*(stress[i][j][1]     -stress[i-1][j-1][1]+stress[i-1][j][1]   -stress[i][j-1][1])
          -da*c2*(stress[i+1][j+1][1] -stress[i-2][j-2][1]+stress[i-2][j+1][1] -stress[i+1][j-2][1])
          +da*c3*(stress[i+2][j+2][1] -stress[i-3][j-3][1]+stress[i-3][j+2][1] -stress[i+2][j-3][1]);

    dszzdx=  c11*(stress[i][j-1][1]   - stress[i-1][j][1]   + stress[i][j][1] -stress[i-1][j-1][1])
            +c22*(stress[i+1][j-2][1] - stress[i-2][j+1][1] + stress[i+1][j+1][1]-stress[i-2][j-2][1])
            +c33*(stress[i+2][j-3][1] - stress[i-3][j+2][1] + stress[i+2][j+2][1]-stress[i-3][j-3][1]);

    dsxxdz= c11*(stress[i][j][0]     -stress[i-1][j-1][0]+stress[i-1][j][0]   -stress[i][j-1][0])
           +c22*(stress[i+1][j+1][0] -stress[i-2][j-2][0]+stress[i-2][j+1][0] -stress[i+1][j-2][0])
           +c33*(stress[i+2][j+2][0] -stress[i-3][j-3][0]+stress[i-3][j+2][0] -stress[i+2][j-3][0]);

    sxx = 0.25*(stress[i][j-1][0] + stress[i-1][j][0] + stress[i][j][0] + stress[i-1][j-1][0] );
    szz = 0.25*(stress[i][j][1] + stress[i-1][j-1][1] + stress[i-1][j][1] + stress[i][j-1][1] );

    ctheta2a=0.25*(ctheta2[i-order+1][j-1]+ctheta2[i-order][j]+ctheta2[i-order+1][j]+ctheta2[i-order+1][j-1]);
    stheta2a=0.25*(stheta2[i-order+1][j-1]+stheta2[i-order][j]+stheta2[i-order+1][j]+stheta2[i-order+1][j-1]);
    csthetaa=0.25*(cstheta[i-order+1][j-1]+cstheta[i-order][j]+cstheta[i-order+1][j]+cstheta[i-order+1][j-1]);

     jj=j;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

     uxa[i-order][jj][0]=( uxa[i-order][jj][0]/dt - 0.5*dxx[i-order]*uxa[i-order][jj][0] 
                    +( dxctheta2[i-order][j]*sxx + ctheta2a*dsxxdx 
                     + stheta2a*dszzdx + dzcstheta[i-order][j]*sxx  )/densU[i-order][j] )/x1;

     uza[i-order][jj][0]=( uza[i-order][jj][0]/dt - 0.5*dzz[j]*uza[i-order][jj][0]
                    +( dxstheta2[i-order][j]*szz + csthetaa*dsxxdz
                     - dzcstheta[i-order][j]*szz - csthetaa*dszzdz )/densU[i-order][j]  )/z1;

     u[i][j][0] = uxa[i-order][jj][0] + uza[i-order][jj][0] + gauss[i-order][j]*sourceX[time1];


     uxa[i-order][jj][1]=(uxa[i-order][jj][1]/dt - 0.5*dxx[i-order]*uxa[i-order][jj][1]
                    +( dxcstheta[i-order][j]*sxx + csthetaa*dsxxdx 
                     - csthetaa*dszzdx + dzstheta2[i-order][j]*sxx )/densU[i-order][j] )/x1;

     uza[i-order][jj][1]=(uza[i-order][jj][1]/dt - 0.5*dzz[j]*uza[i-order][jj][1]
                    +( -dxcstheta[i-order][j]*szz + stheta2a*dsxxdz
                    + dzctheta2[i-order][j]*szz + ctheta2a*dszzdz )/densU[i-order][j]  )/z1;

     u[i][j][1] = uxa[i-order][jj][1] + uza[i-order][jj][1] + gauss[i-order][j]*sourceY[time1];
 }
 }
///////////////////////////////////////////////////////////
 for(i=order; i<Nx+order; i++)
 {
 for(j=0; j<order; j++)
 {
     dsxxdx=0.0;
     dszzdz=0.0;
     dsxxdz=0.0;
     dszzdx=0.0;

     sxx = 0.5*(stress[i-1][j][0] + stress[i][j][0] );
     szz = 0.5*(stress[i][j][1] + stress[i-1][j][1] );

    ctheta2a=0.5*(ctheta2[i-order][j]+ctheta2[i-order+1][j]);
    stheta2a=0.5*(stheta2[i-order][j]+stheta2[i-order+1][j]);
    csthetaa=0.5*(cstheta[i-order][j]+cstheta[i-order+1][j]);

     jj=j;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

     uxa[i-order][jj][0]=( uxa[i-order][jj][0]/dt - 0.5*dxx[i-order]*uxa[i-order][jj][0] 
                    +( dxctheta2[i-order][j]*sxx + ctheta2a*dsxxdx 
                     + stheta2a*dszzdx + dzcstheta[i-order][j]*sxx  )/densU[i-order][j] )/x1;

     uza[i-order][jj][0]=( uza[i-order][jj][0]/dt - 0.5*dzz[j]*uza[i-order][jj][0]
                    +( dxstheta2[i-order][j]*szz + csthetaa*dsxxdz
                     - dzcstheta[i-order][j]*szz - csthetaa*dszzdz )/densU[i-order][j]  )/z1;

     u[i][j][0] = uxa[i-order][jj][0] + uza[i-order][jj][0] + gauss[i-order][j]*sourceX[time1];


     uxa[i-order][jj][1]=(uxa[i-order][jj][1]/dt - 0.5*dxx[i-order]*uxa[i-order][jj][1]
                    +( dxcstheta[i-order][j]*sxx + csthetaa*dsxxdx 
                     - csthetaa*dszzdx + dzstheta2[i-order][j]*sxx )/densU[i-order][j] )/x1;

     uza[i-order][jj][1]=(uza[i-order][jj][1]/dt - 0.5*dzz[j]*uza[i-order][jj][1]
                    +( -dxcstheta[i-order][j]*szz + stheta2a*dsxxdz
                    + dzctheta2[i-order][j]*szz + ctheta2a*dszzdz )/densU[i-order][j]  )/z1;

     u[i][j][1] = uxa[i-order][jj][1] + uza[i-order][jj][1] + gauss[i-order][j]*sourceY[time1];

 }
 }
///////////////////////////////////////////////////////////
 for(i=order; i<Nx+order; i++)
 {
 for(j=Nzz-order; j<Nzz; j++)
 {
     dsxxdx=0.0;
     dszzdz=0.0;
     dsxxdz=0.0;
     dszzdx=0.0;

     sxx = 0.25*(stress[i][j-1][0] + stress[i-1][j][0] + stress[i][j][0] + stress[i-1][j-1][0] );
     szz = 0.25*(stress[i][j][1] + stress[i-1][j-1][1] + stress[i-1][j][1] + stress[i][j-1][1] );

    ctheta2a=0.25*(ctheta2[i-order+1][j-1]+ctheta2[i-order][j]+ctheta2[i-order+1][j]+ctheta2[i-order+1][j-1]);
    stheta2a=0.25*(stheta2[i-order+1][j-1]+stheta2[i-order][j]+stheta2[i-order+1][j]+stheta2[i-order+1][j-1]);
    csthetaa=0.25*(cstheta[i-order+1][j-1]+cstheta[i-order][j]+cstheta[i-order+1][j]+cstheta[i-order+1][j-1]);

     jj=j;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

     uxa[i-order][jj][0]=( uxa[i-order][jj][0]/dt - 0.5*dxx[i-order]*uxa[i-order][jj][0] 
                    +( dxctheta2[i-order][j]*sxx + ctheta2a*dsxxdx 
                     + stheta2a*dszzdx + dzcstheta[i-order][j]*sxx  )/densU[i-order][j] )/x1;

     uza[i-order][jj][0]=( uza[i-order][jj][0]/dt - 0.5*dzz[j]*uza[i-order][jj][0]
                    +( dxstheta2[i-order][j]*szz + csthetaa*dsxxdz
                     - dzcstheta[i-order][j]*szz - csthetaa*dszzdz )/densU[i-order][j]  )/z1;

     u[i][j][0] = uxa[i-order][jj][0] + uza[i-order][jj][0] + gauss[i-order][j]*sourceX[time1];


     uxa[i-order][jj][1]=(uxa[i-order][jj][1]/dt - 0.5*dxx[i-order]*uxa[i-order][jj][1]
                    +( dxcstheta[i-order][j]*sxx + csthetaa*dsxxdx 
                     - csthetaa*dszzdx + dzstheta2[i-order][j]*sxx )/densU[i-order][j] )/x1;

     uza[i-order][jj][1]=(uza[i-order][jj][1]/dt - 0.5*dzz[j]*uza[i-order][jj][1]
                    +( -dxcstheta[i-order][j]*szz + stheta2a*dsxxdz
                    + dzctheta2[i-order][j]*szz + ctheta2a*dszzdz )/densU[i-order][j]  )/z1;

     u[i][j][1] = uxa[i-order][jj][1] + uza[i-order][jj][1] + gauss[i-order][j]*sourceY[time1];
 }
 }
////////////////////////////////////////////////////////////////////////////
}  // outside pml loop


}

// Diff of the velocities to get the stress
void diff_vel(double stress[Nx+2*order][Nzz][2],double u[Nx+2*order][Nzz][2])
{
 int i,j,jj;
 double d1,d2,da=0.5/dx,x1,z1;
 double c11,c22,c33;
 double sqrtdelta,epsCons,Vp2;

 c11=da*c1;
 c22=-da*c2;
 c33=da*c3;

if(X_pml[my_rank]==1)
{
////////////////////////////////////////////////////////////////////////////
 for(i=order; i<Nx+order; i++)
 {
 for(j=PMLW; j<Nzz-PMLW; j++)
 {
    // 6th order rsg
     dudx = c11*( u[i+1][j][0]   -u[i][j+1][0]   + u[i+1][j+1][0] - u[i][j][0])
           +c22*( u[i+2][j-1][0] -u[i-1][j+2][0] + u[i+2][j+2][0] - u[i-1][j-1][0])
           +c33*( u[i+3][j-2][0] -u[i-2][j+3][0] + u[i+3][j+3][0] - u[i-2][j-2][0]);

     dvdz = c11*( u[i+1][j+1][1]-  u[i][j][1]      + u[i][j+1][1]    - u[i+1][j][1])
           +c22*( u[i+2][j+2][1] - u[i-1][j-1][1]  + u[i-1][j+2][1]  - u[i+2][j-1][1])
           +c33*( u[i+3][j+3][1] - u[i-2][j-2][1]  + u[i-2][j+3][1]  - u[i+3][j-2][1]);

     dvdx = c11*( u[i+1][j][1]   -u[i][j+1][1]   + u[i+1][j+1][1] - u[i][j][1])
           +c22*( u[i+2][j-1][1] -u[i-1][j+2][1] + u[i+2][j+2][1] - u[i-1][j-1][1])
           +c33*( u[i+3][j-2][1] -u[i-2][j+3][1] + u[i+3][j+3][1] - u[i-2][j-2][1]);

     dudz = c11*( u[i+1][j+1][0]-  u[i][j][0]      + u[i][j+1][0]    - u[i+1][j][0])
           +c22*( u[i+2][j+2][0] - u[i-1][j-1][0]  + u[i-1][j+2][0]  - u[i+2][j-1][0])
           +c33*( u[i+3][j+3][0] - u[i-2][j-2][0]  + u[i-2][j+3][0]  - u[i+3][j-2][0]);

    sqrtdelta=sqrt(1.0+2.0*delta[i-order][j]);
    epsCons=(1.0+2.0*eps[i-order][j]);
    Vp2=densL[i-order][j]*velp[i-order][j]*velp[i-order][j];

    stress[i][j][0] = stress[i][j][0]
                    + dt*Vp2*( (epsCons*ctheta2[i-order+1][j]+sqrtdelta*stheta2[i-order+1][j])*dudx 
                              +(epsCons*cstheta[i-order+1][j]-sqrtdelta*cstheta[i-order+1][j])*dudz
                              +(epsCons*cstheta[i-order+1][j]-sqrtdelta*cstheta[i-order+1][j])*dvdx
                              +(epsCons*stheta2[i-order+1][j]+sqrtdelta*ctheta2[i-order+1][j])*dvdz )
                    + gauss[i-order][j]*source[time1];

    stress[i][j][1] =  stress[i][j][1]
                    + dt*Vp2*( (sqrtdelta*ctheta2[i-order+1][j]+stheta2[i-order+1][j])*dudx 
                              +(sqrtdelta*cstheta[i-order+1][j]-cstheta[i-order+1][j])*dudz
                              +(sqrtdelta*cstheta[i-order+1][j]-cstheta[i-order+1][j])*dvdx
                              +(sqrtdelta*stheta2[i-order+1][j]+ctheta2[i-order+1][j])*dvdz )
                    + gauss[i-order][j]*source[time1];
/// nice to see if changing sqrt function speeds up code
  }
  }
////////////////////////////////////////////////////////////////////////////
 for(i=order; i<Nx+order; i++)
 {
 for(j=Nzz-PMLW; j<Nzz-order; j++)
 {
    // 6th order rsg
     dudx = da*c1*( u[i+1][j][0]   -u[i][j+1][0]   + u[i+1][j+1][0] - u[i][j][0])
           -da*c2*( u[i+2][j-1][0] -u[i-1][j+2][0] + u[i+2][j+2][0] - u[i-1][j-1][0])
           +da*c3*( u[i+3][j-2][0] -u[i-2][j+3][0] + u[i+3][j+3][0] - u[i-2][j-2][0]);

     dvdz = da*c1*( u[i+1][j+1][1]-  u[i][j][1]      + u[i][j+1][1]    - u[i+1][j][1])
           -da*c2*( u[i+2][j+2][1] - u[i-1][j-1][1]  + u[i-1][j+2][1]  - u[i+2][j-1][1])
           +da*c3*( u[i+3][j+3][1] - u[i-2][j-2][1]  + u[i-2][j+3][1]  - u[i+3][j-2][1]);

     dvdx = c11*( u[i+1][j][1]   -u[i][j+1][1]   + u[i+1][j+1][1] - u[i][j][1])
           +c22*( u[i+2][j-1][1] -u[i-1][j+2][1] + u[i+2][j+2][1] - u[i-1][j-1][1])
           +c33*( u[i+3][j-2][1] -u[i-2][j+3][1] + u[i+3][j+3][1] - u[i-2][j-2][1]);

     dudz = c11*( u[i+1][j+1][0]-  u[i][j][0]      + u[i][j+1][0]    - u[i+1][j][0])
           +c22*( u[i+2][j+2][0] - u[i-1][j-1][0]  + u[i-1][j+2][0]  - u[i+2][j-1][0])
           +c33*( u[i+3][j+3][0] - u[i-2][j-2][0]  + u[i-2][j+3][0]  - u[i+3][j-2][0]);

     jj=j-Nzz+PMLW;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

     sqrtdelta=sqrt(1.0+2.0*delta[i-order][j]);
     epsCons=(1.0+2.0*eps[i-order][j]);
     Vp2=densL[i-order][j]*velp[i-order][j]*velp[i-order][j];

     sxt[i-order][jj][0]=( sxt[i-order][jj][0]*(1.0/dt - dxx[i-order]*0.5)
              + Vp2*( (epsCons*ctheta2[i-order+1][j]+sqrtdelta*stheta2[i-order+1][j])*dudx 
                     +(epsCons*cstheta[i-order+1][j]-sqrtdelta*cstheta[i-order+1][j])*dvdx ) )/x1;

     szt[i-order][jj][0]=( szt[i-order][jj][0]*(1.0/dt - dzz[j]*0.5)
              + Vp2*( (epsCons*cstheta[i-order+1][j]-sqrtdelta*cstheta[i-order+1][j])*dudz
                     +(epsCons*stheta2[i-order+1][j]+sqrtdelta*ctheta2[i-order+1][j])*dvdz ) )/z1;

     sxt[i-order][jj][1]=( sxt[i-order][jj][1]*(1.0/dt - dxx[i-order]*0.5)
              + Vp2*( (sqrtdelta*ctheta2[i-order+1][j]+stheta2[i-order+1][j])*dudx 
                     +(sqrtdelta*cstheta[i-order+1][j]-cstheta[i-order+1][j])*dvdx) )/x1;

     szt[i-order][jj][1]=( szt[i-order][jj][1]*(1.0/dt - dzz[j]*0.5)
              + Vp2*( (sqrtdelta*cstheta[i-order+1][j]-cstheta[i-order+1][j])*dudz
                     +(sqrtdelta*stheta2[i-order+1][j]+ctheta2[i-order+1][j])*dvdz ) )/z1;

     stress[i][j][0] = sxt[i-order][jj][0] + szt[i-order][jj][0] + gauss[i-order][j]*source[time1];
     stress[i][j][1] = sxt[i-order][jj][1] + szt[i-order][jj][1] + gauss[i-order][j]*source[time1];
 }
 }
////////////////////////////////////////////////////////////////////////////
 for(i=order; i<Nx+order; i++)
 {
 for(j=Nzz-order+1; j<Nzz; j++)
 {
     dudx=0.0; 
     dvdz=0.0;
     dudz = 0.0;
     dvdx = 0.0;

     jj=j-Nzz+PMLW;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

    sqrtdelta=sqrt(1.0+2.0*delta[i-order][j]);
    epsCons=(1.0+2.0*eps[i-order][j]);
    Vp2=densL[i-order][j]*velp[i-order][j]*velp[i-order][j];

     sxt[i-order][jj][0]=( sxt[i-order][jj][0]*(1.0/dt - dxx[i-order]*0.5)
              + Vp2*( (epsCons*ctheta2[i-order+1][j]+sqrtdelta*stheta2[i-order+1][j])*dudx 
                     +(epsCons*cstheta[i-order+1][j]-sqrtdelta*cstheta[i-order+1][j])*dvdx ) )/x1;

     szt[i-order][jj][0]=( szt[i-order][jj][0]*(1.0/dt - dzz[j]*0.5)
              + Vp2*( (epsCons*cstheta[i-order+1][j]-sqrtdelta*cstheta[i-order+1][j])*dudz
                     +(epsCons*stheta2[i-order+1][j]+sqrtdelta*ctheta2[i-order+1][j])*dvdz ) )/z1;

     sxt[i-order][jj][1]=( sxt[i-order][jj][1]*(1.0/dt - dxx[i-order]*0.5)
              + Vp2*( (sqrtdelta*ctheta2[i-order+1][j]+stheta2[i-order+1][j])*dudx 
                     +(sqrtdelta*cstheta[i-order+1][j]-cstheta[i-order+1][j])*dvdx) )/x1;

     szt[i-order][jj][1]=( szt[i-order][jj][1]*(1.0/dt - dzz[j]*0.5)
              + Vp2*(  (sqrtdelta*cstheta[i-order+1][j]-cstheta[i-order+1][j])*dudz
                      +(sqrtdelta*stheta2[i-order+1][j]+ctheta2[i-order+1][j])*dvdz ) )/z1;

     stress[i][j][0] = sxt[i-order][jj][0] + szt[i-order][jj][0] + gauss[i-order][j]*source[time1];
     stress[i][j][1] = sxt[i-order][jj][1] + szt[i-order][jj][1] + gauss[i-order][j]*source[time1];

 }
 }
////////////////////////////////////////////////////////////////////////////
 for(i=order; i<Nx+order; i++)
 {
 for(j=order; j<PMLW; j++)
 {
    // 6th order rsg
     dudx = da*c1*( u[i+1][j][0]   -u[i][j+1][0]   + u[i+1][j+1][0] - u[i][j][0])
           -da*c2*( u[i+2][j-1][0] -u[i-1][j+2][0] + u[i+2][j+2][0] - u[i-1][j-1][0])
           +da*c3*( u[i+3][j-2][0] -u[i-2][j+3][0] + u[i+3][j+3][0] - u[i-2][j-2][0]);

     dvdz = da*c1*( u[i+1][j+1][1]-  u[i][j][1]      + u[i][j+1][1]    - u[i+1][j][1])
           -da*c2*( u[i+2][j+2][1] - u[i-1][j-1][1]  + u[i-1][j+2][1]  - u[i+2][j-1][1])
           +da*c3*( u[i+3][j+3][1] - u[i-2][j-2][1]  + u[i-2][j+3][1]  - u[i+3][j-2][1]);

     dvdx = c11*( u[i+1][j][1]   -u[i][j+1][1]   + u[i+1][j+1][1] - u[i][j][1])
           +c22*( u[i+2][j-1][1] -u[i-1][j+2][1] + u[i+2][j+2][1] - u[i-1][j-1][1])
           +c33*( u[i+3][j-2][1] -u[i-2][j+3][1] + u[i+3][j+3][1] - u[i-2][j-2][1]);

     dudz = c11*( u[i+1][j+1][0]-  u[i][j][0]      + u[i][j+1][0]    - u[i+1][j][0])
           +c22*( u[i+2][j+2][0] - u[i-1][j-1][0]  + u[i-1][j+2][0]  - u[i+2][j-1][0])
           +c33*( u[i+3][j+3][0] - u[i-2][j-2][0]  + u[i-2][j+3][0]  - u[i+3][j-2][0]);

     jj=j;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

     sqrtdelta=sqrt(1.0+2.0*delta[i-order][j]);
     epsCons=(1.0+2.0*eps[i-order][j]);
     Vp2=densL[i-order][j]*velp[i-order][j]*velp[i-order][j];

     sxb[i-order][jj][0]=( sxb[i-order][jj][0]*(1.0/dt - dxx[i-order]*0.5)
               + Vp2*( (epsCons*ctheta2[i-order+1][j]+sqrtdelta*stheta2[i-order+1][j])*dudx 
                      +(epsCons*cstheta[i-order+1][j]-sqrtdelta*cstheta[i-order+1][j])*dvdx ) )/x1;

     szb[i-order][jj][0]=( szb[i-order][jj][0]*(1.0/dt - dzz[j]*0.5)
               + Vp2*( (epsCons*cstheta[i-order+1][j]-sqrtdelta*cstheta[i-order+1][j])*dudz
                      +(epsCons*stheta2[i-order+1][j]+sqrtdelta*ctheta2[i-order+1][j])*dvdz ) )/z1;

     sxb[i-order][jj][1]=( sxb[i-order][jj][1]*(1.0/dt - dxx[i-order]*0.5)
              + Vp2*( (sqrtdelta*ctheta2[i-order+1][j]+stheta2[i-order+1][j])*dudx 
                     +(sqrtdelta*cstheta[i-order+1][j]-cstheta[i-order+1][j])*dvdx) )/x1;

     szb[i-order][jj][1]=( szb[i-order][jj][1]*(1.0/dt - dzz[j]*0.5)
              + Vp2*( (sqrtdelta*cstheta[i-order+1][j]-cstheta[i-order+1][j])*dudz
                     +(sqrtdelta*stheta2[i-order+1][j]+ctheta2[i-order+1][j])*dvdz ) )/z1;

     stress[i][j][0] = sxb[i-order][jj][0] + szb[i-order][jj][0] ;
     stress[i][j][1] = sxb[i-order][jj][1] + szb[i-order][jj][1] ;
 }
 }
 for(i=order; i<Nx+order; i++)
 {
 for(j=0; j<order; j++)
 {
    // 6th order rsg
     dudx = 0.0;
     dvdz = 0.0;
     dudz = 0.0;
     dvdx = 0.0;

     jj=j;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

    sqrtdelta=sqrt(1.0+2.0*delta[i-order][j]);
    epsCons=(1.0+2.0*eps[i-order][j]);
    Vp2=densL[i-order][j]*velp[i-order][j]*velp[i-order][j];

     sxb[i-order][jj][0]=( sxb[i-order][jj][0]*(1.0/dt - dxx[i-order]*0.5)
               + Vp2*( (epsCons*ctheta2[i-order+1][j]+sqrtdelta*stheta2[i-order+1][j])*dudx 
                      +(epsCons*cstheta[i-order+1][j]-sqrtdelta*cstheta[i-order+1][j])*dvdx ) )/x1;

     szb[i-order][jj][0]=( szb[i-order][jj][0]*(1.0/dt - dzz[j]*0.5)
               + Vp2*( (epsCons*cstheta[i-order+1][j]-sqrtdelta*cstheta[i-order+1][j])*dudz
                      +(epsCons*stheta2[i-order+1][j]+sqrtdelta*ctheta2[i-order+1][j])*dvdz ) )/z1;

     sxb[i-order][jj][1]=( sxb[i-order][jj][1]*(1.0/dt - dxx[i-order]*0.5)
              + Vp2*( (sqrtdelta*ctheta2[i-order+1][j]+stheta2[i-order+1][j])*dudx 
                     +(sqrtdelta*cstheta[i-order+1][j]-cstheta[i-order+1][j])*dvdx) )/x1;

     szb[i-order][jj][1]=( szb[i-order][jj][1]*(1.0/dt - dzz[j]*0.5)
              + Vp2*( (sqrtdelta*cstheta[i-order+1][j]-cstheta[i-order+1][j])*dudz
                     +(sqrtdelta*stheta2[i-order+1][j]+ctheta2[i-order+1][j])*dvdz) )/z1;

     stress[i][j][0] = sxb[i-order][jj][0] + szb[i-order][jj][0] ;
     stress[i][j][1] = sxb[i-order][jj][1] + szb[i-order][jj][1] ;
 }
 }
////////////////////////////////////////////////////////////////////////////
}  // outside pml x zone
else if(X_pml[my_rank]==0)
{
////////////////////////////////////////////////////////////////////////////
 for(i=order; i<Nx+order; i++)
 {
 for(j=order; j<Nzz-order; j++)
 {
   // 6th order rsg
     dudx = da*c1*( u[i+1][j][0]   -u[i][j+1][0]   + u[i+1][j+1][0] - u[i][j][0])
           -da*c2*( u[i+2][j-1][0] -u[i-1][j+2][0] + u[i+2][j+2][0] - u[i-1][j-1][0])
           +da*c3*( u[i+3][j-2][0] -u[i-2][j+3][0] + u[i+3][j+3][0] - u[i-2][j-2][0]);

     dvdz = da*c1*( u[i+1][j+1][1]-  u[i][j][1]      + u[i][j+1][1]    - u[i+1][j][1])
           -da*c2*( u[i+2][j+2][1] - u[i-1][j-1][1]  + u[i-1][j+2][1]  - u[i+2][j-1][1])
           +da*c3*( u[i+3][j+3][1] - u[i-2][j-2][1]  + u[i-2][j+3][1]  - u[i+3][j-2][1]);

     dvdx = c11*( u[i+1][j][1]   -u[i][j+1][1]   + u[i+1][j+1][1] - u[i][j][1])
           +c22*( u[i+2][j-1][1] -u[i-1][j+2][1] + u[i+2][j+2][1] - u[i-1][j-1][1])
           +c33*( u[i+3][j-2][1] -u[i-2][j+3][1] + u[i+3][j+3][1] - u[i-2][j-2][1]);

     dudz = c11*( u[i+1][j+1][0]-  u[i][j][0]      + u[i][j+1][0]    - u[i+1][j][0])
           +c22*( u[i+2][j+2][0] - u[i-1][j-1][0]  + u[i-1][j+2][0]  - u[i+2][j-1][0])
           +c33*( u[i+3][j+3][0] - u[i-2][j-2][0]  + u[i-2][j+3][0]  - u[i+3][j-2][0]);

    jj=j;
    x1=(1.0/dt + dxx[i-order]*0.5);
    z1=(1.0/dt + dzz[j]*0.5);

    sqrtdelta=sqrt(1.0+2.0*delta[i-order][j]);
    epsCons=(1.0+2.0*eps[i-order][j]);
    Vp2=densL[i-order][j]*velp[i-order][j]*velp[i-order][j];

     sxa[i-order][jj][0]=( sxa[i-order][jj][0]*(1.0/dt - dxx[i-order]*0.5)
               + Vp2*( (epsCons*ctheta2[i-order+1][j]+sqrtdelta*stheta2[i-order+1][j])*dudx 
                      +(epsCons*cstheta[i-order+1][j]-sqrtdelta*cstheta[i-order+1][j])*dvdx ) )/x1;

     sza[i-order][jj][0]=( sza[i-order][jj][0]*(1.0/dt - dzz[j]*0.5)
               + Vp2*( (epsCons*cstheta[i-order+1][j]-sqrtdelta*cstheta[i-order+1][j])*dudz
                      +(epsCons*stheta2[i-order+1][j]+sqrtdelta*ctheta2[i-order+1][j])*dvdz ) )/z1;

     sxa[i-order][jj][1]=( sxa[i-order][jj][1]*(1.0/dt - dxx[i-order]*0.5)
              + Vp2*( (sqrtdelta*ctheta2[i-order+1][j]+stheta2[i-order+1][j])*dudx
                     +(sqrtdelta*cstheta[i-order+1][j]-cstheta[i-order+1][j])*dvdx) )/x1;

     sza[i-order][jj][1]=( sza[i-order][jj][1]*(1.0/dt - dzz[j]*0.5)
              + Vp2*( (sqrtdelta*cstheta[i-order+1][j]-cstheta[i-order+1][j])*dudz
                     +(sqrtdelta*stheta2[i-order+1][j]+ctheta2[i-order+1][j])*dvdz ) )/z1;

     stress[i][j][0] = sxa[i-order][jj][0] + sza[i-order][jj][0] + gauss[i-order][j]*source[time1];
     stress[i][j][1] = sxa[i-order][jj][1] + sza[i-order][jj][1] + gauss[i-order][j]*source[time1];
 }
 }
///////////////////////////////////////////////////////////
 for(i=order; i<Nx+order; i++)
 {
 for(j=0; j<order; j++)
 {
   // 6th order rsg
     dudx = 0.0;
     dvdz = 0.0;
     dudz = 0.0;
     dvdx = 0.0;

     jj=j;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

    sqrtdelta=sqrt(1.0+2.0*delta[i-order][j]);
    epsCons=(1.0+2.0*eps[i-order][j]);
    Vp2=densL[i-order][j]*velp[i-order][j]*velp[i-order][j];

     sxa[i-order][jj][0]=( sxa[i-order][jj][0]*(1.0/dt - dxx[i-order]*0.5)
               + Vp2*( (epsCons*ctheta2[i-order+1][j]+sqrtdelta*stheta2[i-order+1][j])*dudx 
                      +(epsCons*cstheta[i-order+1][j]-sqrtdelta*cstheta[i-order+1][j])*dvdx ) )/x1;

     sza[i-order][jj][0]=( sza[i-order][jj][0]*(1.0/dt - dzz[j]*0.5)
               + Vp2*( (epsCons*cstheta[i-order+1][j]-sqrtdelta*cstheta[i-order+1][j])*dudz
                      +(epsCons*stheta2[i-order+1][j]+sqrtdelta*ctheta2[i-order+1][j])*dvdz ) )/z1;

     sxa[i-order][jj][1]=( sxa[i-order][jj][1]*(1.0/dt - dxx[i-order]*0.5)
              + Vp2*( (sqrtdelta*ctheta2[i-order+1][j]+stheta2[i-order+1][j])*dudx 
                     +(sqrtdelta*cstheta[i-order+1][j]-cstheta[i-order+1][j])*dvdx) )/x1;

     sza[i-order][jj][1]=( sza[i-order][jj][1]*(1.0/dt - dzz[j]*0.5)
              + Vp2*( (sqrtdelta*cstheta[i-order+1][j]-cstheta[i-order+1][j])*dudz
                     +(sqrtdelta*stheta2[i-order+1][j]+ctheta2[i-order+1][j])*dvdz ) )/z1;

     stress[i][j][0] = sxa[i-order][jj][0] + sza[i-order][jj][0] ;
     stress[i][j][1] = sxa[i-order][jj][1] + sza[i-order][jj][1] ;
 }
 }
///////////////////////////////////////////////////////////
 for(i=order; i<Nx+order; i++)
 {
 for(j=Nzz-order; j<Nzz; j++)
 {
   // 6th order rsg
     dudx = 0.0;
     dvdz = 0.0;
     dudz = 0.0;
     dvdx = 0.0;

     jj=j;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

     sqrtdelta=sqrt(1.0+2.0*delta[i-order][j]);
     epsCons=(1.0+2.0*eps[i-order][j]);
     Vp2=densL[i-order][j]*velp[i-order][j]*velp[i-order][j];

     sxa[i-order][jj][0]=( sxa[i-order][jj][0]*(1.0/dt - dxx[i-order]*0.5)
               + Vp2*( (epsCons*ctheta2[i-order+1][j]+sqrtdelta*stheta2[i-order+1][j])*dudx 
                      +(epsCons*cstheta[i-order+1][j]-sqrtdelta*cstheta[i-order+1][j])*dvdx ) )/x1;

     sza[i-order][jj][0]=( sza[i-order][jj][0]*(1.0/dt - dzz[j]*0.5)
               + Vp2*( (epsCons*cstheta[i-order+1][j]-sqrtdelta*cstheta[i-order+1][j])*dudz
                      +(epsCons*stheta2[i-order+1][j]+sqrtdelta*ctheta2[i-order+1][j])*dvdz ) )/z1;

     sxa[i-order][jj][1]=( sxa[i-order][jj][1]*(1.0/dt - dxx[i-order]*0.5)
              + Vp2*( (sqrtdelta*ctheta2[i-order+1][j]+stheta2[i-order+1][j])*dudx 
                     +(sqrtdelta*cstheta[i-order+1][j]-cstheta[i-order+1][j])*dvdx) )/x1;

     sza[i-order][jj][1]=( sza[i-order][jj][1]*(1.0/dt - dzz[j]*0.5)
              + Vp2*( (sqrtdelta*cstheta[i-order+1][j]-cstheta[i-order+1][j])*dudz
                     +(sqrtdelta*stheta2[i-order+1][j]+ctheta2[i-order+1][j])*dvdz ) )/z1;

    stress[i][j][0] = sxa[i-order][jj][0] + sza[i-order][jj][0] + gauss[i-order][j]*source[time1];
    stress[i][j][1] = sxa[i-order][jj][1] + sza[i-order][jj][1] + gauss[i-order][j]*source[time1];
 }
 }
////////////////////////////////////////////////////////////////////////////
}  // outside pml loop


}

