
//------------------------------------------------------------------------------
// Constants and functions
#define Gauss(x,y,a)  exp( -(x*x+y*y)/(a*a) ) 
#define Max(x,y) ( (x)>=(y)  ?  (x) : (y) )
#define Min(x,y) ( (x)<=(y)  ?  (x) : (y) )
#define order 3
#define vp                   (3000.00)      // Homo p-wave speed
#define rho                  (2000.00)      // Homo density
#define EPS                  (0.0)      // Homo p-wave speed
#define DELTA                (0.0)      // Homo density
#define LR                     1
#define max_traces           (1024)
double PI=(3.14159265);

//------------------------------------------------------------------------------
// parameters used in code
int Nx,Nz,Nzz,PMLW ,no_trace; 
int velocity_model,Max_Time, absorb_model;
int sourcetype,kill_all_ascii_traces;
int snap_freq,start_time,no_snaps;
int time1;
int *x_coord,*z_coord,node_count;
int *x,*z,NumSource;
int *xsource,*zsource;
int lr_count,lr_countx,lr_countz;

double dx,dt,vp_pml,ndamp,Rdamp,amplitude,alpha;
double mxx,mzz,mxz;

char input1[50],input2[50], input3[50] ,input4[50];
char input5[50],input6[50], input7[50], input8[50], input9[50];
char output1[50],output2[50],output3[50];
//-----------------------------------------------------------------------------
// FD staggered grid operators
//double c1=(27.0/24.0);
//double c2=(1.0/24.0);
//double c2=(0.0/24.0);
double c1=(2250.0/1920.0);
double c2=(125.0/1920.0);
double c3=(9.0/1920.0);

// Global material and dynamic arrays
// Nx padded for 1D domain decomp
// Nz padded for free surface region
//double ***stress,***u;
double **delta,**gauss;
double **velp,**eps;
double **densL,**densU;
double **theta,**stheta2,**ctheta2,**cstheta;
double **dxstheta2,**dxctheta2,**dxcstheta;
double **dzstheta2,**dzctheta2,**dzcstheta;

// Absorbing  boundary constants
int *X_pml;
double ***sxt,***sxb;
double ***szt,***szb;
double ***uxt,***uxb;
double ***uzt,***uzb;
double ***uxa,***uza,***sza,***sxa;
double *dxx , *dzz;

// random constants - no need to be here but in functions
double *sourceX,*sourceY;
double *source,max_vel; 
double dsxxdx,dszzdz;
double dsxxdz,dszzdx;
double dudx,dudz,dvdz,dvdx;

FILE *out_trace[max_traces];

//--------------------------------------------------------------------------------
// MPI Variables
MPI_Comm new_comm;
MPI_Status status;
//const  int  TAG_SEND   = 50;
const  int  ndims      = 1;
int max_nb_of_comm = 512; // maximum number of non blocking comm
MPI_Datatype gcol;
MPI_Datatype fcol;
MPI_Datatype hcol;
int rank,my_rank, size, my_size;
//int dims[1],period[1],reorder;

//--------------------------------------------------------------------------------
// Routines called by the code
#include"READ_PAR_FILE.h"
#include"ALLOCATE.h"
#include"TRANSMIT.h"
#include"INITIAL.h"
#include"BUILD-MODEL.h"
#include"TRACE.h"
#include"SOURCE.h"
#include"UPDATE_VEL.h"
#include"ABSORB_FN.h"
#include"SNAPSHOT.h"
#include"CONVERT_TRACE_2_SEGY.h"
//--------------------------------------------------------------------------------
