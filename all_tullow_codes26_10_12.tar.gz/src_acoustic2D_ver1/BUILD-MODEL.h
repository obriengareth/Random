/////////////////////////////////////////////////////////////


/// loading in four model files
void build()
{
  int i,ii,j,n;
  float aa;
  char file_name[50];
  FILE *input;

//------------------------------------------------------------
/* for(i=0; i<Nx*my_size; i++)
 {
 for(j=0; j<Nzz; j++)
 {
   if(locate_node(i)==my_rank )
   {
     ii=i%Nx;
     eps[ii][j]=0.0;
     delta[ii][j]=0.0;
  }
 }
 }*/

/// Opening and writing in model VP

 max_vel=0.0;
 sprintf(file_name,"%s",input1);
 if(( input = fopen(file_name,"r"))==NULL )
 {
     printf("No VP FILE on node %d: Defaulting to homogenous VP=%lf\n",my_rank,vp);
     max_vel=vp;
 }
 else if(( input = fopen(file_name,"r"))!=NULL )
 {
   for(i=0; i<Nx*my_size; i++)
   {
   for(j=order; j<Nz+order; j++)
   {
      fread(&aa, sizeof(float), 1, input);
      //printf("%d %d %d %f\n",my_rank,i,j,aa);

      if(max_vel<aa)
      max_vel=aa;

      if(locate_node(i)==my_rank )
      {
        ii=i%Nx;
        velp[ii][j]=aa;
      }
   }
   }
   for(i=0; i<Nx; i++)
   {
   for(j=0; j<order; j++)
   {
     velp[i][j]=velp[i][order];
   }
   }
   for(i=0; i<Nx; i++)
   {
   for(j=Nz+order; j<Nzz; j++)
   {
     velp[i][j]=velp[i][Nz+order-1];
   }
   }
   fclose(input); 
 }
/// closing VP input

/// Opening and writing in model density
 sprintf(file_name,"%s",input2);
 if(( input = fopen(file_name,"r"))==NULL )
 {
     printf("No DENSITY FILE on node %d: Defaulting to homogenous density=%lf\n",my_rank,rho);
 }
 else if(( input = fopen(file_name,"r"))!=NULL )
 {
   for(i=0; i<Nx*my_size; i++)
   {
   for(j=order; j<Nz+order; j++)
   {
      fread(&aa, sizeof(float), 1, input);

      if(locate_node(i)==my_rank )
      {
        ii=i%Nx;
        densL[ii][j]=aa;
      }
   }
   }
   for(i=0; i<Nx; i++)
   {
   for(j=0; j<order; j++)
   {
     densL[i][j]=densL[i][order];
   }
   }
   for(i=0; i<Nx; i++)
   {
   for(j=Nz+order; j<Nzz; j++)
   {
     densL[i][j]=densL[i][Nz+order-1];
   }
   }
   fclose(input); 
 }
/// closing dens input
/*
/// Opening and writing in model eps
 sprintf(file_name,"%s",input3);
 if(( input = fopen(file_name,"r"))==NULL )
 {
     printf("No EPS FILE on node %d: Defaulting to homogenous EPS=%lf\n",my_rank,EPS);
 }
 else if(( input = fopen(file_name,"r"))!=NULL )
 {
   for(i=0; i<Nx*my_size; i++)
   {
   for(j=order; j<Nz+order; j++)
   {
      fread(&aa, sizeof(float), 1, input);

      if(locate_node(i)==my_rank )
      {
        ii=i%Nx;
        eps[ii][j]=aa;
      }
   }
   }
   for(i=0; i<Nx; i++)
   {
   for(j=0; j<order; j++)
   {
     eps[i][j]=eps[i][order];
   }
   }
   for(i=0; i<Nx; i++)
   {
   for(j=Nz+order; j<Nzz; j++)
   {
     eps[i][j]=eps[i][Nz+order-1];
   }
   }
   fclose(input); 
 }
/// closing eps input

/// Opening and writing in model delta
 sprintf(file_name,"%s",input4);
 if(( input = fopen(file_name,"r"))==NULL )
 {
     printf("No delta FILE on node %d: Defaulting to homogenous delta=%lf\n",my_rank,DELTA);
 }
 else if(( input = fopen(file_name,"r"))!=NULL )
 {
   for(i=0; i<Nx*my_size; i++)
   {
   for(j=order; j<Nz+order; j++)
   {
      fread(&aa, sizeof(float), 1, input);

      if(locate_node(i)==my_rank )
      {
        ii=i%Nx;
        delta[ii][j]=aa;
      }
   }
   }
   for(i=0; i<Nx; i++)
   {
   for(j=0; j<order; j++)
   {
     delta[i][j]=delta[i][order];
   }
   }
   for(i=0; i<Nx; i++)
   {
   for(j=Nz+order; j<Nzz; j++)
   {
     delta[i][j]=delta[i][Nz+order-1];
   }
   }
   fclose(input); 
 }
/// closing delta input
*/
/////////////////////////////////////////////////////////////////////

  for(i=0; i<Nx; i++)
  {
  for(j=Nzz-order-1; j<Nzz; j++)
  {
     velp[i][j]=330.0;
     densL[i][j]=1.0;
     //eps[i][j]=0.0;
     //delta[i][j]=0.0; 
  }
  }

  densityU();

/////////////////////////////////////////////////////////////////////

}    // End routine

