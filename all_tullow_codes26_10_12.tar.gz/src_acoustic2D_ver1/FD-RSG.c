//  Gareth O'Brien 29/9/2011
// -- Include intrinsic C calls --
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include"mpi.h"
// -- Include subroutines calls --
#include"DEFS.h"

//  MAIN CONTROL LOOP
main(int argc ,char *argv[])
{
 int count,i,j,k;
 double start,finish,t0;

// Starting MPI calls and redefining new communicator
  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);

//command line arguements
  if( argc != 2 )
  {
    printf("INCORRECT USAGE - exe par_file\n");
    MPI_Finalize();  exit(1);
  }
  start=MPI_Wtime();

  create_cartesian_topo();

  read_par_file(argv);
  MPI_Barrier(new_comm);

  create_mpi_data_type();

// Initialising the input parameters to model values
  double stress[Nx+2*order][Nzz];
  double u[Nx+2*order][Nzz][2];

  initial(stress,u);

// Initialising the source
  if(sourcetype<5)
  source_routine();

  build();

  absorb_fn();

// Sorting out the output trace files and locations
  trace_files();

  if(my_rank==0)
  error_output();

  MPI_Barrier(new_comm);
//--------------------------------------------------------------------------------
// Main evolution of the system  
 count=0;
 for(time1=0; time1<=Max_Time; time1++)
 {
// sending halo regions
    transfer_stress(stress);

// stress diff
    diff_stress(stress,u); 

// sending halo regions
    transfer_vel(u);

// vel diff
    diff_vel(stress,u);

// Output snapshots
   if( (time1%snap_freq)==0 && time1>=start_time && count<no_snaps)
   {
     wavefield(stress,u);
     count++;
   }

   if(my_rank==0 && time1%1000==0)
   printf("\t 2D Acoustic Code Time step %d\n",time1);

// Output trace files
   write_trace(stress,u);

 }
////////////////////////////////////////////////////////////////////////////

 close_trace();

 MPI_Barrier(new_comm);
 if(no_snaps!=0)
 {
  merge_wavefield();
 }
 MPI_Barrier(new_comm);

 printf(" OUPUT LR t=%d x=%d %d z=%d\n",lr_count,lr_countx,lr_countx*my_size,lr_countz);
 finish=MPI_Wtime();
 printf(" Time for run on node %d is %lf minutes \n",my_rank,(finish-start)/60);

 if(my_rank==0)
 convert_traces_su();

 MPI_Finalize();

}          // End of main


