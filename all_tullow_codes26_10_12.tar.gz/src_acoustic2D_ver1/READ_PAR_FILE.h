
void read_par_file(char *argv[])
{
  int c,count,i;
  double readin[30];
  char string[50],value;
  char file_name[50];
  FILE *input,*tempout;

  sprintf(string,"%s",argv[1]);
  if(( input= fopen(string,"r")) ==NULL )
  {
    printf("Error opening par file on node %d\n",my_rank);
    MPI_Finalize();
    exit(0);
  }

  sprintf(file_name,"TEMP_PAR%d",my_rank);
  if(( tempout= fopen(file_name,"w")) ==NULL )
  {
    printf("Error opening TEMP_FILE file on node %d\n",my_rank);
    MPI_Finalize();
    exit(0);
  }
  count=0;
  while(( c=getc(input))!=EOF)
  {
     value=c;
     if(count==1)
     {
      fprintf(tempout,"%c",value);
      if(value==' ')
      {
        fprintf(tempout,"\n");
     }
     }
     if(value=='=')
     {
       count=1;
     }
     if(value==' ')
     {
       count=0;
     }
  }
  fclose(input);
  fclose(tempout);

  sprintf(file_name,"TEMP_PAR%d",my_rank);
  if(( input= fopen(file_name,"r")) ==NULL )
  {
     printf("Error opening file on node %d\n",my_rank);
     MPI_Finalize();
     exit(0);
  }

  fscanf(input,"%d\n",&Nx);
  fscanf(input,"%d\n",&Nz);
  fscanf(input,"%lf\n",&dx);
  fscanf(input,"%lf\n",&dt);
  fscanf(input,"%d\n",&Max_Time);

  fscanf(input,"%s\n",&input1);
  fscanf(input,"%s\n",&input9);
  fscanf(input,"%s\n",&input2);
  fscanf(input,"%s\n",&input3);
  fscanf(input,"%s\n",&input4);
  fscanf(input,"%s\n",&input8);

  fscanf(input,"%d\n",&absorb_model);
  fscanf(input,"%d\n",&PMLW);
  fscanf(input,"%lf\n",&vp_pml);
  fscanf(input,"%lf\n",&ndamp);
  fscanf(input,"%lf\n",&Rdamp);

  fscanf(input,"%s\n",&input5);
  fscanf(input,"%s\n",&input6);
  fscanf(input,"%d\n",&NumSource);
  fscanf(input,"%d\n",&sourcetype);
  fscanf(input,"%lf\n",&mxx);
  fscanf(input,"%lf\n",&mzz);
  fscanf(input,"%lf\n",&mxz);

  fscanf(input,"%d\n",&no_trace);
  fscanf(input,"%s\n",&input7);
  fscanf(input,"%s\n",&output1);
  fscanf(input,"%d\n",&kill_all_ascii_traces);

  fscanf(input,"%s\n",&output2);
  fscanf(input,"%d\n",&snap_freq);
  fscanf(input,"%d\n",&start_time);
  fscanf(input,"%d\n",&no_snaps);

  fclose(input);

  remove(file_name);

  Nzz=(Nz+order*2);

if(my_rank==1)
{
  printf("------------------------------------\n",no_snaps);
  printf("Nx \t\t=%d\n",Nx);
  printf("Nz \t\t=%d\n",Nz);
  printf("Nzz \t\t=%d\n",Nzz);
  printf("dx \t\t=%lf\n",dx);
  printf("dt \t\t=%lf\n",dt);
  printf("Max_Time \t=%d\n",Max_Time);

  printf("input1 \t\t=%s\n",input1);
  printf("input2 \t\t=%s\n",input9);
  printf("input3 \t\t=%s\n",input2);
  printf("input4 \t\t=%s\n",input3);
  printf("input5 \t\t=%s\n",input4);
  printf("input6 \t\t=%s\n",input8);

  printf("absorb_model \t=%d\n",absorb_model);
  printf("PMLW \t\t=%d\n",PMLW);
  printf("vp_pml \t\t=%f\n",vp_pml);
  printf("ndamp \t\t=%f\n",ndamp);
  printf("Rdamp \t\t=%f\n",Rdamp);

  printf("input7 \t\t=%s\n",input5);
  printf("input8 \t\t=%s\n",input6);
  printf("source no \t=%d\n",NumSource);
  printf("sourcetype \t=%d\n",sourcetype);
  printf("mxx \t\t=%lf\n",mxx);
  printf("mzz \t\t=%lf\n",mzz);
  printf("mxz \t\t=%lf\n",mxz);


  printf("no_trace \t=%d\n",no_trace);
  printf("input9 \t\t=%s\n",input7);
  printf("output1 \t=%s\n",output1);
  printf("kill_all_ascii \t=%d\n",kill_all_ascii_traces);

  printf("output2 \t=%s\n",output2);
  printf("snap_freq \t=%d\n",snap_freq);
  printf("start_time \t=%d\n",start_time);
  printf("no_snaps \t=%d\n",no_snaps);
}


}
