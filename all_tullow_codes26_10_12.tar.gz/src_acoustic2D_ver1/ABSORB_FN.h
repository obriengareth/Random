
//////////////////////////////////////////////////////////////////////////////////////////////
/// PML absorbing boundary
void absorb_fn()
{
 int i,j,width;
 double xx;

/// zero tapering functions as default
 for(i=0; i<Nx; i++)
 {
  dxx[i]=0.0;
 }
 for(j=0; j<Nzz; j++)
 {
  dzz[j]=0.0;
 }

 width=PMLW;
/// Build taper funtions in both directions according to
/// d(x)=do(x/W)^n
/// do=log(1/R)*(3*vp/2/W)

if(absorb_model==1.0)
{
 /// zzzz
 for(j=0; j<Nzz; j++)
 {
  dzz[j]=0.0;
  if(j<width)
  {
    xx=width*dx-j*dx;
    dzz[j]=log(1.0/Rdamp)*(3.0*vp_pml/2.0/width/dx)*pow(xx/width/dx,ndamp);
  }
  else if(j>Nzz-width)
  {
    xx= j*dx - (Nzz-width)*dx;
    dzz[j]=log(1.0/Rdamp)*(3.0*vp_pml/2.0/width/dx)*pow(xx/width/dx,ndamp);
  }
 }
/// xxxx
 for(i=0; i<Nx; i++)
 {
  dxx[i]=0.0;
  if( (i+my_rank*Nx) < width)
  {
    xx = width*dx - ( i + my_rank*Nx)*dx;
    dxx[i]=log(1.0/Rdamp)*(3.0*vp_pml/2.0/width/dx)*pow(xx/width/dx,ndamp);
  }
  else if( (i+my_rank*Nx) > Nx*(my_size)-width)
  {
    xx = (i + my_rank*Nx)*dx - (Nx*(my_size)-width)*dx;
    dxx[i]=log(1.0/Rdamp)*(3.0*vp_pml/2.0/width/dx)*pow(xx/width/dx,ndamp);
  }
 }

}
else if(absorb_model==2.0)
{
  /// zzzz
 for(j=0; j<Nzz; j++)
 {
  dzz[j]=0.0;
  if(j<width)
  {
    xx=width*dx-j*dx;
    dzz[j]=log(1.0/Rdamp)*(3.0*vp_pml/2.0/width/dx)*pow(xx/width/dx,ndamp);
  }
 }
/// xxxx
 for(i=0; i<Nx; i++)
 {
  dxx[i]=0.0;
  if( (i+my_rank*Nx) < width)
  {
    xx = width*dx - ( i + my_rank*Nx)*dx;
    dxx[i]=log(1.0/Rdamp)*(3.0*vp_pml/2.0/width/dx)*pow(xx/width/dx,ndamp);
  }
  else if( (i+my_rank*Nx) > Nx*(my_size)-width)
  {
    xx = (i + my_rank*Nx)*dx - (Nx*(my_size)-width)*dx;
    dxx[i]=log(1.0/Rdamp)*(3.0*vp_pml/2.0/width/dx)*pow(xx/width/dx,ndamp);
  }
 }
}

/// find nodes with no x pml padding and store in X_pml
 X_pml=alloc1d_int(my_size);
 X_pml[my_rank]=1;
 double sum=0.0;
 for(i=0; i<Nx; i++)
 {
  sum=sum+dxx[i];
 }
 if(sum!=0.0)
 X_pml[my_rank]=0;

//printf("%d %d %e\n",my_rank,X_pml[my_rank],sum);

/// allocate X boundary memory for pml
 if(X_pml[my_rank]==0)
 {
  uxa=alloc3d(Nx,Nzz,2);
  uza=alloc3d(Nx,Nzz,2);
  sxa=alloc2d(Nx,Nzz);
  sza=alloc2d(Nx,Nzz);
 }

}
