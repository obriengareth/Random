////////////////////////////////////////////////////////////////////////////
int *alloc1d_int(int n1)
{
 int *dummy;

 dummy=(int *) calloc(n1,sizeof(int ));
 if (dummy==NULL)
 {
    printf(" Could not allocate memory 1 1d int\n");MPI_Finalize();
    exit(1);
 }
  return dummy;

}

void free_array1d_int(int *a)
{
 free(a);
}

/////////////////////////////////////////////////////////////////////////////

int **alloc2d_int(int n1,int n2)
{
  int i;
  int **dummy;

 dummy=(int **) calloc(n1,sizeof(int *));
 if (dummy==NULL)
 {
    printf(" Could not allocate memory 1 2d int\n");MPI_Finalize();
    exit(1);
 }
 for(i=0; i<n1; i++)
 {
   dummy[i]=(int *) calloc(n2,sizeof(int ));
   if (dummy[i]==NULL)
   {
      printf(" Could not allocate memory 2 2d int\n");MPI_Finalize();
      exit(1);
   }
 }

 return dummy;

}

// Freeing 2d array
void free_array2d_int(int **a)
{
  int i;
 for(i=0; i<Nx; i++)
 {
    free(a[i]);
 }
 free(a);

}
// Freeing 2d array
void free_array2d_int_other(int **dummy)
{
  int i;
 for(i=0; i<Nx*my_size; i++)
 {
    free(dummy[i]);
 }
 free(dummy);

}
/////////////////////////////////////////////////////////////////////////////

int ***alloc3d_int(int n1,int n2,int n3)
{
  int i,j;
  int ***dummy;

 dummy=(int ***) calloc(n1,sizeof(int **));
 if (dummy==NULL)
 {
    printf(" Could not allocate memory 1 3i\n");
    exit(1);
 }
 for(i=0; i<n1; i++)
 {
   dummy[i]=(int **) calloc(n2,sizeof(int *));
   if (dummy[i]==NULL)
   {
      printf(" Could not allocate memory 2 3i\n");
      exit(1);
   }
   for(j=0; j<n2; j++)
   {
    dummy[i][j]=(int *) calloc(n3,sizeof(int ));
    if (dummy[i][j]==NULL)
    {
      printf(" Could not allocate memory 3 3i\n");
      exit(1);
    }
   }
}

 return dummy;

}

// Freeing 2d array
void free_array3d_int(int ***a)
{
  int i,j;
 for(i=0; i<Nx; i++)
 {
   for(j=0; j<Nz; j++)
    free(a[i][j]);
    free(a[i]);
 }
 free(a);

}

/////////////////////////////////////////////////////////////////////////////

double *alloc1d(int n1)
{
 double *dummy;

 dummy=(double *) calloc(n1,sizeof(double ));
 if (dummy==NULL)
 {
    printf(" Could not allocate memory v_1d \n");MPI_Finalize();
    exit(1);
 }
  return dummy;

}

void free_array1d(double *a)
{
 free(a);
}
//////////////////////////////////////////////////////////////////////////////

double **alloc2d(int n1,int n2)
{
  int i;
  double **dummy;

 dummy=(double **) calloc(n1,sizeof(double *));
 if (dummy==NULL)
 {
    printf(" Could not allocate memory 1 v_2d \n");MPI_Finalize();
    exit(1);
 }
 for(i=0; i<n1; i++)
 {
   dummy[i]=(double *) calloc(n2,sizeof(double ));
   if (dummy[i]==NULL)
   {
      printf(" Could not allocate memory 2 v_2d\n");MPI_Finalize();
      exit(1);
   }
 }

 return dummy;

}

// Freeing 2d array
void free_array2d(double **a)
{
  int i;
 for(i=0; i<Nx; i++)
 {
    free(a[i]);
 }
 free(a);

}


////////////////////////////////////////////////////////////////////////////


double ***alloc3d(int n1,int n2,int n3)
{
  int i,j;
  double ***dummy;

 dummy=(double ***) calloc(n1,sizeof(double **));
 if (dummy==NULL)
 {
    printf(" Could not allocate memory 1 3d\n");
    exit(1);
 }
 for(i=0; i<n1; i++)
 {
   dummy[i]=(double **) calloc(n2,sizeof(double *));
   if (dummy[i]==NULL)
   {
      printf(" Could not allocate memory 2 3d\n");
      exit(1);
   }
   for(j=0; j<n2; j++)
   {
    dummy[i][j]=(double *) calloc(n3,sizeof(double ));
    if (dummy[i][j]==NULL)
    {
      printf(" Could not allocate memory 3 3d\n");
      exit(1);
    }
   }
}

  return dummy;

}


void free_array3d(double ***a)
{
  int i,j;
 for(i=0; i<Nx; i++)
 {
   for(j=0; j<Nz; j++)
    free(a[i][j]);
    free(a[i]);
 }
 free(a);

}

/////////////////////////////////////////////////////////////////////////////////

double ****alloc4d(int n1,int n2,int n3,int n4)
{
  int i,j,k;
  double ****dummy;

 dummy=(double ****) calloc(n1,sizeof(double ***));
 if (dummy==NULL)
 {
    printf(" Could not allocate memory 1 4d\n");
    exit(1);
 }
 for(i=0; i<n1; i++)
 {
    dummy[i]=(double ***) calloc(n2,sizeof(double **));
    if (dummy[i]==NULL)
    {
      printf(" Could not allocate memory 2 4d \n");
      exit(1);
    }
  for(j=0; j<n2; j++)
  {
     dummy[i][j]=(double **) calloc(n3,sizeof(double *));
     if (dummy[i][j]==NULL)
     {
      printf(" Could not allocate memory 3 4d\n");
      exit(1);
     }
   for(k=0; k<n3; k++)
   {
     dummy[i][j][k]=(double *) calloc(n4,sizeof(double ));
     if (dummy[i][j][k]==NULL)
     {
       printf(" Could not allocate memory 4 4d\n");
       exit(1);
     }
   } //k
  }  //j
 }   //i

   return dummy;
}  //end function

void free_array4d(double ****a)
{
  int i,j,k;

 for(i=0; i<3; i++)
 {
  for(j=0; j<Nx; j++)
  {
    for(k=0; k<Nz; k++)
    {
    free(a[i][j][k]);
    }
    free(a[i][j]);
  }
    free(a[i]);
 }
 free(a);

}

////////////////////////////////////////////////////////////////////////////////////
