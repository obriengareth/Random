
// Outputs snap shots of the wavefield ever snap_freq time steps
void wavefield(double stress[Nx+2*order][Nzz],double u[Nx+2*order][Nzz][2])
{
   int i,j,k;
   char file_name[50];
   FILE *output;

 sprintf(file_name,"TEMP%d_%d",time1,my_rank);
 if(( output= fopen(file_name,"w")) ==NULL )
 {
   printf("Error opening snap file on node %d at time %d\n",my_rank,time1);
   MPI_Finalize();
   exit(0);
 }

 for(i=order; i<Nx+order; i=i+LR)
 {
 for(j=order; j<Nz+order; j=j+LR)
 {
    fprintf(output,"%e %e %e\n",u[i][j][0],u[i][j][1],(stress[i][j]) );
 }
 }
 fclose(output);

}

void merge_wavefield()
{
   int i,j,n,l;
   double a,b,c,aa[3];
   char file_name[50];
   FILE *output,*input[my_size];

for(n=0; n<no_snaps; n++)
{
 if(my_rank==0)
 {
    l=start_time+snap_freq*n;
    sprintf(file_name,"%s%d",output2,l);
    if(( output = fopen(file_name,"w")) ==NULL )
    {
       printf("Error opening snap file on node %d at time %d\n",my_rank,time1);
       MPI_Finalize();
       exit(0);
    }
    for(j=0; j<my_size; j++)
    {
        sprintf(file_name,"TEMP%d_%d",l,j);
	if(( input[j] = fopen(file_name,"r")) ==NULL )
        {
          printf("Error merging file %s on node %d\n",file_name,j);
          MPI_Finalize();
          exit(0);
        }
     // }
      for(i=0;i<lr_count; i++)
      {
        fscanf(input[j],"%lf %lf %lf\n",&a,&b,&c);
	aa[0]=a; aa[1]=b;  aa[2]=c;
        fwrite(&aa, sizeof(double), 3, output);
      }

    }

    for(i=0; i<my_size; i++)
    {
      sprintf(file_name,"TEMP%d_%d",l,i);
      remove(file_name);
    }
    fclose(output);
  }

}

}    // end of routine

