
/////////////////////////////////////////////////////////////
// Locates the node given the coordinate
int locate_node(int coord)
{
 int i,node;

 for(i=0; i<my_size; i++)
 {
   if( coord < ((Nx)*i+Nx) && coord >= (Nx*i) )
   {
     node=i;
   }
 }
 return node;

}

// Initiallising variables routine
void initial(double stress[Nx+2*order][Nzz],double u[Nx+2*order][Nzz][2])
{
  int i,j;

  alpha=dx*6.0;

  //stress = alloc3d(Nx+2*order,Nzz,2);
  //     u = alloc3d(Nx+2*order,Nzz,2);
   //delta = alloc2d(Nx,Nzz);
   gauss = alloc2d(Nx,Nzz);
    velp = alloc2d(Nx,Nzz);
     //eps = alloc2d(Nx,Nzz);
   densL = alloc2d(Nx,Nzz);
   densU = alloc2d(Nx,Nzz);

   sxt = alloc2d(Nx,PMLW);
   sxb = alloc2d(Nx,PMLW);
   szt = alloc2d(Nx,PMLW);
   szb = alloc2d(Nx,PMLW);
   uxt = alloc3d(Nx,PMLW,2);
   uxb = alloc3d(Nx,PMLW,2);
   uzt = alloc3d(Nx,PMLW,2);
   uzb = alloc3d(Nx,PMLW,2);

   dxx = alloc1d(Nx);
   dzz = alloc1d(Nzz);

  // Zeroing grids
  for(i=0; i<Nx; i++)
  {
  for(j=0; j<Nzz; j++)
  {
    velp[i][j]=vp;
    densL[i][j]=rho;
    densU[i][j]=0.0;
    //eps[i][j]=EPS;
    //delta[i][j]=DELTA;

    u[i][j][0]=0.0;
    u[i][j][1]=0.0;

    stress[i][j]=0.0;
  }
  }
  for(i=Nx; i<Nx+2*order; i++)
  {
  for(j=0; j<Nzz; j++)
  {
    u[i][j][0]=0.0;
    u[i][j][1]=0.0;

    stress[i][j]=0.0;
  }
  }

///-------------------------------------------------------------

  lr_count=lr_countx=lr_countz=0;
  for(j=0; j<Nx; j=j+LR)
  {
    lr_countx++;
    lr_countz=0;
  for(i=0; i<Nz; i=i+LR)
  {
     lr_countz++;
     lr_count++;
  }
  }

///-------------------------------------------------------------

}    // End or routine


///-------------------------------------------------------------

void error_output()
{
  double dtmax; 

  printf("------------------------------------------\n");
  printf("--------------ERROR CHECKS----------------\n");

  dtmax=dx/max_vel*0.4;
  printf("CFL Stability dt < 0.4 dx/max_vel\n");
  printf("CFL Stability %lf < %lf\n",dt,dtmax);

  if(dtmax<dt)
  {
     printf("stability error CFL dt=%lf Input dt=%lf\n",dtmax,dt);
     MPI_Finalize();
     exit(0);
  }
  printf("REQUIRE 5 grid points per minimum wavelength for near field propagation\n");
 
  if(PMLW < order*2)
  {
   PMLW=2*order;
   printf("PMLW layer too small - dsetting to default. This won't effect par_file inputs\n");
  }

  if(no_trace>max_traces)
  {
   no_trace=max_traces;
   printf("Too many traces - changing to default value\n");
  }

  if( no_snaps!=0 && ( (no_snaps-1)*snap_freq+start_time)>Max_Time )
  {
   snap_freq= floor( (Max_Time-start_time)/no_snaps );
   printf("snaps exceed run time: changing to snap_freq=%d\n",snap_freq);
  }
  printf("------------------------------------------\n");

}

///-------------------------------------------------------------

