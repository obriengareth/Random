
// Source Routine
void source_routine()
{
 int time_loop,i,j,n;
 FILE *input,*out_source,*inputb;
 char file_name[50];

 source=alloc1d(Max_Time);
 sourceX=alloc1d(Max_Time); 
 sourceY=alloc1d(Max_Time);

 sprintf(file_name,"%s",input5); 
 if(( input = fopen(file_name,"r")) ==NULL )
 {
     printf("Error 1001: opening source file on node %d\n",my_rank);
     MPI_Finalize();
     exit(0);
 }
 for(time_loop=0; time_loop<Max_Time; time_loop++)
 {
   source[time_loop]=0;
   fscanf(input,"%lf\n",&source[time_loop]);
 }
 for(time_loop=0; time_loop<Max_Time; time_loop++)
 {
   source[time_loop] = source[time_loop];
 }
 fclose(input);

/////////////////////////////////////////////////////////////////////

 int aa,bb;
 xsource=alloc1d_int(NumSource);
 zsource=alloc1d_int(NumSource);

 if(( inputb= fopen(input6,"r")) == NULL )
 {
     printf("Error 1002: opening source file on node %d\n",my_rank);
     MPI_Finalize();
     exit(0);
 }

 for(i=0; i<NumSource; i++)
 {
  fscanf(inputb,"%d %d\n",&aa,&bb); 
  xsource[i]=floor(aa/dx);
  zsource[i]=floor(bb/dx);
 }
 fclose(inputb);
//////////////////////////////////////////////////////////////////////
  for(time_loop=0; time_loop<Max_Time; time_loop++)
  {
    sourceX[time_loop]=0.0;
    sourceY[time_loop]=0.0;
  }

  if( sourcetype==1 )
  {
    for(time_loop=0; time_loop<Max_Time; time_loop++)
    {
         sourceX[time_loop]=source[time_loop];
         source[time_loop]=0.0;
    }
  }
  if( sourcetype==2 )
  {
    for(time_loop=0; time_loop<Max_Time; time_loop++)
    {
         sourceY[time_loop]=source[time_loop];
         source[time_loop]=0.0;
    }
  }
//////////////////////////////////////////////////////////////////////

for(i=0; i<Nx; i++)
{
for(j=0; j<Nzz; j++)
{
  gauss[i][j]=0.0;
}
}
alpha=4.5*dx;

for(n=0; n<NumSource; n++)
{
for(i=0; i<Nx; i++)
{
for(j=order; j<Nzz-order; j++)
{
  gauss[i][j]=gauss[i][j]+Gauss( dx*(xsource[n]-i-Nx*my_rank),dx*(zsource[n]-(j-order)),alpha);
}
}
}
for(i=0; i<Nx; i++)
{
for(j=0; j<Nzz; j++)
{
  gauss[i][j]=gauss[i][j]/NumSource;
}
}
//printf(" %d %d\n",xsource,zsource);

}

/*
void explosive_source(double stress[Nx+2*order][Nzz][2])
{
  int i,j,k;

  for(i=0; i<Nx; i++)
  {
  for(j=order; j<Nz+order; j++)
  {
    stress[i+order][j][0]=stress[i+order][j][0] + gauss[i][j]*source[time1];
    stress[i+order][j][1]=stress[i+order][j][1] + gauss[i][j]*source[time1];
  }
  }
 
}

void force_source(double u[Nx+2*order][Nzz][2])
{
 int i,j,k;

  for(i=0; i<Nx; i++)
  {
  for(j=order; j<Nz+order; j++)
  { 
    if(sourcetype==1 )
    u[i+order][j][0]=u[i+order][j][0]+gauss[i][j]*source[time1]*(dt/densU[i][j]);
    
    if(sourcetype==2 )
    u[i+order][j][1]=u[i+order][j][1]+gauss[i][j]*source[time1]*(dt/densU[i][j]);
  }
  }
 
}*/

////////////////////////////////////////////////////////////////////////////////////////////////

