
//////////////////////////////////////////////////////////////////////////////////////////////////
// Constants and functions
#define Gauss(x,y,z,a)  exp( -(x*x+y*y+z*z)/(a*a) ) 
#define Max(x,y) ( (x)>=(y)  ?  (x) : (y) )
#define Min(x,y) ( (x)<=(y)  ?  (x) : (y) )
#define order 4
#define vp                   (1500.00)      // Homo p-wave speed
#define rho                  (1000.00)      // Homo density
#define EPS                  (0.0)      // Homo eps
#define DELTA                (0.0)      // Homo delta
#define THETA                (0.0)      // Homo theta
#define max_traces           (512)

double PI=(3.14159265);

//////////////////////////////////////////////////////////////////////////////////////////////////

//definitions of moving between real and grid coordinates
// Nx = (int) ceil(LX/dx/my_size) + ceil(2*Width/my_size);
// Ny = (int) ceil(LY/dx)  + 2*Width;
// Nz = (int) ceil(LZ/dz)  + 2*Width;

// Nxx = (int) ceil(LX/dx/my_size) + ceil(2*Width/my_size) + order*2 ;
// Nyy = (int) ceil(LY/dx) + 2*Width + order*2;
// Nzz = (int) ceil(LZ/dz) + 2*Width + order*2;

#define Nxx1 (Nx1+2*order)
#define Nyy1 (Ny1+2*order)
#define Nzz1 (Nz1+2*order)

//////////////////////////////////////////////////////////////////////////////////////////////////
// model parameters used in code
int time1,NoVelPts;
int Max_Time,no_trace; 
int Nxx,Nyy,Nzz,Nx,Ny,Nz;
double alpha,max_vel;

//////////////////////////////////////////////////////////////////////////////////////////////////
// FD 2nd Central grid operators
//double c1=(0.5);
//double c2=(0.0);
//double c3=(0.0);
//double c4=(0.0);

// FD 4th Central grid operators
//double c1=(2.00/3.0);
//double c2=(-1.0/12.0);
//double c3=(0.0);
//double c4=(0.0);

// FD 6th Central grid operators
//double c1=(3.00/4.0);
//double c2=(-3.0/20.0);
//double c3=(1.00/60.0);
//double c4=(0.00);

// FD 8th Central grid operators
//double c1=(4.00/5.0);
//double c2=(-1.0/5.0);
//double c3=(4.00/105.0);
//double c4=(-1.0/280.0);

//////////////////////////////////////////////////////////////////////////////////////////////////
// FD 2nd RSG
//double c1=0.25*(1.0);
//double c2=0.25*(0.0);
//double c3=0.25*(0.0);
//double c4=0.25*(0.0);

// FD 4th RSG
//double c1=0.25*(9.00/8.0);
//double c2=0.25*(-1.0/24.0);
//double c3=0.25*(0.00);
//double c4=0.25*(0.00);

// FD 6th RSG
//double c1=0.25*(75.00/64.0);
//double c2=0.25*(-25.0/384.0);
//double c3=0.25*(3.000/640.0);
//double c4=0.25*(0.000);

// FD 8th RSG
double c1=0.25*(1225.0/1024.0);
double c2=0.25*(-245.0/3072.0);
double c3=0.25*(49.000/5120.0);
double c4=0.25*(-5.000/7168.0);

//////////////////////////////////////////////////////////////////////////////////////////////////

// material and dynamic arrays
double ***dens;
double ***velp;
double ***delta,***eps;
double ***theta,***phi;

double u[Nxx1][Nyy1][Nzz1][3];
double stress[Nxx1][Nyy1][Nzz1][2];
double R[Nxx1][Nyy1][Nzz1][9];

// TTI derivatives of rotation matrix
double ***dr00dx, ***dr11dx,***dr22dx,***dr03dx,***dr14dx,***dr06dx,***dr17dx,***dr28dx,***dr25dx;
double ***dr03dy, ***dr14dy,***dr25dy,***dr33dy,***dr44dy,***dr55dy,***dr36dy,***dr47dy,***dr58dy; 
double ***dr06dz, ***dr17dz,***dr28dz,***dr36dz,***dr47dz,***dr58dz,***dr66dz,***dr77dz,***dr88dz;

// boundary constants
double *dxx ,*dyy, *dzz;

// Source variables
double *sourceX,*sourceY,*sourceZ,*source,***gauss;
int NumSource;
int *xsource,*ysource,*zsource;
int *x_coord,*y_coord,*z_coord,no_trace;

// random constants - no need to be here can put in functions
double dsxxdx,dszzdx;
double dsxxdy,dszzdy;
double dsxxdz,dszzdz;
double dudx,dudy,dudz;
double dvdx,dvdy,dvdz;
double dwdx,dwdy,dwdz;

// I/O variables
int no_snap,count_snaps;
int lr_count,lr_countx,lr_county,lr_countz;
FILE *out_trace[max_traces];
//////////////////////////////////////////////////////////////////////////////////////////////////

// MPI Variables
MPI_Comm new_comm;
MPI_Status status;
const  int  ndims      = 1;
int max_nb_of_comm = 1024; // maximum number of non blocking comm
MPI_Datatype Xcol1;
MPI_Datatype Xcol2;
MPI_Datatype Xcol3;
MPI_Datatype Xcol4;
int rank,my_rank, size, my_size;
int dims[1],periods[1],reorder;
//////////////////////////////////////////////////////////////////////////////////////////////////

// Routines called by the code
#include"FUNCTIONS.h"
#include"TRANSMIT.h"
#include"BUILD-MODEL.h"
#include"TRACE.h"
#include"SOURCE.h"
//#include"UPDATE_VEL.h"
#include"UPDATE_VEL_RSG.h"
#include"ABSORB_FN.h"
#include"SNAPSHOT.h"
//#include"CONVERT_TRACE_2_SEGY.h"
//////////////////////////////////////////////////////////////////////////////////////////////////

