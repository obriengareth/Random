
// Source Routine
void source_routine()
{
 int time_loop,i,j,k,n;
 double max_so;
 FILE *input,*out_source;
 char file_name[50];

// allocating source time function
 source=alloc1d(Max_Time);
 //sourceX=alloc1d(Max_Time); 
 //sourceY=alloc1d(Max_Time);

// loading in source time function
 max_so=0.0;
 sprintf(file_name,"%s",input6); 
 if(( input = fopen(file_name,"r")) ==NULL )
 {
     printf("Error 1001: opening source file on node %d\n",my_rank);
     MPI_Finalize();
     exit(0);
 }
 for(time_loop=0; time_loop<Max_Time; time_loop++)
 {
   source[time_loop]=0;
   fscanf(input,"%lf\n",&source[time_loop]);

   if(max_so<fabs(source[time_loop]))
   max_so=fabs(source[time_loop]);

 }
 fclose(input);

// opening in source locations
// counting number of sources
 int c,fileLen,count;
 double aa,bb,cc;
 char value;

 if(( input= fopen(input7,"r")) == NULL )
 {
     printf("Error 1002: opening source file on node %d\n",my_rank);
     MPI_Finalize();
     exit(0);
 }

 count=0;
 while(( c=getc(input))!=EOF)
 {
    value=c;
    if(value=='\n')
    count++;
 }
 NumSource=count;
 xsource=alloc1d_int(NumSource);
 ysource=alloc1d_int(NumSource);
 zsource=alloc1d_int(NumSource);
 fclose(input);

// loading source locations
 if(( input= fopen(input7,"r")) == NULL )
 {
     printf("Error 1003: opening source file on node %d\n",my_rank);
     MPI_Finalize();
     exit(0);
 }
 for(i=0; i<NumSource; i++)
 {
  fscanf(input,"%lf %lf %lf\n",&aa,&bb,&cc); 
  xsource[i]=(int) ((aa-OX)/dx)+Width;
  ysource[i]=(int) ((bb-OY)/dx)+Width;
  zsource[i]=(int) Nz-Width-((cc-OZ)/dz) -1;
 }
 fclose(input);

 for(i=0; i<NumSource; i++)
 {
  if( xsource[i]<0 || xsource[i]>=Nxx*my_size || ysource[i]<0 || ysource[i]>=Nyy || zsource[i]<0 || zsource[i]>=Nzz )
  {
   xsource[i]=0;
   ysource[i]=0;
   zsource[i]=0;
  }
 }

if(my_rank==0)
{
printf("-------------------------------------------\n");
printf("Outputting source grid coordinates\n");
for(i=0; i<NumSource; i++)
printf("%d %d %d\n",xsource[i],ysource[i],zsource[i]);
printf("-------------------------------------------\n");
}

/////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
 /* for(time_loop=0; time_loop<Max_Time; time_loop++)
  {
    sourceX[time_loop]=0.0;
    sourceY[time_loop]=0.0;
  }*/

  /*if( sourcetype==1 )
  {
    for(time_loop=0; time_loop<Max_Time; time_loop++)
    {
         sourceX[time_loop]=source[time_loop];
         source[time_loop]=0.0;
    }
  }
  if( sourcetype==2 )
  {
    for(time_loop=0; time_loop<Max_Time; time_loop++)
    {
         sourceY[time_loop]=source[time_loop];
         source[time_loop]=0.0;
    }
  }*/

//////////////////////////////////////////////////////////////////////
// allocating gaussian volume for source
 gauss = alloc3d(Nx,Ny,Nz);
 double alpha=4.5*dx;

 for(n=0; n<NumSource; n++)
 {
  for(i=0; i<Nx; i++)
  {
  for(j=0; j<Ny; j++)
  {
  for(k=0; k<Nz; k++)
  {
    // Gaussian 3D pulse for source implementation
    gauss[i][j][k]=gauss[i][j][k]+dens[i][j][k]*Gauss( dx*(xsource[n]-i-Nx*my_rank),dx*(ysource[n]-(j)),dz*(zsource[n]-(k)),alpha);

    // to avoid generation of source S-waves set epsilon=delta
    /*if(gauss[i][j][k]>=0.05)
    {
      // delta[i][j][k]=eps[i][j][k];
    }*/
  }
  }
  }
 }

 /*for(i=0; i<Nx; i++)
 {
 for(j=0; j<Ny; j++)
 {
 for(k=0; k<Nz; k++)
 {
   if(velp[i][j][k]==0.0)
   {
    gauss[i][j][k]=0.0;
   }
 }
 }
 }*/

}
////////////////////////////////////////////////////////////////////////////////////////////////

/*
void explosive_source()
{
  int i,ii,j,k,n;

  for(i=0; i<Nx; i++)
  {
  for(j=0; j<Ny; j++)
  {
  for(k=0; k<Nz; k++)
  {
    stress[i+order][j+order][k+order][0]=stress[i+order][j+order][k+order][0] + gauss[i][j][k]*source[time1]*sscale;
    stress[i+order][j+order][k+order][1]=stress[i+order][j+order][k+order][1] + gauss[i][j][k]*source[time1]*sscale;
  }
  }
  }

}
*/
////////////////////////////////////////////////////////////////////////////////////////////////
/*
void force_source()
{
 int i,ii,j,k,n;

  for(n=0; n<NumSource; i++)
  {
    i=xsource[n];    j=ysource[n];    k=zsource[n];
    if(locate_node(i)==my_rank)
    {
     ii=i%Nx;
     //u[ii+order][j+order][k+order][0] = u[ii+order][j+order][k+order][0] + source[time1];
     //u[ii+order][j+order][k+order][1] = u[ii+order][j+order][k+order][1] + source[time1];
     u[ii+order][j+order][k+order][2] = u[ii+order][j+order][k+order][2] + source[time1];
    }
  }

}
*/
////////////////////////////////////////////////////////////////////////////////////////////////

