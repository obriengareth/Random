

////////////////////////////////////////////////////////////////
// Open trace files and locate them correctly
void trace_files()
{
  int i,c,fileLen,count,no;
  double aa,bb,cc;
  char value,file_name[50];
  FILE *input; 


////////////////////////////////////////////////////////////////////////////////
// Allocate correct memory
 if(( input= fopen(input8,"r")) == NULL )
 {
     printf("Error 2001: opening source file on node %d\n",my_rank);
     MPI_Finalize();
     exit(0);
 }
 count=0;
 while(( c=getc(input))!=EOF)
 {
    value=c;
    if(value=='\n')
    count++;
 }
 no_trace=count;
 fclose(input);
 x_coord = alloc1d_int(no_trace);
 y_coord = alloc1d_int(no_trace);
 z_coord = alloc1d_int(no_trace);

////////////////////////////////////////////////////////////////////////////////
// open recorder files and input locations

 sprintf(file_name,"%s",input8);
 if(( input= fopen(file_name,"r"))==NULL )
 {
     printf("Error 2002: opening input rec file on node %d\n",my_rank);
     MPI_Finalize();
    exit(0);
 }

 for(i=0; i<no_trace; i++)
 {
    fscanf(input,"%lf %lf %lf\n",&aa,&bb,&cc);
    x_coord[i]=(int) ((aa-OX)/dx) + Width;
    y_coord[i]=(int) ((bb-OY)/dx) + Width;
    z_coord[i]=(int) Nz-Width-((cc-OZ)/dz) -1;

    //printf("%d %d %d\n",x_coord[i],y_coord[i],z_coord[i]);
 }

 if(my_rank==0)printf("-------------------------------------------\n");
 if(my_rank==0)printf("Outputting recorder grid coordinates\n");
 for(i=0; i<no_trace; i++)
 {
   if( x_coord[i]<0 || x_coord[i]>=Nxx*my_size || y_coord[i]<0 || y_coord[i]>=Nyy || z_coord[i]<0 || z_coord[i]>=Nzz )
   {
    x_coord[i]=0;
    y_coord[i]=0;
    z_coord[i]=0;
   }

   if(my_rank==0)
   printf("%d %d %d\n",x_coord[i],y_coord[i],z_coord[i]);
 }
 fclose(input);
 if(my_rank==0)printf("-------------------------------------------\n");

////////////////////////////////////////////////////////////////////////////////
// opening recorder files

 for(i=0; i<no_trace; i++)
 {
    if(locate_node(x_coord[i])==my_rank)
    {
     sprintf(file_name,"%s%d",output1,i);
     if(( out_trace[i]= fopen(file_name,"w")) ==NULL )
     {
         printf("Error 2003: opening trace file on node %d\n",my_rank);
         MPI_Finalize();
         exit(0);
     }
    }
    //printf("%d %d %d\n",x_coord[i],y_coord[i],z_coord[i]);
 }

}     // End of Routine


// Writing the correct trace position to correct file
void write_trace()
{
  int i,ii,j,k,n;
  double pressure;

  for(n=0; n<no_trace; n++)
  {
    i=x_coord[n]; j=y_coord[n];  k=z_coord[n];

    if(locate_node(i)==my_rank)
    {
     ii=i%Nx;
     pressure=stress[ii+order][j+order][k+order][0]+stress[ii+order][j+order][k+order][1];

      /*printf(" %e %e %e %e \n",u[ii+order][j+order][k+order][0],
                                            u[ii+order][j+order][k+order][1],
                                            u[ii+order][j+order][k+order][2],pressure );*/

     fprintf(out_trace[n],"%e %e %e %e\n",u[ii+order][j+order][k+order][0],
                                          u[ii+order][j+order][k+order][1],
                                          u[ii+order][j+order][k+order][2],pressure );
    }
  }

}  // End of Routine


// Closing files
void close_trace()
{
  int i;

  for(i=0; i<no_trace; i++)
  {
    if(locate_node(x_coord[i])==my_rank)
    {
      fclose(out_trace[i]);
    }
  }

}     // End of routine



