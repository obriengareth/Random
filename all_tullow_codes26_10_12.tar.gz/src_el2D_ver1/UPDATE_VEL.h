/// main routine for diff stress amnd velocity
/*
  // 4th order rsg
    dsxxdx=da*c1*(stress[0][i][j-1]   -stress[0][i-1][j]   +stress[0][i][j]      -stress[0][i-1][j-1])
          -da*c2*(stress[0][i+1][j-2]-stress[0][i-2][j+1]+stress[0][i+1][j+1]-stress[0][i-2][j-2]);

    dszzdz=da*c1*(stress[1][i][j]      -stress[1][i-1][j-1]+stress[1][i-1][j]   -stress[1][i][j-1])
          -da*c2*(stress[1][i+1][j+1]-stress[1][i-2][j-2]+stress[1][i-2][j+1]-stress[1][i+1][j-2]);

  // 6th order rsg
    dsxxdx=da*c1*(stress[i][j-1][0]   - stress[i-1][j][0]   + stress[i][j][0] -stress[i-1][j-1][0])
            -da*c2*(stress[i+1][j-2][0] - stress[i-2][j+1][0] + stress[i+1][j+1][0]-stress[i-2][j-2][0])
            +da*c3*(stress[i+2][j-3][0] - stress[i-3][j+2][0] + stress[i+2][j+2][0]-stress[i-3][j-3][0]);

    dszzdz=da*c1*(stress[i][j][1]     -stress[i-1][j-1][1]+stress[i-1][j][1]   -stress[i][j-1][1])
          -da*c2*(stress[i+1][j+1][1] -stress[i-2][j-2][1]+stress[i-2][j+1][1] -stress[i+1][j-2][1])
          +da*c3*(stress[i+2][j+2][1] -stress[i-3][j-3][1]+stress[i-3][j+2][1] -stress[i+2][j-3][1]);
*/

// Diff of the velocities to get the stress
void diff_stress(double stress[Nx+2*order][Nzz][3],double u[Nx+2*order][Nzz][2])
{
 int i,j,jj;
 double da=0.5/dx,x1,z1;
 double c11,c22,c33;
// double sxx,szz;
// double ctheta2a,stheta2a,csthetaa;

 c11=da*c1;
 c22=-da*c2;
 c33=da*c3;

if(X_pml[my_rank]==1)
{
////////////////////////////////////////////////////////////////////////////
 for(i=order; i<Nx+order; i++)
 {
 for(j=PMLW; j<Nzz-PMLW; j++)
 {
    // 6th order rsg
    dsxxdx=  c11*(stress[i][j-1][0]   - stress[i-1][j][0]   + stress[i][j][0] -stress[i-1][j-1][0])
            +c22*(stress[i+1][j-2][0] - stress[i-2][j+1][0] + stress[i+1][j+1][0]-stress[i-2][j-2][0])
            +c33*(stress[i+2][j-3][0] - stress[i-3][j+2][0] + stress[i+2][j+2][0]-stress[i-3][j-3][0]);

    dszzdz= c11*(stress[i][j][1]     -stress[i-1][j-1][1]+stress[i-1][j][1]   -stress[i][j-1][1])
           +c22*(stress[i+1][j+1][1] -stress[i-2][j-2][1]+stress[i-2][j+1][1] -stress[i+1][j-2][1])
           +c33*(stress[i+2][j+2][1] -stress[i-3][j-3][1]+stress[i-3][j+2][1] -stress[i+2][j-3][1]);

    dsxzdx=  c11*(stress[i][j-1][2]   - stress[i-1][j][2]   + stress[i][j][2] -stress[i-1][j-1][2])
            +c22*(stress[i+1][j-2][2] - stress[i-2][j+1][2] + stress[i+1][j+1][2]-stress[i-2][j-2][2])
            +c33*(stress[i+2][j-3][2] - stress[i-3][j+2][2] + stress[i+2][j+2][2]-stress[i-3][j-3][2]);

    dsxzdz= c11*(stress[i][j][2]     -stress[i-1][j-1][2]+stress[i-1][j][2]   -stress[i][j-1][2])
           +c22*(stress[i+1][j+1][2] -stress[i-2][j-2][2]+stress[i-2][j+1][2] -stress[i+1][j-2][2])
           +c33*(stress[i+2][j+2][2] -stress[i-3][j-3][2]+stress[i-3][j+2][2] -stress[i+2][j-3][2]);


    u[i][j][0] = u[i][j][0] 
               + dt*( dsxxdx + dsxzdz )/densU[i-order][j]
               + gauss[i-order][j]*sourceX[time1];

    u[i][j][1] = u[i][j][1] 
               + dt*( dsxzdx + dszzdz )/densU[i-order][j]
               + gauss[i-order][j]*sourceY[time1];

  }
  }
////////////////////////////////////////////////////////////////////////////
 for(i=order; i<Nx+order; i++)
 {
 for(j=Nzz-PMLW; j<Nzz-order; j++)
 {
     // 6th order rsg
    dsxxdx=  c11*(stress[i][j-1][0]   - stress[i-1][j][0]   + stress[i][j][0] -stress[i-1][j-1][0])
            +c22*(stress[i+1][j-2][0] - stress[i-2][j+1][0] + stress[i+1][j+1][0]-stress[i-2][j-2][0])
            +c33*(stress[i+2][j-3][0] - stress[i-3][j+2][0] + stress[i+2][j+2][0]-stress[i-3][j-3][0]);

    dszzdz= c11*(stress[i][j][1]     -stress[i-1][j-1][1]+stress[i-1][j][1]   -stress[i][j-1][1])
           +c22*(stress[i+1][j+1][1] -stress[i-2][j-2][1]+stress[i-2][j+1][1] -stress[i+1][j-2][1])
           +c33*(stress[i+2][j+2][1] -stress[i-3][j-3][1]+stress[i-3][j+2][1] -stress[i+2][j-3][1]);

    dsxzdx=  c11*(stress[i][j-1][2]   - stress[i-1][j][2]   + stress[i][j][2] -stress[i-1][j-1][2])
            +c22*(stress[i+1][j-2][2] - stress[i-2][j+1][2] + stress[i+1][j+1][2]-stress[i-2][j-2][2])
            +c33*(stress[i+2][j-3][2] - stress[i-3][j+2][2] + stress[i+2][j+2][2]-stress[i-3][j-3][2]);

    dsxzdz= c11*(stress[i][j][2]     -stress[i-1][j-1][2]+stress[i-1][j][2]   -stress[i][j-1][2])
           +c22*(stress[i+1][j+1][2] -stress[i-2][j-2][2]+stress[i-2][j+1][2] -stress[i+1][j-2][2])
           +c33*(stress[i+2][j+2][2] -stress[i-3][j-3][2]+stress[i-3][j+2][2] -stress[i+2][j-3][2]);

     jj=j-Nzz+PMLW;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

     uxt[i-order][jj][0]=(1.0/x1)*( uxt[i-order][jj][0]/dt - 0.5*dxx[i-order]*uxt[i-order][jj][0] 
                    +( dsxxdx )/densU[i-order][j] );

     uzt[i-order][jj][0]=(1.0/z1)*( uzt[i-order][jj][0]/dt - 0.5*dzz[j]*uzt[i-order][jj][0]
                    +( dsxzdz )/densU[i-order][j]  );

     u[i][j][0] = uxt[i-order][jj][0] + uzt[i-order][jj][0] + gauss[i-order][j]*sourceX[time1];


     uxt[i-order][jj][1]=(1.0/x1)*(uxt[i-order][jj][1]/dt - 0.5*dxx[i-order]*uxt[i-order][jj][1]
                    +( dsxzdx )/densU[i-order][j] );

     uzt[i-order][jj][1]=(1.0/z1)*(uzt[i-order][jj][1]/dt - 0.5*dzz[j]*uzt[i-order][jj][1] 
                    +( dszzdz )/densU[i-order][j]  );

     u[i][j][1] = uxt[i-order][jj][1] + uzt[i-order][jj][1] + gauss[i-order][j]*sourceY[time1];

  }
  }
////////////////////////////////////////////////////////////////////////////
 for(i=order; i<Nx+order; i++)
 {
 for(j=Nzz-order; j<Nzz; j++)
 {
     dsxxdx=0.0;
     dszzdz=0.0;
     dsxzdz=0.0;
     dsxzdx=0.0;

     jj=j-Nzz+PMLW;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

     uxt[i-order][jj][0]=(1.0/x1)*( uxt[i-order][jj][0]/dt - 0.5*dxx[i-order]*uxt[i-order][jj][0] 
                    +( dsxxdx )/densU[i-order][j] );

     uzt[i-order][jj][0]=(1.0/z1)*( uzt[i-order][jj][0]/dt - 0.5*dzz[j]*uzt[i-order][jj][0]
                    +( dsxzdz )/densU[i-order][j]  );

     u[i][j][0] = uxt[i-order][jj][0] + uzt[i-order][jj][0] + gauss[i-order][j]*sourceX[time1];


     uxt[i-order][jj][1]=(1.0/x1)*(uxt[i-order][jj][1]/dt - 0.5*dxx[i-order]*uxt[i-order][jj][1]
                    +( dsxzdx )/densU[i-order][j] );

     uzt[i-order][jj][1]=(1.0/z1)*(uzt[i-order][jj][1]/dt - 0.5*dzz[j]*uzt[i-order][jj][1] 
                    +( dszzdz )/densU[i-order][j]  );

     u[i][j][1] = uxt[i-order][jj][1] + uzt[i-order][jj][1] + gauss[i-order][j]*sourceY[time1];
  }
  }
////////////////////////////////////////////////////////////////////////////
  for(i=order; i<Nx+order; i++)
  {
  for(j=order; j<PMLW; j++)
  {
    // 6th order rsg
    dsxxdx=  c11*(stress[i][j-1][0]   - stress[i-1][j][0]   + stress[i][j][0] -stress[i-1][j-1][0])
            +c22*(stress[i+1][j-2][0] - stress[i-2][j+1][0] + stress[i+1][j+1][0]-stress[i-2][j-2][0])
            +c33*(stress[i+2][j-3][0] - stress[i-3][j+2][0] + stress[i+2][j+2][0]-stress[i-3][j-3][0]);

    dszzdz= c11*(stress[i][j][1]     -stress[i-1][j-1][1]+stress[i-1][j][1]   -stress[i][j-1][1])
           +c22*(stress[i+1][j+1][1] -stress[i-2][j-2][1]+stress[i-2][j+1][1] -stress[i+1][j-2][1])
           +c33*(stress[i+2][j+2][1] -stress[i-3][j-3][1]+stress[i-3][j+2][1] -stress[i+2][j-3][1]);

    dsxzdx=  c11*(stress[i][j-1][2]   - stress[i-1][j][2]   + stress[i][j][2] -stress[i-1][j-1][2])
            +c22*(stress[i+1][j-2][2] - stress[i-2][j+1][2] + stress[i+1][j+1][2]-stress[i-2][j-2][2])
            +c33*(stress[i+2][j-3][2] - stress[i-3][j+2][2] + stress[i+2][j+2][2]-stress[i-3][j-3][2]);

    dsxzdz= c11*(stress[i][j][2]     -stress[i-1][j-1][2]+stress[i-1][j][2]   -stress[i][j-1][2])
           +c22*(stress[i+1][j+1][2] -stress[i-2][j-2][2]+stress[i-2][j+1][2] -stress[i+1][j-2][2])
           +c33*(stress[i+2][j+2][2] -stress[i-3][j-3][2]+stress[i-3][j+2][2] -stress[i+2][j-3][2]);

     jj=j;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

     uxb[i-order][jj][0]=(1.0/x1)*( uxb[i-order][jj][0]/dt - 0.5*dxx[i-order]*uxb[i-order][jj][0] 
                    +( dsxxdx )/densU[i-order][j] );

     uzb[i-order][jj][0]=(1.0/z1)*( uzb[i-order][jj][0]/dt - 0.5*dzz[j]*uzb[i-order][jj][0]
                    +( dsxzdz )/densU[i-order][j]  );

     u[i][j][0] = uxb[i-order][jj][0] + uzb[i-order][jj][0] + gauss[i-order][j]*sourceX[time1];


     uxb[i-order][jj][1]=(1.0/x1)*(uxb[i-order][jj][1]/dt - 0.5*dxx[i-order]*uxb[i-order][jj][1]
                    +( dsxzdx )/densU[i-order][j] );

     uzb[i-order][jj][1]=(1.0/z1)*(uzb[i-order][jj][1]/dt - 0.5*dzz[j]*uzb[i-order][jj][1] 
                    +( dszzdz  )/densU[i-order][j]  );

     u[i][j][1] = uxb[i-order][jj][1] + uzb[i-order][jj][1] + gauss[i-order][j]*sourceY[time1];
  }
  }
  for(i=order; i<Nx+order; i++)
  {
  for(j=0; j<order; j++)
  {
     dsxxdx=0.0;
     dszzdz=0.0;
     dsxzdz=0.0;
     dsxzdx=0.0;

     jj=j;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

     uxb[i-order][jj][0]=(1.0/x1)*( uxb[i-order][jj][0]/dt - 0.5*dxx[i-order]*uxb[i-order][jj][0] 
                    +( dsxxdx )/densU[i-order][j] );

     uzb[i-order][jj][0]=(1.0/z1)*( uzb[i-order][jj][0]/dt - 0.5*dzz[j]*uzb[i-order][jj][0]
                    +( dsxzdz )/densU[i-order][j]  );

     u[i][j][0] = uxb[i-order][jj][0] + uzb[i-order][jj][0] + gauss[i-order][j]*sourceX[time1];


     uxb[i-order][jj][1]=(1.0/x1)*(uxb[i-order][jj][1]/dt - 0.5*dxx[i-order]*uxb[i-order][jj][1]
                    +( dsxzdx )/densU[i-order][j] );

     uzb[i-order][jj][1]=(1.0/z1)*(uzb[i-order][jj][1]/dt - 0.5*dzz[j]*uzb[i-order][jj][1] 
                    +( dszzdz )/densU[i-order][j]  );

     u[i][j][1] = uxb[i-order][jj][1] + uzb[i-order][jj][1] + gauss[i-order][j]*sourceY[time1];
  }
  }

////////////////////////////////////////////////////////////////////////////
}  // outside pml x zone
else if(X_pml[my_rank]==0)
{
////////////////////////////////////////////////////////////////////////////
 for(i=order; i<Nx+order; i++)
 {
 for(j=order; j<Nzz-order; j++)
 {
    // 6th order rsg
    dsxxdx=  c11*(stress[i][j-1][0]   - stress[i-1][j][0]   + stress[i][j][0] -stress[i-1][j-1][0])
            +c22*(stress[i+1][j-2][0] - stress[i-2][j+1][0] + stress[i+1][j+1][0]-stress[i-2][j-2][0])
            +c33*(stress[i+2][j-3][0] - stress[i-3][j+2][0] + stress[i+2][j+2][0]-stress[i-3][j-3][0]);

    dszzdz= c11*(stress[i][j][1]     -stress[i-1][j-1][1]+stress[i-1][j][1]   -stress[i][j-1][1])
           +c22*(stress[i+1][j+1][1] -stress[i-2][j-2][1]+stress[i-2][j+1][1] -stress[i+1][j-2][1])
           +c33*(stress[i+2][j+2][1] -stress[i-3][j-3][1]+stress[i-3][j+2][1] -stress[i+2][j-3][1]);

    dsxzdx=  c11*(stress[i][j-1][2]   - stress[i-1][j][2]   + stress[i][j][2] -stress[i-1][j-1][2])
            +c22*(stress[i+1][j-2][2] - stress[i-2][j+1][2] + stress[i+1][j+1][2]-stress[i-2][j-2][2])
            +c33*(stress[i+2][j-3][2] - stress[i-3][j+2][2] + stress[i+2][j+2][2]-stress[i-3][j-3][2]);

    dsxzdz= c11*(stress[i][j][2]     -stress[i-1][j-1][2]+stress[i-1][j][2]   -stress[i][j-1][2])
           +c22*(stress[i+1][j+1][2] -stress[i-2][j-2][2]+stress[i-2][j+1][2] -stress[i+1][j-2][2])
           +c33*(stress[i+2][j+2][2] -stress[i-3][j-3][2]+stress[i-3][j+2][2] -stress[i+2][j-3][2]);

     jj=j;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

     uxa[i-order][jj][0]=(1.0/x1)*( uxa[i-order][jj][0]/dt - 0.5*dxx[i-order]*uxa[i-order][jj][0] 
                    +( dsxxdx )/densU[i-order][j] );

     uza[i-order][jj][0]=(1.0/z1)*( uza[i-order][jj][0]/dt - 0.5*dzz[j]*uza[i-order][jj][0]
                    +( dsxzdz )/densU[i-order][j]  );

     u[i][j][0] = uxa[i-order][jj][0] + uza[i-order][jj][0] + gauss[i-order][j]*sourceX[time1];


     uxa[i-order][jj][1]=(1.0/x1)*(uxa[i-order][jj][1]/dt - 0.5*dxx[i-order]*uxa[i-order][jj][1]
                    +( dsxzdx )/densU[i-order][j] );

     uza[i-order][jj][1]=(1.0/z1)*(uza[i-order][jj][1]/dt - 0.5*dzz[j]*uza[i-order][jj][1] 
                    +( dszzdz  )/densU[i-order][j]  );

     u[i][j][1] = uxa[i-order][jj][1] + uza[i-order][jj][1] + gauss[i-order][j]*sourceY[time1];
 }
 }
///////////////////////////////////////////////////////////
 for(i=order; i<Nx+order; i++)
 {
 for(j=0; j<order; j++)
 {
     dsxxdx=0.0;
     dszzdz=0.0;
     dsxzdz=0.0;
     dsxzdx=0.0;

     jj=j;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

     uxa[i-order][jj][0]=(1.0/x1)*( uxa[i-order][jj][0]/dt - 0.5*dxx[i-order]*uxa[i-order][jj][0] 
                    +( dsxxdx )/densU[i-order][j] );

     uza[i-order][jj][0]=(1.0/z1)*( uza[i-order][jj][0]/dt - 0.5*dzz[j]*uza[i-order][jj][0]
                    +( dsxzdz )/densU[i-order][j]  );

     u[i][j][0] = uxa[i-order][jj][0] + uza[i-order][jj][0] + gauss[i-order][j]*sourceX[time1];


     uxa[i-order][jj][1]=(1.0/x1)*(uxa[i-order][jj][1]/dt - 0.5*dxx[i-order]*uxa[i-order][jj][1]
                    +( dsxzdx )/densU[i-order][j] );

     uza[i-order][jj][1]=(1.0/z1)*(uza[i-order][jj][1]/dt - 0.5*dzz[j]*uza[i-order][jj][1] 
                    +( dszzdz  )/densU[i-order][j]  );

     u[i][j][1] = uxa[i-order][jj][1] + uza[i-order][jj][1] + gauss[i-order][j]*sourceY[time1];
 }
 }
///////////////////////////////////////////////////////////
 for(i=order; i<Nx+order; i++)
 {
 for(j=Nzz-order; j<Nzz; j++)
 {
     dsxxdx=0.0;
     dszzdz=0.0;
     dsxzdz=0.0;
     dsxzdx=0.0;

     jj=j;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

     uxa[i-order][jj][0]=(1.0/x1)*( uxa[i-order][jj][0]/dt - 0.5*dxx[i-order]*uxa[i-order][jj][0] 
                    +( dsxxdx )/densU[i-order][j] );

     uza[i-order][jj][0]=(1.0/z1)*( uza[i-order][jj][0]/dt - 0.5*dzz[j]*uza[i-order][jj][0]
                    +( dsxzdz )/densU[i-order][j]  );

     u[i][j][0] = uxa[i-order][jj][0] + uza[i-order][jj][0] + gauss[i-order][j]*sourceX[time1];


     uxa[i-order][jj][1]=(1.0/x1)*(uxa[i-order][jj][1]/dt - 0.5*dxx[i-order]*uxa[i-order][jj][1]
                    +( dsxzdx )/densU[i-order][j] );

     uza[i-order][jj][1]=(1.0/z1)*(uza[i-order][jj][1]/dt - 0.5*dzz[j]*uza[i-order][jj][1] 
                    +( dszzdz  )/densU[i-order][j]  );

     u[i][j][1] = uxa[i-order][jj][1] + uza[i-order][jj][1] + gauss[i-order][j]*sourceY[time1];
 }
 }
////////////////////////////////////////////////////////////////////////////
}  // outside pml loop


}

// Diff of the velocities to get the stress
void diff_vel(double stress[Nx+2*order][Nzz][3],double u[Nx+2*order][Nzz][2])
{
 int i,j,jj;
 double d1,d2,da=0.5/dx,x1,z1;
 double c11,c22,c33;
 double sqrtdelta,epsCons,Vp2;

 c11=da*c1;
 c22=-da*c2;
 c33=da*c3;

if(X_pml[my_rank]==1)
{
////////////////////////////////////////////////////////////////////////////
 for(i=order; i<Nx+order; i++)
 {
 for(j=PMLW; j<Nzz-PMLW; j++)
 {
    // 6th order rsg
     dudx = c11*( u[i+1][j][0]   -u[i][j+1][0]   + u[i+1][j+1][0] - u[i][j][0])
           +c22*( u[i+2][j-1][0] -u[i-1][j+2][0] + u[i+2][j+2][0] - u[i-1][j-1][0])
           +c33*( u[i+3][j-2][0] -u[i-2][j+3][0] + u[i+3][j+3][0] - u[i-2][j-2][0]);

     dvdz = c11*( u[i+1][j+1][1]-  u[i][j][1]      + u[i][j+1][1]    - u[i+1][j][1])
           +c22*( u[i+2][j+2][1] - u[i-1][j-1][1]  + u[i-1][j+2][1]  - u[i+2][j-1][1])
           +c33*( u[i+3][j+3][1] - u[i-2][j-2][1]  + u[i-2][j+3][1]  - u[i+3][j-2][1]);

     dvdx = c11*( u[i+1][j][1]   -u[i][j+1][1]   + u[i+1][j+1][1] - u[i][j][1])
           +c22*( u[i+2][j-1][1] -u[i-1][j+2][1] + u[i+2][j+2][1] - u[i-1][j-1][1])
           +c33*( u[i+3][j-2][1] -u[i-2][j+3][1] + u[i+3][j+3][1] - u[i-2][j-2][1]);

     dudz = c11*( u[i+1][j+1][0]-  u[i][j][0]      + u[i][j+1][0]    - u[i+1][j][0])
           +c22*( u[i+2][j+2][0] - u[i-1][j-1][0]  + u[i-1][j+2][0]  - u[i+2][j-1][0])
           +c33*( u[i+3][j+3][0] - u[i-2][j-2][0]  + u[i-2][j+3][0]  - u[i+3][j-2][0]);

    stress[i][j][0] = stress[i][j][0]
                    + dt*( M[i-order][j]*( dudx + dvdz ) - 2.0*mu[i-order][j]*dvdz )
                    + mxx*gauss[i-order][j]*source[time1];

    stress[i][j][1] =  stress[i][j][1]
                    + dt*( M[i-order][j]*( dudx + dvdz ) - 2.0*mu[i-order][j]*dudx )
                    + mzz*gauss[i-order][j]*source[time1];

    stress[i][j][2] =  stress[i][j][2]
                    + dt*mu[i-order][j]*(  dudz+dvdx  )
                    + mxz*gauss[i-order][j]*source[time1];


  }
  }
////////////////////////////////////////////////////////////////////////////
 for(i=order; i<Nx+order; i++)
 {
 for(j=Nzz-PMLW; j<Nzz-order; j++)
 {
    // 6th order rsg
     dudx = da*c1*( u[i+1][j][0]   -u[i][j+1][0]   + u[i+1][j+1][0] - u[i][j][0])
           -da*c2*( u[i+2][j-1][0] -u[i-1][j+2][0] + u[i+2][j+2][0] - u[i-1][j-1][0])
           +da*c3*( u[i+3][j-2][0] -u[i-2][j+3][0] + u[i+3][j+3][0] - u[i-2][j-2][0]);

     dvdz = da*c1*( u[i+1][j+1][1]-  u[i][j][1]      + u[i][j+1][1]    - u[i+1][j][1])
           -da*c2*( u[i+2][j+2][1] - u[i-1][j-1][1]  + u[i-1][j+2][1]  - u[i+2][j-1][1])
           +da*c3*( u[i+3][j+3][1] - u[i-2][j-2][1]  + u[i-2][j+3][1]  - u[i+3][j-2][1]);

     dvdx = c11*( u[i+1][j][1]   -u[i][j+1][1]   + u[i+1][j+1][1] - u[i][j][1])
           +c22*( u[i+2][j-1][1] -u[i-1][j+2][1] + u[i+2][j+2][1] - u[i-1][j-1][1])
           +c33*( u[i+3][j-2][1] -u[i-2][j+3][1] + u[i+3][j+3][1] - u[i-2][j-2][1]);

     dudz = c11*( u[i+1][j+1][0]-  u[i][j][0]      + u[i][j+1][0]    - u[i+1][j][0])
           +c22*( u[i+2][j+2][0] - u[i-1][j-1][0]  + u[i-1][j+2][0]  - u[i+2][j-1][0])
           +c33*( u[i+3][j+3][0] - u[i-2][j-2][0]  + u[i-2][j+3][0]  - u[i+3][j-2][0]);

     jj=j-Nzz+PMLW;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

     sxt[i-order][jj][0]=( sxt[i-order][jj][0]*(1.0/dt - dxx[i-order]*0.5)
              + ( M[i-order][j]*dudx ) )/x1;

     szt[i-order][jj][0]=( szt[i-order][jj][0]*(1.0/dt - dzz[j]*0.5)
              + (M[i-order][j]*dvdz - 2.0*mu[i-order][j]*dvdz ) )/z1;

     sxt[i-order][jj][1]=( sxt[i-order][jj][1]*(1.0/dt - dxx[i-order]*0.5)
              + ( M[i-order][j]*dudx - 2.0*mu[i-order][j]*dudx) )/x1;

     szt[i-order][jj][1]=( szt[i-order][jj][1]*(1.0/dt - dzz[j]*0.5)
              + (M[i-order][j]*dvdz ) )/z1;

     sxt[i-order][jj][2]=( sxt[i-order][jj][2]*(1.0/dt - dxx[i-order]*0.5)
              + ( mu[i-order][j]*(  dvdx  )) )/x1;

     szt[i-order][jj][2]=( szt[i-order][jj][2]*(1.0/dt - dzz[j]*0.5)
              + ( mu[i-order][j]*(  dudz  )) )/z1;

     stress[i][j][0] = sxt[i-order][jj][0] + szt[i-order][jj][0] + mxx*gauss[i-order][j]*source[time1];
     stress[i][j][1] = sxt[i-order][jj][1] + szt[i-order][jj][1] + mzz*gauss[i-order][j]*source[time1];
     stress[i][j][2] = sxt[i-order][jj][2] + szt[i-order][jj][2] + mxz*gauss[i-order][j]*source[time1];
 }
 }
////////////////////////////////////////////////////////////////////////////
 for(i=order; i<Nx+order; i++)
 {
 for(j=Nzz-order+1; j<Nzz; j++)
 {
     dudx=0.0; 
     dvdz=0.0;
     dudz = 0.0;
     dvdx = 0.0;

     jj=j-Nzz+PMLW;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

     sxt[i-order][jj][0]=( sxt[i-order][jj][0]*(1.0/dt - dxx[i-order]*0.5)
              + ( M[i-order][j]*dudx ) )/x1;

     szt[i-order][jj][0]=( szt[i-order][jj][0]*(1.0/dt - dzz[j]*0.5)
              + (M[i-order][j]*dvdz - 2.0*mu[i-order][j]*dvdz ) )/z1;

     sxt[i-order][jj][1]=( sxt[i-order][jj][1]*(1.0/dt - dxx[i-order]*0.5)
              + ( M[i-order][j]*dudx - 2.0*mu[i-order][j]*dudx) )/x1;

     szt[i-order][jj][1]=( szt[i-order][jj][1]*(1.0/dt - dzz[j]*0.5)
              + (M[i-order][j]*dvdz ) )/z1;

     sxt[i-order][jj][2]=( sxt[i-order][jj][2]*(1.0/dt - dxx[i-order]*0.5)
              + ( mu[i-order][j]*(  dvdx  )) )/x1;

     szt[i-order][jj][2]=( szt[i-order][jj][2]*(1.0/dt - dzz[j]*0.5)
              + ( mu[i-order][j]*(  dudz  )) )/z1;

     stress[i][j][0] = sxt[i-order][jj][0] + szt[i-order][jj][0] + mxx*gauss[i-order][j]*source[time1];
     stress[i][j][1] = sxt[i-order][jj][1] + szt[i-order][jj][1] + mzz*gauss[i-order][j]*source[time1];
     stress[i][j][2] = sxt[i-order][jj][2] + szt[i-order][jj][2] + mxz*gauss[i-order][j]*source[time1];
 }
 }
////////////////////////////////////////////////////////////////////////////
 for(i=order; i<Nx+order; i++)
 {
 for(j=order; j<PMLW; j++)
 {
    // 6th order rsg
     dudx = da*c1*( u[i+1][j][0]   -u[i][j+1][0]   + u[i+1][j+1][0] - u[i][j][0])
           -da*c2*( u[i+2][j-1][0] -u[i-1][j+2][0] + u[i+2][j+2][0] - u[i-1][j-1][0])
           +da*c3*( u[i+3][j-2][0] -u[i-2][j+3][0] + u[i+3][j+3][0] - u[i-2][j-2][0]);

     dvdz = da*c1*( u[i+1][j+1][1]-  u[i][j][1]      + u[i][j+1][1]    - u[i+1][j][1])
           -da*c2*( u[i+2][j+2][1] - u[i-1][j-1][1]  + u[i-1][j+2][1]  - u[i+2][j-1][1])
           +da*c3*( u[i+3][j+3][1] - u[i-2][j-2][1]  + u[i-2][j+3][1]  - u[i+3][j-2][1]);

     dvdx = c11*( u[i+1][j][1]   -u[i][j+1][1]   + u[i+1][j+1][1] - u[i][j][1])
           +c22*( u[i+2][j-1][1] -u[i-1][j+2][1] + u[i+2][j+2][1] - u[i-1][j-1][1])
           +c33*( u[i+3][j-2][1] -u[i-2][j+3][1] + u[i+3][j+3][1] - u[i-2][j-2][1]);

     dudz = c11*( u[i+1][j+1][0]-  u[i][j][0]      + u[i][j+1][0]    - u[i+1][j][0])
           +c22*( u[i+2][j+2][0] - u[i-1][j-1][0]  + u[i-1][j+2][0]  - u[i+2][j-1][0])
           +c33*( u[i+3][j+3][0] - u[i-2][j-2][0]  + u[i-2][j+3][0]  - u[i+3][j-2][0]);

     jj=j;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

     sxb[i-order][jj][0]=( sxb[i-order][jj][0]*(1.0/dt - dxx[i-order]*0.5)
              + ( M[i-order][j]*dudx ) )/x1;

     szb[i-order][jj][0]=( szb[i-order][jj][0]*(1.0/dt - dzz[j]*0.5)
              + (M[i-order][j]*dvdz - 2.0*mu[i-order][j]*dvdz ) )/z1;

     sxb[i-order][jj][1]=( sxb[i-order][jj][1]*(1.0/dt - dxx[i-order]*0.5)
              + ( M[i-order][j]*dudx - 2.0*mu[i-order][j]*dudx) )/x1;

     szb[i-order][jj][1]=( szb[i-order][jj][1]*(1.0/dt - dzz[j]*0.5)
              + (M[i-order][j]*dvdz ) )/z1;

     sxb[i-order][jj][2]=( sxb[i-order][jj][2]*(1.0/dt - dxx[i-order]*0.5)
              + ( mu[i-order][j]*(  dvdx  )) )/x1;

     szb[i-order][jj][2]=( szb[i-order][jj][2]*(1.0/dt - dzz[j]*0.5)
              + ( mu[i-order][j]*(  dudz  )) )/z1;

     stress[i][j][0] = sxb[i-order][jj][0] + szb[i-order][jj][0] + mxx*gauss[i-order][j]*source[time1];
     stress[i][j][1] = sxb[i-order][jj][1] + szb[i-order][jj][1] + mzz*gauss[i-order][j]*source[time1];
     stress[i][j][2] = sxb[i-order][jj][2] + szb[i-order][jj][2] + mxz*gauss[i-order][j]*source[time1];

 }
 }
 for(i=order; i<Nx+order; i++)
 {
 for(j=0; j<order; j++)
 {
    // 6th order rsg
     dudx = 0.0;
     dvdz = 0.0;
     dudz = 0.0;
     dvdx = 0.0;

     jj=j;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

     sxb[i-order][jj][0]=( sxb[i-order][jj][0]*(1.0/dt - dxx[i-order]*0.5)
              + ( M[i-order][j]*dudx ) )/x1;

     szb[i-order][jj][0]=( szb[i-order][jj][0]*(1.0/dt - dzz[j]*0.5)
              + (M[i-order][j]*dvdz - 2.0*mu[i-order][j]*dvdz ) )/z1;

     sxb[i-order][jj][1]=( sxb[i-order][jj][1]*(1.0/dt - dxx[i-order]*0.5)
              + ( M[i-order][j]*dudx - 2.0*mu[i-order][j]*dudx) )/x1;

     szb[i-order][jj][1]=( szb[i-order][jj][1]*(1.0/dt - dzz[j]*0.5)
              + (M[i-order][j]*dvdz ) )/z1;

     sxb[i-order][jj][2]=( sxb[i-order][jj][2]*(1.0/dt - dxx[i-order]*0.5)
              + ( mu[i-order][j]*(  dvdx  )) )/x1;

     szb[i-order][jj][2]=( szb[i-order][jj][2]*(1.0/dt - dzz[j]*0.5)
              + ( mu[i-order][j]*(  dudz  )) )/z1;

     stress[i][j][0] = sxb[i-order][jj][0] + szb[i-order][jj][0] + mxx*gauss[i-order][j]*source[time1];
     stress[i][j][1] = sxb[i-order][jj][1] + szb[i-order][jj][1] + mzz*gauss[i-order][j]*source[time1];
     stress[i][j][2] = sxb[i-order][jj][2] + szb[i-order][jj][2] + mxz*gauss[i-order][j]*source[time1];
 }
 }
////////////////////////////////////////////////////////////////////////////
}  // outside pml x zone
else if(X_pml[my_rank]==0)
{
////////////////////////////////////////////////////////////////////////////
 for(i=order; i<Nx+order; i++)
 {
 for(j=order; j<Nzz-order; j++)
 {
   // 6th order rsg
     dudx = da*c1*( u[i+1][j][0]   -u[i][j+1][0]   + u[i+1][j+1][0] - u[i][j][0])
           -da*c2*( u[i+2][j-1][0] -u[i-1][j+2][0] + u[i+2][j+2][0] - u[i-1][j-1][0])
           +da*c3*( u[i+3][j-2][0] -u[i-2][j+3][0] + u[i+3][j+3][0] - u[i-2][j-2][0]);

     dvdz = da*c1*( u[i+1][j+1][1]-  u[i][j][1]      + u[i][j+1][1]    - u[i+1][j][1])
           -da*c2*( u[i+2][j+2][1] - u[i-1][j-1][1]  + u[i-1][j+2][1]  - u[i+2][j-1][1])
           +da*c3*( u[i+3][j+3][1] - u[i-2][j-2][1]  + u[i-2][j+3][1]  - u[i+3][j-2][1]);

     dvdx = c11*( u[i+1][j][1]   -u[i][j+1][1]   + u[i+1][j+1][1] - u[i][j][1])
           +c22*( u[i+2][j-1][1] -u[i-1][j+2][1] + u[i+2][j+2][1] - u[i-1][j-1][1])
           +c33*( u[i+3][j-2][1] -u[i-2][j+3][1] + u[i+3][j+3][1] - u[i-2][j-2][1]);

     dudz = c11*( u[i+1][j+1][0]-  u[i][j][0]      + u[i][j+1][0]    - u[i+1][j][0])
           +c22*( u[i+2][j+2][0] - u[i-1][j-1][0]  + u[i-1][j+2][0]  - u[i+2][j-1][0])
           +c33*( u[i+3][j+3][0] - u[i-2][j-2][0]  + u[i-2][j+3][0]  - u[i+3][j-2][0]);

     jj=j;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

     sxa[i-order][jj][0]=( sxa[i-order][jj][0]*(1.0/dt - dxx[i-order]*0.5)
              + ( M[i-order][j]*dudx ) )/x1;

     sza[i-order][jj][0]=( sza[i-order][jj][0]*(1.0/dt - dzz[j]*0.5)
              + (M[i-order][j]*dvdz - 2.0*mu[i-order][j]*dvdz ) )/z1;

     sxa[i-order][jj][1]=( sxa[i-order][jj][1]*(1.0/dt - dxx[i-order]*0.5)
              + ( M[i-order][j]*dudx - 2.0*mu[i-order][j]*dudx) )/x1;

     sza[i-order][jj][1]=( sza[i-order][jj][1]*(1.0/dt - dzz[j]*0.5)
              + (M[i-order][j]*dvdz ) )/z1;

     sxa[i-order][jj][2]=( sxa[i-order][jj][2]*(1.0/dt - dxx[i-order]*0.5)
              + ( mu[i-order][j]*(  dvdx  )) )/x1;

     sza[i-order][jj][2]=( sza[i-order][jj][2]*(1.0/dt - dzz[j]*0.5)
              + ( mu[i-order][j]*(  dudz  )) )/z1;

     stress[i][j][0] = sxa[i-order][jj][0] + sza[i-order][jj][0] + mxx*gauss[i-order][j]*source[time1];
     stress[i][j][1] = sxa[i-order][jj][1] + sza[i-order][jj][1] + mzz*gauss[i-order][j]*source[time1];
     stress[i][j][2] = sxa[i-order][jj][2] + sza[i-order][jj][2] + mxz*gauss[i-order][j]*source[time1];

 }
 }
///////////////////////////////////////////////////////////
 for(i=order; i<Nx+order; i++)
 {
 for(j=0; j<order; j++)
 {
   // 6th order rsg
     dudx = 0.0;
     dvdz = 0.0;
     dudz = 0.0;
     dvdx = 0.0;

     jj=j;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

     sxa[i-order][jj][0]=( sxa[i-order][jj][0]*(1.0/dt - dxx[i-order]*0.5)
              + ( M[i-order][j]*dudx ) )/x1;

     sza[i-order][jj][0]=( sza[i-order][jj][0]*(1.0/dt - dzz[j]*0.5)
              + (M[i-order][j]*dvdz - 2.0*mu[i-order][j]*dvdz ) )/z1;

     sxa[i-order][jj][1]=( sxa[i-order][jj][1]*(1.0/dt - dxx[i-order]*0.5)
              + ( M[i-order][j]*dudx - 2.0*mu[i-order][j]*dudx) )/x1;

     sza[i-order][jj][1]=( sza[i-order][jj][1]*(1.0/dt - dzz[j]*0.5)
              + (M[i-order][j]*dvdz ) )/z1;

     sxa[i-order][jj][2]=( sxa[i-order][jj][2]*(1.0/dt - dxx[i-order]*0.5)
              + ( mu[i-order][j]*(  dvdx  )) )/x1;

     sza[i-order][jj][2]=( sza[i-order][jj][2]*(1.0/dt - dzz[j]*0.5)
              + ( mu[i-order][j]*(  dudz  )) )/z1;

     stress[i][j][0] = sxa[i-order][jj][0] + sza[i-order][jj][0] + mxx*gauss[i-order][j]*source[time1];
     stress[i][j][1] = sxa[i-order][jj][1] + sza[i-order][jj][1] + mzz*gauss[i-order][j]*source[time1];
     stress[i][j][2] = sxa[i-order][jj][2] + sza[i-order][jj][2] + mxz*gauss[i-order][j]*source[time1];
 }
 }
///////////////////////////////////////////////////////////
 for(i=order; i<Nx+order; i++)
 {
 for(j=Nzz-order; j<Nzz; j++)
 {
   // 6th order rsg
     dudx = 0.0;
     dvdz = 0.0;
     dudz = 0.0;
     dvdx = 0.0;

     jj=j;
     x1=(1.0/dt + dxx[i-order]*0.5);
     z1=(1.0/dt + dzz[j]*0.5);

     sxa[i-order][jj][0]=( sxa[i-order][jj][0]*(1.0/dt - dxx[i-order]*0.5)
              + ( M[i-order][j]*dudx ) )/x1;

     sza[i-order][jj][0]=( sza[i-order][jj][0]*(1.0/dt - dzz[j]*0.5)
              + (M[i-order][j]*dvdz - 2.0*mu[i-order][j]*dvdz ) )/z1;

     sxa[i-order][jj][1]=( sxa[i-order][jj][1]*(1.0/dt - dxx[i-order]*0.5)
              + ( M[i-order][j]*dudx - 2.0*mu[i-order][j]*dudx) )/x1;

     sza[i-order][jj][1]=( sza[i-order][jj][1]*(1.0/dt - dzz[j]*0.5)
              + (M[i-order][j]*dvdz ) )/z1;

     sxa[i-order][jj][2]=( sxa[i-order][jj][2]*(1.0/dt - dxx[i-order]*0.5)
              + ( mu[i-order][j]*(  dvdx  )) )/x1;

     sza[i-order][jj][2]=( sza[i-order][jj][2]*(1.0/dt - dzz[j]*0.5)
              + ( mu[i-order][j]*(  dudz  )) )/z1;

     stress[i][j][0] = sxa[i-order][jj][0] + sza[i-order][jj][0] + mxx*gauss[i-order][j]*source[time1];
     stress[i][j][1] = sxa[i-order][jj][1] + sza[i-order][jj][1] + mzz*gauss[i-order][j]*source[time1];
     stress[i][j][2] = sxa[i-order][jj][2] + sza[i-order][jj][2] + mxz*gauss[i-order][j]*source[time1];

 }
 }
////////////////////////////////////////////////////////////////////////////
}  // outside pml loop


}

