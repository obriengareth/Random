
void create_cartesian_topo()                   // create cartesian topopogy
{
    int   dims[1];
    int   periods[1];
    int   reorder;
    int   my_new_rank;

    dims[0]    = size;
    periods[0] = 1;
    reorder    = 1;

    MPI_Cart_create(MPI_COMM_WORLD, ndims, dims, periods, reorder, &new_comm);  
    MPI_Comm_rank(new_comm, &my_rank);
    MPI_Comm_size(new_comm, &my_size);   
}

////////////////////////////////////////////////////////////////////////////////////////
void create_mpi_data_type()
{

 int count = 1;
 int blocklen = Nzz*2*order;
 int stride = 0;

 MPI_Type_vector(count, blocklen, stride, MPI_DOUBLE, &fcol);
 MPI_Type_commit(&fcol);

 count = 1;
 blocklen = Nzz*3*order;
 stride = 0;

 MPI_Type_vector(count, blocklen, stride, MPI_DOUBLE, &gcol);
 MPI_Type_commit(&gcol);

 count = 1;
 blocklen = Nzz;
 stride = 0;

 MPI_Type_vector(count, blocklen, stride, MPI_DOUBLE, &hcol);
 MPI_Type_commit(&hcol);

}

void transfer_vel(double u[Nx+2*order][Nzz][2])
{
 //MPI_Status status;
 MPI_Request array_of_requestsf[max_nb_of_comm];
 MPI_Status  array_of_statusesf[max_nb_of_comm];
 int index_of_comm = 0;

 if(my_rank==0)
 {
   MPI_Isend(&u[order][0][0],1,fcol,my_size-1,53,new_comm, &array_of_requestsf[index_of_comm++]);
   MPI_Irecv(&u[Nx+order][0][0],1,fcol,my_rank+1,53,new_comm, &array_of_requestsf[index_of_comm++]);

   MPI_Irecv(&u[0][0][0],1,fcol,my_size-1,53,new_comm, &array_of_requestsf[index_of_comm++] );
   MPI_Isend(&u[Nx][0][0],1,fcol,my_rank+1,53,new_comm, &array_of_requestsf[index_of_comm++]);
 }
 else if( my_rank>0 && my_rank< (my_size-1) )
 {
  MPI_Isend(&u[order][0][0],1,fcol,my_rank-1,53,new_comm, &array_of_requestsf[index_of_comm++]);
  MPI_Irecv(&u[Nx+order][0][0],1,fcol,my_rank+1,53,new_comm, &array_of_requestsf[index_of_comm++]);

  MPI_Irecv(&u[0][0][0],1,fcol,my_rank-1,53,new_comm, &array_of_requestsf[index_of_comm++]);
  MPI_Isend(&u[Nx][0][0],1,fcol,my_rank+1,53,new_comm,  &array_of_requestsf[index_of_comm++]);
 }
 else if( my_rank == (my_size-1) )
 {
   MPI_Irecv(&u[Nx+order][0][0],1,fcol,0,53,new_comm,  &array_of_requestsf[index_of_comm++]);
   MPI_Isend(&u[order][0][0],1,fcol,my_rank-1,53,new_comm,  &array_of_requestsf[index_of_comm++]);

   MPI_Isend(&u[Nx][0][0],1,fcol,0,53,new_comm,  &array_of_requestsf[index_of_comm++]);
   MPI_Irecv(&u[0][0][0],1,fcol,my_rank-1,53,new_comm, &array_of_requestsf[index_of_comm++]);
 }

 MPI_Waitall(index_of_comm, array_of_requestsf, array_of_statusesf);

 //MPI_Type_free(&fcol);

}

void transfer_stress(double stress[Nx+2*order][Nzz][3])
{
 //MPI_Status status;
 MPI_Request array_of_requestsf[max_nb_of_comm];
 MPI_Status  array_of_statusesf[max_nb_of_comm];
 int index_of_comm = 0;

 if(my_rank==0)
 {
   MPI_Isend(&stress[order][0][0],1,gcol,my_size-1,54,new_comm, &array_of_requestsf[index_of_comm++]);
   MPI_Irecv(&stress[Nx+order][0][0],1,gcol,my_rank+1,54,new_comm, &array_of_requestsf[index_of_comm++]);

   MPI_Irecv(&stress[0][0][0],1,gcol,my_size-1,54,new_comm, &array_of_requestsf[index_of_comm++] );
   MPI_Isend(&stress[Nx][0][0],1,gcol,my_rank+1,54,new_comm, &array_of_requestsf[index_of_comm++]);
 }
 else if( my_rank>0 && my_rank< (my_size-1) )
 {
  MPI_Isend(&stress[order][0][0],1,gcol,my_rank-1,54,new_comm, &array_of_requestsf[index_of_comm++]);
  MPI_Irecv(&stress[Nx+order][0][0],1,gcol,my_rank+1,54,new_comm, &array_of_requestsf[index_of_comm++]);

  MPI_Irecv(&stress[0][0][0],1,gcol,my_rank-1,54,new_comm, &array_of_requestsf[index_of_comm++]);
  MPI_Isend(&stress[Nx][0][0],1,gcol,my_rank+1,54,new_comm,  &array_of_requestsf[index_of_comm++]);
 }
 else if( my_rank == (my_size-1) )
 {
   MPI_Irecv(&stress[Nx+order][0][0],1,gcol,0,54,new_comm,  &array_of_requestsf[index_of_comm++]);
   MPI_Isend(&stress[order][0][0],1,gcol,my_rank-1,54,new_comm,  &array_of_requestsf[index_of_comm++]);

   MPI_Isend(&stress[Nx][0][0],1,gcol,0,54,new_comm,  &array_of_requestsf[index_of_comm++]);
   MPI_Irecv(&stress[0][0][0],1,gcol,my_rank-1,54,new_comm, &array_of_requestsf[index_of_comm++]);
 }

 MPI_Waitall(index_of_comm, array_of_requestsf, array_of_statusesf);

 //MPI_Type_free(&fcol);

}

/*
void transfer_theta(double theta[Nx+2][Nzz])
{
 //MPI_Status status;
 MPI_Request array_of_requestsf[max_nb_of_comm];
 MPI_Status  array_of_statusesf[max_nb_of_comm];
 int index_of_comm = 0;

 if(my_rank==0)
 {
   MPI_Isend(&theta[1][0],1,hcol,my_size-1,53,new_comm, &array_of_requestsf[index_of_comm++]);
   MPI_Irecv(&theta[Nx+1][0],1,hcol,my_rank+1,53,new_comm, &array_of_requestsf[index_of_comm++]);

   MPI_Irecv(&theta[0][0],1,hcol,my_size-1,53,new_comm, &array_of_requestsf[index_of_comm++] );
   MPI_Isend(&theta[Nx][0],1,hcol,my_rank+1,53,new_comm, &array_of_requestsf[index_of_comm++]);
 }
 else if( my_rank>0 && my_rank< (my_size-1) )
 {
  MPI_Isend(&theta[1][0],1,hcol,my_rank-1,53,new_comm, &array_of_requestsf[index_of_comm++]);
  MPI_Irecv(&theta[Nx+1][0],1,hcol,my_rank+1,53,new_comm, &array_of_requestsf[index_of_comm++]);

  MPI_Irecv(&theta[0][0],1,hcol,my_rank-1,53,new_comm, &array_of_requestsf[index_of_comm++]);
  MPI_Isend(&theta[Nx][0],1,hcol,my_rank+1,53,new_comm,  &array_of_requestsf[index_of_comm++]);
 }
 else if( my_rank == (my_size-1) )
 {
   MPI_Irecv(&theta[Nx+1][0],1,hcol,0,53,new_comm,  &array_of_requestsf[index_of_comm++]);
   MPI_Isend(&theta[order][0],1,hcol,my_rank-1,53,new_comm,  &array_of_requestsf[index_of_comm++]);

   MPI_Isend(&theta[Nx][0],1,hcol,0,53,new_comm,  &array_of_requestsf[index_of_comm++]);
   MPI_Irecv(&theta[0][0],1,hcol,my_rank-1,53,new_comm, &array_of_requestsf[index_of_comm++]);
 }

 MPI_Waitall(index_of_comm, array_of_requestsf, array_of_statusesf);

 //MPI_Type_free(&fcol);

}
//////////////////////////////////////////////////////////////////////////////////////
*/
/// Interpolating density grid (densL) onto velocity grid called densU
void densityU()
{
 int i,j;
 int bcol[1],d[1];
 double left_dens[Nzz],right_dens[Nzz];
 double templeft_dens[Nzz],tempright_dens[Nzz];
 double a,b,c,e;
 int iup1,iup2,ido1,ido2;
 int jup1,jup2,jdo1,jdo2;
 int kup1,kup2,kdo1,kdo2;

 MPI_Datatype col;
 MPI_Status status;

 bcol[0]=Nzz;   d[0]=0;
 MPI_Type_indexed(1,bcol,d,MPI_DOUBLE,&col);
 MPI_Type_commit(&col);

  for(i=0; i<Nzz; i++)
  {
    left_dens[i]=densL[0][i];
    right_dens[i]=densL[Nx-1][i];

    templeft_dens[i]=0;
    tempright_dens[i]=0;
  }

 MPI_Barrier(new_comm);
 if(my_rank==0)
 {
   MPI_Send(left_dens,1,col,my_size-1,50,new_comm);
   MPI_Recv(tempright_dens,1,col,my_rank+1,50,new_comm,&status);

   MPI_Recv(templeft_dens,1,col,my_size-1,50,new_comm,&status);
   MPI_Send(right_dens,1,col,my_rank+1,50,new_comm);
 }
 else if( my_rank>0 && my_rank< (my_size-1) )
 {
  MPI_Send(left_dens,1,col,my_rank-1,50,new_comm);
  MPI_Recv(tempright_dens,1,col,my_rank+1,50,new_comm,&status);

  MPI_Recv(templeft_dens,1,col,my_rank-1,50,new_comm,&status);
  MPI_Send(right_dens,1,col,my_rank+1,50,new_comm);
 }
 else if( my_rank == (my_size-1) )
 {
   MPI_Recv(tempright_dens,1,col,0,50,new_comm,&status);
   MPI_Send(left_dens,1,col,my_rank-1,50,new_comm);

   MPI_Send(right_dens,1,col,0,50,new_comm);
   MPI_Recv(templeft_dens,1,col,my_rank-1,50,new_comm,&status);
 }
 MPI_Barrier(new_comm);

 MPI_Type_free(&col);

 for(i=0; i<Nx; i++)
 {
 for(j=0; j<Nzz; j++)
 {    
   jup1=j+1; jdo1=j-1;  
   iup1=i+1; ido1=i-1;  

   //if(j==Nzz-1) { jup1=0;  }
   //if(j==0)    { jdo1=Nzz-1;  }

   if(j!=0)
   {
     if(i==0)
     {
      densU[i][j]=0.25*(densL[i][j]+templeft_dens[j]+templeft_dens[jdo1]+densL[i][jdo1]);
     }
     else
     {
      densU[i][j]=0.25*(densL[i][j]+densL[ido1][j]+densL[ido1][jdo1]+densL[i][jdo1]);
     } 
    }
    else if(j==0)
    { 
     if(i==0)
     {
      densU[i][j]=0.5*(densL[i][j]+templeft_dens[j]);
     }
     else
     {
      densU[i][j]=0.5*(densL[i][j]+densL[ido1][j]);
     } 
    } 
 }
 }

}


