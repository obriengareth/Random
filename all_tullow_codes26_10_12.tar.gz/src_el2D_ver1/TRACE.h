

////////////////////////////////////////////////////////////////
// Open trace files and locate them correctly
void trace_files()
{
  int j,n;
  int no;
  FILE *input;
  char file_name[50];

// Allocate correct memory
  no=no_trace;
  x=alloc1d_int(no);
  z=alloc1d_int(no);

  sprintf(file_name,"%s",input7);
  if(( input= fopen(file_name,"r"))==NULL )
  {
     printf("Error 2001: opening input rec file on node %d\n",my_rank);
     MPI_Finalize();
     exit(0);
  }

  node_count=0;
  for(n=0; n<no_trace; n++)
  {
    fscanf(input,"%d %d\n",&x[n],&z[n]);
    x[n]=floor(x[n]/dx);
    z[n]=floor(z[n]/dx);

    //printf("%d %d %d\n",my_rank,x[n],z[n]);

    if(locate_node(x[n])==my_rank)
    {
       node_count++;
    }
  }
  x_coord=alloc1d_int(node_count);
  z_coord=alloc1d_int(node_count);
 
  j=0;
  for(n=0; n<no_trace; n++)
  {
    if(locate_node(x[n])==my_rank)
    {
      x_coord[j]=x[n]%Nx + order;
      z_coord[j]=z[n] + order;

 //printf("%d %d %d\n",my_rank,x_coord[j],z_coord[j]);
      j++;
      sprintf(file_name,"%s%d",output1,n);
      if(( out_trace[n]= fopen(file_name,"w")) ==NULL )
      {
         printf("Error 2002: opening trace file on node %d\n",my_rank);
         MPI_Finalize();
         exit(0);
      }
     }
   }
   fclose(input);



}     // End of Routine

// Writing the correct trace position to correct file
void write_trace(double stress[Nx+2*order][Nzz][3],double u[Nx+2*order][Nzz][2])
{
  int i,j;

  j=0;
  for(i=0; i<no_trace; i++)
  {
    if(locate_node(x[i])==my_rank)
    {

      // fprintf(out_trace[i]," %e %e %e \n",0.0,0.0,0.0   );

     fprintf(out_trace[i]," %e %e %e \n",u[x_coord[j]][z_coord[j]][0]
                                         ,u[x_coord[j]][z_coord[j]][1]
     ,stress[x_coord[j]][z_coord[j]][0]+stress[x_coord[j]][z_coord[j]][1]   );

      j++;
    }
  }

}  // End of Routine

// Closing files
void close_trace()
{
  int i;

  for(i=0; i<no_trace; i++)
  {
    if(locate_node(x[i])==my_rank)
    {
      fclose(out_trace[i]);
    }
  }

}     // End of routine




