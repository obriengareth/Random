/////////////////////////////////////////////////////////////////////////////////////////////////////////

#define LX  0.0      // Total X length in m 
#define LY  0.0      // Total Y length in m 
#define LZ  0.0      // Total Z length in m 
#define OX  0.0      // Origin X in m 
#define OY  0.0      // Origin Y in m 
#define OZ  0.0      // Origin Z in m Top Down (sea ->0)

/////////////////////////////////////////////////////////////////////////////////////////////////////////

#define Width		24   // width of the abs

#define Nx1   (10 + 2*Width/12)
#define Ny1   (100 + 2*Width)
#define Nz1   (80 + 2*Width)

/////////////////////////////////////////////////////////////////////////////////////////////////////////

#define dx        (10.0)     // Spatial Increment 
#define dz        (10.0)     // Spatial Increment
#define dt        (0.001)    // Temporal Increment 
#define Duration  (1.0)    //  Run Time

/////////////////////////////////////////////////////////////////////////////////////////////////////////

#define vdrop 		0.25                      //  vdrop decreases velocity on edge 1 is  off
#define randvalue	0.35                      // deivation +/- of max_vel in random boundaries 0 is off
#define lambda		(1.0/2.0/2.0/Width/Width) // lambda function is just rule of thumb, set to 0 for no bc
#define sscaleF         (1e+2)                    // scale source by this amount
#define sscaleR         (1e+5)                    // scale source by this amount

/////////////////////////////////////////////////////////////////////////////////////////////////////////

#define input1  "VP.bin"     // Input v-p file
#define input2  "DEN.bin"    // Input density file
#define input3  "EPS.bin"    // Input eps file e>d
#define input4  "DELTA.bin"    // Input delta file e>d
#define input5  "THETA.bin"    // Input theta file
#define input9  "PHI.bin"    // Input phi file

#define input6  "dricker20Hz"    // source time function
#define input7  "source1"    // source location

#define input11  "shot1/reverse"    // reverse data
#define input10  "recorder1"         // reverse data locations

/////////////////////////////////////////////////////////////////////////////////////////////////////////

#define output3        "mess/image"   // source time function
#define no_snaps        0.005          // take snapshot every no_snaps seconds
#define LR              1             // downgrade image resolution  by factor

/////////////////////////////////////////////////////////////////////////////////////////////////////////
