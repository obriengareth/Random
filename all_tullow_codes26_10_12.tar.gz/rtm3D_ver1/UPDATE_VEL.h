// main routine for diff stress and velocity

// Diff stress for vel update for TTI
void update_velocity()
{
 int i,j,k;
 double updateX,updateY,updateZ;
 double c11,c22,c33,c44;

// FD coefficients
 c11=(c1/dx);
 c22=(c2/dx);
 c33=(c3/dx);
 c44=(c4/dx);

 for(i=order; i<Nx+order; i++)
 {
 for(j=order; j<Ny+order; j++)
 {
 for(k=order; k<Nz+order; k++)
 {
////////////////////////////////////// TTI
// 8th order cd of horizontal and vertical stress
// can replace with pointer arithmetic to speed up?

   dsxxdx= c11*( stress[i+1][j][k][0]-stress[i-1][j][k][0] ) + c22*( stress[i+2][j][k][0]-stress[i-2][j][k][0] )
          +c33*( stress[i+3][j][k][0]-stress[i-3][j][k][0] ) + c44*( stress[i+4][j][k][0]-stress[i-4][j][k][0] );

   dsxxdy= c11*( stress[i][j+1][k][0]-stress[i][j-1][k][0] ) + c22*( stress[i][j+2][k][0]-stress[i][j-2][k][0] )
          +c33*( stress[i][j+3][k][0]-stress[i][j-3][k][0] ) + c44*( stress[i][j+4][k][0]-stress[i][j-4][k][0] );

   dsxxdz=(dx/dz)*( c11*( stress[i][j][k+1][0]-stress[i][j][k-1][0] ) + c22*( stress[i][j][k+2][0]-stress[i][j][k-2][0] )
                   +c33*( stress[i][j][k+3][0]-stress[i][j][k-3][0] ) + c44*( stress[i][j][k+4][0]-stress[i][j][k-4][0] ) ) ;

   dszzdx=c11*( stress[i+1][j][k][1]-stress[i-1][j][k][1] ) + c22*( stress[i+2][j][k][1]-stress[i-2][j][k][1] )
         +c33*( stress[i+3][j][k][1]-stress[i-3][j][k][1] ) + c44*( stress[i+3][j][k][1]-stress[i-3][j][k][1] );

   dszzdy=c11*( stress[i][j+1][k][1]-stress[i][j-1][k][1] ) + c22*( stress[i][j+2][k][1]-stress[i][j-2][k][1] )
         +c33*( stress[i][j+3][k][1]-stress[i][j-3][k][1] ) + c44*( stress[i][j+4][k][1]-stress[i][j-4][k][1] );

   dszzdz=(dx/dz)*( c11*( stress[i][j][k+1][1]-stress[i][j][k-1][1] ) + c22*( stress[i][j][k+2][1]-stress[i][j][k-2][1] )
                   +c33*( stress[i][j][k+3][1]-stress[i][j][k-3][1] ) + c44*( stress[i][j][k+4][1]-stress[i][j][k-4][1] ) ) ;

// Equations 13a in Duvenck et al
   updateX =  (R[i][j][k][0]*R[i][j][k][0]+R[i][j][k][1]*R[i][j][k][1])*dsxxdx
            + (dr00dx[i-order][j-order][k-order]+dr11dx[i-order][j-order][k-order])*stress[i][j][k][0]
            + (R[i][j][k][2]*R[i][j][k][2])*dszzdx
            + dr22dx[i-order][j-order][k-order]*stress[i][j][k][1] ;

   updateY = (R[i][j][k][0]*R[i][j][k][3]+R[i][j][k][1]*R[i][j][k][4])*dsxxdy
            + (dr03dy[i-order][j-order][k-order]+dr14dy[i-order][j-order][k-order])*stress[i][j][k][0]
           + (R[i][j][k][2]*R[i][j][k][5])*dszzdy
            + dr25dy[i-order][j-order][k-order]*stress[i][j][k][1] ;

   updateZ = (R[i][j][k][0]*R[i][j][k][6]+R[i][j][k][1]*R[i][j][k][7])*dsxxdz
            + (dr06dz[i-order][j-order][k-order]+dr17dz[i-order][j-order][k-order])*stress[i][j][k][0]
            +(R[i][j][k][2]*R[i][j][k][8])*dszzdz
            + dr28dz[i-order][j-order][k-order]*stress[i][j][k][1] ;

   u[i][j][k][0] = u[i][j][k][0] + dxx[i-order]*dyy[j-order]*dzz[k-order]*
                                  (dt*(updateX+updateY+updateZ)/dens[i-order][j-order][k-order]);

// Equations 13a in Duvenck et al
   updateX = (R[i][j][k][3]*R[i][j][k][0]+R[i][j][k][4]*R[i][j][k][1])*dsxxdx
           + (dr03dx[i-order][j-order][k-order]+dr14dx[i-order][j-order][k-order])*stress[i][j][k][0]
           + (R[i][j][k][5]*R[i][j][k][2])*dszzdx
           + dr25dx[i-order][j-order][k-order]*stress[i][j][k][1] ;

   updateY = (R[i][j][k][3]*R[i][j][k][3]+R[i][j][k][4]*R[i][j][k][4])*dsxxdy
           + (dr33dy[i-order][j-order][k-order]+dr44dy[i-order][j-order][k-order])*stress[i][j][k][0]
           + (R[i][j][k][5]*R[i][j][k][5])*dszzdy
           + dr55dy[i-order][j-order][k-order]*stress[i][j][k][1] ;

   updateZ = (R[i][j][k][3]*R[i][j][k][6]+R[i][j][k][4]*R[i][j][k][7])*dsxxdz 
           + (dr36dz[i-order][j-order][k-order]+dr47dz[i-order][j-order][k-order])*stress[i][j][k][0]
           + (R[i][j][k][5]*R[i][j][k][8])*dszzdz
           + dr58dz[i-order][j-order][k-order]*stress[i][j][k][1] ;

   u[i][j][k][1] = u[i][j][k][1] + dxx[i-order]*dyy[j-order]*dzz[k-order]*
                                   (dt*(updateX+updateY+updateZ)/dens[i-order][j-order][k-order]);

// Equations 13a in Duvenck et al
   updateX = (R[i][j][k][0]*R[i][j][k][6]+R[i][j][k][7]*R[i][j][k][1])*dsxxdx
           + (dr06dx[i-order][j-order][k-order]+dr17dx[i-order][j-order][k-order])*stress[i][j][k][0]
           + (R[i][j][k][8]*R[i][j][k][2])*dszzdx
           + dr28dx[i-order][j-order][k-order]*stress[i][j][k][1] ;

   updateY = (R[i][j][k][6]*R[i][j][k][3]+R[i][j][k][7]*R[i][j][k][4])*dsxxdy 
           + (dr36dy[i-order][j-order][k-order]+dr47dy[i-order][j-order][k-order])*stress[i][j][k][0]
           + (R[i][j][k][8]*R[i][j][k][5])*dszzdy 
           + dr58dy[i-order][j-order][k-order]*stress[i][j][k][1] ;

   updateZ = (R[i][j][k][6]*R[i][j][k][6]+R[i][j][k][7]*R[i][j][k][7])*dsxxdz 
           + (dr66dz[i-order][j-order][k-order]+dr77dz[i-order][j-order][k-order])*stress[i][j][k][0]
           + (R[i][j][k][8]*R[i][j][k][8])*dszzdz 
           + dr88dz[i-order][j-order][k-order]*stress[i][j][k][1] ;

   u[i][j][k][2] = u[i][j][k][2] + dxx[i-order]*dyy[j-order]*dzz[k-order]*
                                   (dt*(updateX+updateY+updateZ)/dens[i-order][j-order][k-order]);

////////////////////////////////////// VTI
/*
// 8th order cd of horizontal and vertical stress
 // can replace with pointer arithmetic to speed up?

  dsxxdx= c11*( stress[i+1][j][k][0]-stress[i-1][j][k][0] ) + c22*( stress[i+2][j][k][0]-stress[i-2][j][k][0] )
          +c33*( stress[i+3][j][k][0]-stress[i-3][j][k][0] ) + c44*( stress[i+4][j][k][0]-stress[i-4][j][k][0] );

   dsxxdy=c11*( stress[i][j+1][k][0]-stress[i][j-1][k][0] ) + c22*( stress[i][j+2][k][0]-stress[i][j-2][k][0] )
         +c33*( stress[i][j+3][k][0]-stress[i][j-3][k][0] ) + c44*( stress[i][j+4][k][0]-stress[i][j-4][k][0] );

   dszzdz=(dx/dz)*( c11*( stress[i][j][k+1][1]-stress[i][j][k-1][1] ) + c22*( stress[i][j][k+2][1]-stress[i][j][k-2][1] )
                   +c33*( stress[i][j][k+3][1]-stress[i][j][k-3][1] ) + c44*( stress[i][j][k+4][1]-stress[i][j][k-4][1] ) ) ;

   u[i][j][k][0] = u[i][j][k][0] + dxx[i-order]*dyy[j-order]*dzz[k-order]*
                                  (dt*(dsxxdx)/dens[i-order][j-order][k-order]);

   u[i][j][k][1] = u[i][j][k][1] + dxx[i-order]*dyy[j-order]*dzz[k-order]*
                                   (dt*(dsxxdy)/dens[i-order][j-order][k-order]);

   u[i][j][k][2] = u[i][j][k][2] + dxx[i-order]*dyy[j-order]*dzz[k-order]*
                                   (dt*(dszzdz)/dens[i-order][j-order][k-order]);
*/
////////////////////////////////////// ACOUSTIC
/*
// 8th order cd of horizontal and vertical stress
 // can replace with pointer arithmetic to speed up?
  dsxxdx= c11*( stress[i+1][j][k][0]-stress[i-1][j][k][0] ) + c22*( stress[i+2][j][k][0]-stress[i-2][j][k][0] )
          +c33*( stress[i+3][j][k][0]-stress[i-3][j][k][0] ) + c44*( stress[i+4][j][k][0]-stress[i-4][j][k][0] );

   dsxxdy=c11*( stress[i][j+1][k][0]-stress[i][j-1][k][0] ) + c22*( stress[i][j+2][k][0]-stress[i][j-2][k][0] )
         +c33*( stress[i][j+3][k][0]-stress[i][j-3][k][0] ) + c44*( stress[i][j+4][k][0]-stress[i][j-4][k][0] );

   dsxxdz=(dx/dz)*( c11*( stress[i][j][k+1][0]-stress[i][j][k-1][0] ) + c22*( stress[i][j][k+2][0]-stress[i][j][k-2][0] )
                   +c33*( stress[i][j][k+3][0]-stress[i][j][k-3][0] ) + c44*( stress[i][j][k+4][0]-stress[i][j][k-4][0] ) ) ;

   u[i][j][k][0] = u[i][j][k][0] + dxx[i-order]*dyy[j-order]*dzz[k-order]*
                                  (dt*(dsxxdx)/dens[i-order][j-order][k-order]);

   u[i][j][k][1] = u[i][j][k][1] + dxx[i-order]*dyy[j-order]*dzz[k-order]*
                                  (dt*(dsxxdy)/dens[i-order][j-order][k-order]);

   u[i][j][k][2] = u[i][j][k][2] + dxx[i-order]*dyy[j-order]*dzz[k-order]*
                                  (dt*(dsxxdz)/dens[i-order][j-order][k-order]);

*/
 }
 }
 }

//printf("%d \t%d %d %d \t%d\n",my_rank,Nxx,Nyy,Nzz,order);

}


/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////

// Diff of the velocities to get the stress
void update_stress()
{
 int i,j,k;
 double updateX,updateY,updateZ;
 double c11,c22,c33,c44;
 double E,D,V;

 // FD coefficients
 c11=c1/dx;
 c22=c2/dx;
 c33=c3/dx;
 c44=c4/dx;

 for(i=order; i<Nx+order; i++)
 {
 for(j=order; j<Ny+order; j++)
 {
 for(k=order; k<Nz+order; k++)
 {
////////////////////////////////////// TTI
// 8th order FD of velocities
// can replace with pointer arithmetic to speed up?
    dudx=c11*( u[i+1][j][k][0]-u[i-1][j][k][0] ) + c22*( u[i+2][j][k][0]-u[i-2][j][k][0] )
        +c33*( u[i+3][j][k][0]-u[i-3][j][k][0] ) + c44*( u[i+4][j][k][0]-u[i-4][j][k][0] );

    dudy=c11*( u[i][j+1][k][0]-u[i][j-1][k][0] ) + c22*( u[i][j+2][k][0]-u[i][j-2][k][0] )
        +c33*( u[i][j+3][k][0]-u[i][j-3][k][0] ) + c44*( u[i][j+4][k][0]-u[i][j-4][k][0] );

    dudz=(dx/dz)*( c11*( u[i][j][k+1][0]-u[i][j][k-1][0] ) + c22*( u[i][j][k+2][0]-u[i][j][k-2][0] )
                  +c33*( u[i][j][k+3][0]-u[i][j][k-3][0] ) + c44*( u[i][j][k+4][0]-u[i][j][k-4][0] ) ) ;

    dvdx=c11*( u[i+1][j][k][1]-u[i-1][j][k][1] ) + c22*( u[i+2][j][k][1]-u[i-2][j][k][1] )
        +c33*( u[i+3][j][k][1]-u[i-3][j][k][1] ) + c44*( u[i+4][j][k][1]-u[i-4][j][k][1] );

    dvdy=c11*( u[i][j+1][k][1]-u[i][j-1][k][1] ) + c22*( u[i][j+2][k][1]-u[i][j-2][k][1] )
        +c33*( u[i][j+3][k][1]-u[i][j-3][k][1] ) + c44*( u[i][j+4][k][1]-u[i][j-4][k][1] );

    dvdz=(dx/dz)*( c11*( u[i][j][k+1][1]-u[i][j][k-1][1] ) + c22*( u[i][j][k+2][1]-u[i][j][k-2][1] )
                  +c33*( u[i][j][k+3][1]-u[i][j][k-3][1] ) + c44*( u[i][j][k+4][1]-u[i][j][k-4][1] ) ) ;

    dwdx=c11*( u[i+1][j][k][2]-u[i-1][j][k][2] ) + c22*( u[i+2][j][k][2]-u[i-2][j][k][2] )
        +c33*( u[i+3][j][k][2]-u[i-3][j][k][2] ) + c44*( u[i+4][j][k][2]-u[i-4][j][k][2] );

    dwdy=c11*( u[i][j+1][k][2]-u[i][j-1][k][2] ) + c22*( u[i][j+2][k][2]-u[i][j-2][k][2] )
        +c33*( u[i][j+3][k][2]-u[i][j-3][k][2] ) + c44*( u[i][j+4][k][2]-u[i][j-4][k][2] );

    dwdz=(dx/dz)*( c11*( u[i][j][k+1][2]-u[i][j][k-1][2] ) + c22*( u[i][j][k+2][2]-u[i][j][k-2][2] )
                  +c33*( u[i][j][k+3][2]-u[i][j][k-3][2] ) + c44*( u[i][j][k+4][2]-u[i][j][k-4][2] ) ) ;

// Equations 13a in Duvenck et al
    D=sqrt(1.0+2.0*delta[i-order][j-order][k-order]);
    E=(1.0+2.0*eps[i-order][j-order][k-order]);
    V=dens[i-order][j-order][k-order]*velp[i-order][j-order][k-order]*velp[i-order][j-order][k-order];

    stress[i][j][k][0] = stress[i][j][k][0] + gauss[i-order][j-order][k-order]*source[time1]*sscale
                 + dxx[i-order]*dyy[j-order]*dzz[k-order]*dt*V*(
                 ( E*R[i][j][k][0]*R[i][j][k][0] + E*R[i][j][k][1]*R[i][j][k][1] + D*R[i][j][k][2]*R[i][j][k][2]  )*dudx +
                 ( E*R[i][j][k][3]*R[i][j][k][0] + E*R[i][j][k][4]*R[i][j][k][1] + D*R[i][j][k][5]*R[i][j][k][2]  )*dvdx +
                 ( E*R[i][j][k][6]*R[i][j][k][0] + E*R[i][j][k][7]*R[i][j][k][1] + D*R[i][j][k][8]*R[i][j][k][2]  )*dwdx +
                 ( E*R[i][j][k][0]*R[i][j][k][3] + E*R[i][j][k][1]*R[i][j][k][4] + D*R[i][j][k][2]*R[i][j][k][5]  )*dudy +
                 ( E*R[i][j][k][3]*R[i][j][k][3] + E*R[i][j][k][4]*R[i][j][k][4] + D*R[i][j][k][5]*R[i][j][k][5]  )*dvdy +
                 ( E*R[i][j][k][6]*R[i][j][k][3] + E*R[i][j][k][7]*R[i][j][k][4] + D*R[i][j][k][8]*R[i][j][k][5]  )*dwdy +
                 ( E*R[i][j][k][0]*R[i][j][k][6] + E*R[i][j][k][1]*R[i][j][k][7] + D*R[i][j][k][2]*R[i][j][k][8]  )*dudz +
                 ( E*R[i][j][k][3]*R[i][j][k][6] + E*R[i][j][k][4]*R[i][j][k][7] + D*R[i][j][k][5]*R[i][j][k][8]  )*dvdz +
                 ( E*R[i][j][k][6]*R[i][j][k][6] + E*R[i][j][k][7]*R[i][j][k][7] + D*R[i][j][k][8]*R[i][j][k][8]  )*dwdz );

    stress[i][j][k][1] = stress[i][j][k][1] + gauss[i-order][j-order][k-order]*source[time1]*sscale
                 + dxx[i-order]*dyy[j-order]*dzz[k-order]*dt*V*(
                 ( D*R[i][j][k][0]*R[i][j][k][0] + D*R[i][j][k][1]*R[i][j][k][1] + R[i][j][k][2]*R[i][j][k][2]  )*dudx +
                 ( D*R[i][j][k][3]*R[i][j][k][0] + D*R[i][j][k][4]*R[i][j][k][1] + R[i][j][k][5]*R[i][j][k][2]  )*dvdx +
                 ( D*R[i][j][k][6]*R[i][j][k][0] + D*R[i][j][k][7]*R[i][j][k][1] + R[i][j][k][8]*R[i][j][k][2]  )*dwdx +
                 ( D*R[i][j][k][0]*R[i][j][k][3] + D*R[i][j][k][1]*R[i][j][k][4] + R[i][j][k][2]*R[i][j][k][5]  )*dudy +
                 ( D*R[i][j][k][3]*R[i][j][k][3] + D*R[i][j][k][4]*R[i][j][k][4] + R[i][j][k][5]*R[i][j][k][5]  )*dvdy +
                 ( D*R[i][j][k][6]*R[i][j][k][3] + D*R[i][j][k][7]*R[i][j][k][4] + R[i][j][k][8]*R[i][j][k][5]  )*dwdy +
                 ( D*R[i][j][k][0]*R[i][j][k][6] + D*R[i][j][k][1]*R[i][j][k][7] + R[i][j][k][2]*R[i][j][k][8]  )*dudz +
                 ( D*R[i][j][k][3]*R[i][j][k][6] + D*R[i][j][k][4]*R[i][j][k][7] + R[i][j][k][5]*R[i][j][k][8]  )*dvdz +
                 ( D*R[i][j][k][6]*R[i][j][k][6] + D*R[i][j][k][7]*R[i][j][k][7] + R[i][j][k][8]*R[i][j][k][8]  )*dwdz );

////////////////////////////////////// VTI
/*
// 8th order FD of velocities
// can replace with pointer arithmetic to speed up?
    dudx=c11*( u[i+1][j][k][0]-u[i-1][j][k][0] ) + c22*( u[i+2][j][k][0]-u[i-2][j][k][0] )
        +c33*( u[i+3][j][k][0]-u[i-3][j][k][0] ) + c44*( u[i+4][j][k][0]-u[i-4][j][k][0] );

    dvdy=c11*( u[i][j+1][k][1]-u[i][j-1][k][1] ) + c22*( u[i][j+2][k][1]-u[i][j-2][k][1] )
        +c33*( u[i][j+3][k][1]-u[i][j-3][k][1] ) + c44*( u[i][j+4][k][1]-u[i][j-4][k][1] );

    dwdz=(dx/dz)*( c11*( u[i][j][k+1][2]-u[i][j][k-1][2] ) + c22*( u[i][j][k+2][2]-u[i][j][k-2][2] )
                  +c33*( u[i][j][k+3][2]-u[i][j][k-3][2] ) + c44*( u[i][j][k+4][2]-u[i][j][k-4][2] ) ) ;

    D=sqrt(1.0+2.0*delta[i-order][j-order][k-order]);
    E=(1.0+2.0*eps[i-order][j-order][k-order]);
    V=dens[i-order][j-order][k-order]*velp[i-order][j-order][k-order]*velp[i-order][j-order][k-order];

    stress[i][j][k][0] = stress[i][j][k][0] + dxx[i-order]*dyy[j-order]*dzz[k-order]*dt*V*(
                         E*dudx + E*dvdy + D*dwdz )
                         + gauss[i-order][j-order][k-order]*source[time1]*sscale;

    stress[i][j][k][1] = stress[i][j][k][1] + dxx[i-order]*dyy[j-order]*dzz[k-order]*dt*V*(
                         D*dudx + D*dvdy + dwdz )
                         + gauss[i-order][j-order][k-order]*source[time1]*sscale;
*/
////////////////////////////////////// ACOUSTIC
// 8th order FD of velocities
/*
// can replace with pointer arithmetic to speed up?
    dudx=c11*( u[i+1][j][k][0]-u[i-1][j][k][0] ) + c22*( u[i+2][j][k][0]-u[i-2][j][k][0] )
        +c33*( u[i+3][j][k][0]-u[i-3][j][k][0] ) + c44*( u[i+4][j][k][0]-u[i-4][j][k][0] );

    dvdy=c11*( u[i][j+1][k][1]-u[i][j-1][k][1] ) + c22*( u[i][j+2][k][1]-u[i][j-2][k][1] )
        +c33*( u[i][j+3][k][1]-u[i][j-3][k][1] ) + c44*( u[i][j+4][k][1]-u[i][j-4][k][1] );

    dwdz=(dx/dz)*( c11*( u[i][j][k+1][2]-u[i][j][k-1][2] ) + c22*( u[i][j][k+2][2]-u[i][j][k-2][2] )
                  +c33*( u[i][j][k+3][2]-u[i][j][k-3][2] ) + c44*( u[i][j][k+4][2]-u[i][j][k-4][2] ) ) ;

    V=dens[i-order][j-order][k-order]*velp[i-order][j-order][k-order]*velp[i-order][j-order][k-order];
    stress[i][j][k][0] = stress[i][j][k][0] + dxx[i-order]*dyy[j-order]*dzz[k-order]*dt*V*(
                      dudx + dvdy + dwdz ) + gauss[i-order][j-order][k-order]*source[time1]*sscale;
    stress[i][j][k][1] = stress[i][j][k][0];
*/
  }
  }
  }

 if(free_surface==1)
 {
  for(i=order; i<Nx+order; i++)
  {
  for(j=order; j<Ny+order; j++)
  {
   //stress[i][j][Nz-Width-1][1] = 0.0;
   for(k=Nz-Width; k<Nz+order; k++)
   {
    stress[i][j][k][0] = 0.0;
    stress[i][j][k][1] = 0.0;
    u[i][j][k][0]=0.0;
    u[i][j][k][1]=0.0;
    u[i][j][k][2]=0.0;
   }
  }
  }
 }

}

/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////