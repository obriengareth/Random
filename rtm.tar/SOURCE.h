
// Source Routine
void source_routine_forward_shot()
{
 int time_loop,i,j,k,n;
 double max_so;
 FILE *input,*out_source;
 char file_name[50];

// allocating source time function
 source=alloc1d(Max_Time+1);

// loading in source time function
 max_so=0.0;
 sprintf(file_name,"%s",input6); 
 if(( input = fopen(file_name,"r")) ==NULL )
 {
     printf("Error 1001: opening source file on node %d\n",my_rank);
     MPI_Finalize();
     exit(0);
 }
 for(time_loop=0; time_loop<=Max_Time; time_loop++)
 {
   source[time_loop]=0;
   fscanf(input,"%lf\n",&source[time_loop]);

   if(max_so<fabs(source[time_loop]))
   max_so=fabs(source[time_loop]);

 }
 fclose(input);


// opening in source locations
// counting number of sources
 int c,fileLen,count;
 double aa,bb,cc;
 char value;

 if(( input= fopen(input7,"r")) == NULL )
 {
     printf("Error 1002: opening source file on node %d\n",my_rank);
     MPI_Finalize();
     exit(0);
 }

 count=0;
 while(( c=getc(input))!=EOF)
 {
    value=c;
    if(value=='\n')
    count++;
 }
 NumSource=count;
 xsource=alloc1d_int(NumSource);
 ysource=alloc1d_int(NumSource);
 zsource=alloc1d_int(NumSource);
 fclose(input);

// loading source locations
 if(( input= fopen(input7,"r")) == NULL )
 {
     printf("Error 1003: opening source file on node %d\n",my_rank);
     MPI_Finalize();
     exit(0);
 }
 for(i=0; i<NumSource; i++)
 {
  fscanf(input,"%lf %lf %lf\n",&aa,&bb,&cc); 
  xsource[i]=(int) ((aa-OX)/dx)+Width;
  ysource[i]=(int) ((bb-OY)/dx)+Width;
  zsource[i]=(int) Nz-Width-((cc-OZ)/dz);
 }
 fclose(input);

 for(i=0; i<NumSource; i++)
 {
  if( xsource[i]<0 || xsource[i]>=Nxx*my_size || ysource[i]<0 || ysource[i]>=Nyy || zsource[i]<0 || zsource[i]>=Nzz )
  {
   xsource[i]=0;
   ysource[i]=0;
   zsource[i]=0;
  }
 }

/*if(my_rank==0)
{
printf("-------------------------------------------\n");
printf("Outputting source grid coordinates\n");
for(i=0; i<NumSource; i++)
printf("%d %d %d\n",xsource[i],ysource[i],zsource[i]);
printf("-------------------------------------------\n");
}*/

//////////////////////////////////////////////////////////////////////
// allocating gaussian volume for source
 gauss = alloc3d(Nx,Ny,Nz);
/* double alpha1=4.5*dx;

 for(n=0; n<NumSource; n++)
 {
  for(i=0; i<Nx; i++)
  {
  for(j=0; j<Ny; j++)
  {
  for(k=0; k<Nz; k++)
  {
    // Gaussian 3D pulse for source implementation
    gauss[i][j][k]=gauss[i][j][k]+dens[i][j][k]*Gauss( dx*(xsource[n]-i-Nx*my_rank),dx*(ysource[n]-(j)),dz*(zsource[n]-(k)),alpha1);

    // to avoid generation of source S-waves set epsilon=delta
    if(gauss[i][j][k]>=0.05)
    {
      // delta[i][j][k]=eps[i][j][k];
    }
  }
  }
  }
 }*/

}

////////////////////////////////////////////////////////////////////////////////////////////////


// Source Routine
void source_routine_reverse_data0()
{
 int time_loop,i,j,k,n;
 double max_so;
 FILE *input,*out_source;
 char file_name[50];

// opening in reverse data source locations
// counting number of sources
 int c,fileLen,count;
 double aa,bb,cc,dd;
 char value;

 if(( input= fopen(input10,"r")) == NULL )
 {
     printf("Error 1012: opening source file on node %d\n",my_rank);
     MPI_Finalize();
     exit(0);
 }

 count=0;
 while(( c=getc(input))!=EOF)
 {
    value=c;
    if(value=='\n')
    count++;
 }
 NumSourceD=count;
 xsourceD=alloc1d_int(NumSourceD);
 ysourceD=alloc1d_int(NumSourceD);
 zsourceD=alloc1d_int(NumSourceD);
 fclose(input);

// loading data source locations
 if(( input= fopen(input10,"r")) == NULL )
 {
     printf("Error 1013: opening source file on node %d\n",my_rank);
     MPI_Finalize();
     exit(0);
 }
 for(i=0; i<NumSourceD; i++)
 {
  fscanf(input,"%lf %lf %lf\n",&aa,&bb,&cc); 
  xsourceD[i]=(int) ((aa-OX)/dx)+Width;
  ysourceD[i]=(int) ((bb-OY)/dx)+Width;
  zsourceD[i]=(int) Nz-Width-((cc-OZ)/dz);
 }
 fclose(input);

 for(i=0; i<NumSourceD; i++)
 {
  if( xsourceD[i]<0 || xsourceD[i]>=Nxx*my_size || ysourceD[i]<0 || ysourceD[i]>=Nyy || zsourceD[i]<0 || zsourceD[i]>=Nzz )
  {
   xsourceD[i]=0;
   ysourceD[i]=0;
   zsourceD[i]=0;
  }
 }

/*if(my_rank==0)
{
printf("-------------------------------------------\n");
printf("Outputting reverse data grid coordinates\n");
for(i=0; i<NumSourceD; i++)
printf("%d %d %d\n",xsourceD[i],ysourceD[i],zsourceD[i]);
printf("Number of sources into reverse wavefield %d \n",NumSourceD);
printf("-------------------------------------------\n");
}*/

/////////////////////////////////////////////////////////////////////

// allocating source time function
 sourceZ=alloc2d(Max_Time+1,NumSourceD);
 gaussR = alloc3d(Nx,Ny,Nz);


}

// Source Routine
void source_routine_reverse_data()
{
 int time_loop,i,j,k,n;
 double max_so;
 FILE *input,*out_source;
 char file_name[50];
 int c,fileLen,count;
 double aa,bb,cc,dd;
 char value;
 double sourceTemp[Max_Time+1];
 double norm_source;


// loading in data source time function
 for(i=0; i<NumSourceD; i++)
 {
  norm_source=0;
  sprintf(file_name,"%s%d/reverse%d",input11,shot_no,i); 
  if(( input = fopen(file_name,"r")) ==NULL )
  {
     printf("Error 1011: opening source file %s%d/reverse%d on node %d \n",input11,shot_no,i,my_rank);
     MPI_Finalize();
     exit(0);
  }
  for(time_loop=0; time_loop<=Max_Time; time_loop++)
  {
   fscanf(input,"%lf %lf %lf %lf\n",&aa,&bb,&cc,&dd);
   //if(i==0)
   //printf("%d %e %e %e %e\n",time_loop,aa,bb,cc,dd);
   sourceTemp[time_loop]=cc;

   // normalising each source to sscaleR
   if( norm_source<fabs(sourceTemp[time_loop]) )
   norm_source=fabs(sourceTemp[time_loop]);

  }
  fclose(input);

  if( norm_source==0.0 )
  norm_source=1.0;

  for(time_loop=0; time_loop<=Max_Time; time_loop++)
  {
   sourceZ[time_loop][i] = sscaleR * sourceTemp[Max_Time-time_loop]/norm_source;
   //printf("%d %d %e\n",my_rank,time_loop,sourceZ[time_loop][i]);
  }
 }

////////////////////////////////////////////////////////////////////////////////////////////////
 double alpha1=4.5*dx;
 for(i=0; i<Nx; i++)
 {
 for(j=0; j<Ny; j++)
 {
 for(k=0; k<Nz; k++)
 {
  gaussR[i][j][k] =  0.0;
 }
 }
 }

 for(n=0; n<NumSourceD; n++)
 {
 for(i=0; i<Nx; i++)
 {
 for(j=0; j<Ny; j++)
 {
 for(k=0; k<Nz; k++)
 {
  gaussR[i][j][k] =  gaussR[i][j][k] + Gauss( dx*(xsourceD[n]-i-Nx*my_rank),dx*(ysourceD[n]-j),dx*(zsourceD[n]-k),alpha1);
 }
 }
 }
 }


}



////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////

void source_reverse()
{
 int i,ii,j,k,n;
 int xdir,ydir,zdir;

// playing in vertical velocity source over a finite volume of points
 for(n=0; n<NumSourceD; n++)
 {
  for(xdir=-1; xdir<2; xdir++)
  {
  for(ydir=-1; ydir<2; ydir++)
  {
  for(zdir=-1; zdir<2; zdir++)
  {
    i=xsourceD[n]+xdir;
    j=ysourceD[n]+ydir+order;
    k=zsourceD[n]+zdir+order;

    if(i>=0 && i<Nx*my_size && j>=order && j<Nyy && k>=order && k<Nzz)
    {
     if(locate_node(i)==my_rank)
     {
      ii=i%Nx;
      //uR[ii+order][j][k][2] = uR[ii+order][j][k][2] + gaussR[ii][j-order][k-order]*sourceD[time1][n];
      uR[ii+order][j][k][2] = uR[ii+order][j][k][2] + sourceZ[time1][n]/27.0;
     }
    }
  }
  }
  }
 }

// need to add in other directions and possible pressure source for marine

}

////////////////////////////////////////////////////////////////////////////////////////////////

