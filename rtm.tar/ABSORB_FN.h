////////////////////////////////////////////////////////////////////
// Random boundaries and absorbing boundary
void absorb_fn()
{
 int i,j,k;
 double randomise,d0,new_vel,drop_value;

/////////////////////////////////////////////////////////////////////
// allocating taper functions

 dxx = alloc1d(Nx);
 dyy = alloc1d(Ny);
 dzz = alloc1d(Nz);

/////////////////////////////////////////////////////////////////////
// Z
 for(k=0; k<Nz; k++)
 {
  dzz[k]=1.0;
  if(k<Width)
  {
    dzz[k]=exp( -lambda*(Width-k)*(Width-k) );
  }
  else if(k>Nz-Width)
  {
    dzz[k]=exp( -lambda*(-Nz+Width+k)*(-Nz+Width+k) );
  }
 }

// Y
 for(j=0; j<Ny; j++)
 {
  dyy[j]=1.0;
  if(j<Width)
  {
    dyy[j]=exp( -lambda*(Width-j)*(Width-j) );
  }
  else if(j>Ny-Width)
  {
    dyy[j]=exp( -lambda*(-Ny+Width+j)*(-Ny+Width+j) );
  }
 }

// X
 for(i=0; i<Nx; i++)
 {
  dxx[i]=1.0;
  if( (i+my_rank*Nx) < Width)
  {
    dxx[i]=exp(-lambda*(Width-i-my_rank*Nx)*(Width-i-my_rank*Nx));
  }
  else if( (i+my_rank*Nx) > Nx*(my_size)-Width)
  {
    dxx[i]=exp(-lambda*(i+my_rank*Nx-Nx*(my_size)+Width)*(i+my_rank*Nx-Nx*(my_size)+Width));
  }
 }

/////////////////////////////////////////////////////////////////////
// adding in random boundaries

 max_vel=0.0;
 d0=exp(-lambda*Width*Width)*exp(-lambda*Width*Width)*exp(-lambda*Width*Width);
 for(i=0; i<Nx; i++)
 {
 for(j=0; j<Ny; j++)
 {
 for(k=0; k<Nz; k++)
 {
   // droping velocity as moving towards boundary and increasing randomness
   drop_value=(vdrop-1.0)*(1.0-dxx[i]*dyy[j]*dzz[k])/(1.0-d0) + 1.0 ;
   randomise = ((1.0-dxx[i]*dyy[j]*dzz[k])/(1.0-d0));
   new_vel = velp0[i][j][k]*drop_value  + randvalue*randomise*( max_vel - 2.0*ranf()*max_vel ) ;

   if(new_vel>0.1*velp0[i][j][k] && velp0[i][j][k]!=0.0 && velp0[i][j][k]!=330.0)
   {
    velp[i][j][k]=new_vel; 
   }

   if(velp0[i][j][k]==0.0)
   {
     dzz[k]=0.0;
   }
   if(velp0[i][j][k]==330.0)
   {
     dzz[k]=0.0;
   }

   if(max_vel<velp[i][j][k])
   max_vel=velp[i][j][k];
 }
 }
 }
/////////////////////////////////////////////////////////////////////

}
