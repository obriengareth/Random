
// Outputs snap shots of the wavefield ever snap_freq time steps
/*
void wavefield()
{
 int i,j,k;
 char file_name[50];
 FILE *output;

 sprintf(file_name,"TEMP%d_%d",count_snaps,my_rank);
 if(( output= fopen(file_name,"w")) ==NULL )
 {
   printf("Error 301 opening snap file on node %d at time %d\n",my_rank,time1);
   MPI_Finalize();
   exit(0);
 }

 for(i=order; i<Nx+order; i=i+LR)
 {
 for(j=order; j<Ny+order; j=j+LR)
 { 
 for(k=order; k<Nz+order; k=k+LR)
 {
   fprintf(output,"%e %e %e %e\n",uR[i][j][k][0],uR[i][j][k][1],uR[i][j][k][2],(stressR[i][j][k][0]+stressR[i][j][k][1]) );
 }
 }
 }
 fclose(output);

}

// merging temp files from individual nodes
void merge_wavefield()
{
 int i,j,n,l;
 double a,b,c,d,aa[4];
 char file_name[50];
 FILE *output,*input[my_size];

for(n=0; n<no_snap; n++)
{
    sprintf(file_name,"%s%d",output2,n);
    if(( output = fopen(file_name,"w")) ==NULL )
    {
       printf("Error 4004 opening snap file on node %d at time %d\n",my_rank,time1);
       MPI_Finalize();
       exit(0);
    }
    for(j=0; j<my_size; j++)
    {
        sprintf(file_name,"TEMP%d_%d",n,j);
	if(( input[j] = fopen(file_name,"r")) ==NULL )
        {
          printf("Error 3456 merging file %s on node %d\n",file_name,j);
          MPI_Finalize();
          exit(0);
        }

      for(i=0;i<lr_count; i++)
      {
        fscanf(input[j],"%lf %lf %lf %lf\n",&a,&b,&c,&d);
	aa[0]=a; aa[1]=b;  aa[2]=c; aa[3]=d;
        fwrite(&aa, sizeof(double), 4, output);
      }

    }

    for(i=0; i<my_size; i++)
    {
      sprintf(file_name,"TEMP%d_%d",n,i);
      remove(file_name);
    }
    fclose(output);
}

}    // end of routine
*/

////////////////////////////////////////////////////////////////////////////////////////////////////
// Output Velocity Model
void output_velmodel()
{
   int i,j,k,n,l;
   double a,b,c,aa[1];
   char file_name[50];
   FILE *output,*input[my_size];

 if(my_rank==0)
 printf("Writing out velocity model used for RTM\n");

// writing out vel on individual codes
 sprintf(file_name,"TEMP_VEL_%d",my_rank);
 if(( output= fopen(file_name,"w")) ==NULL )
 {
   printf("Error 1235 opening snap file on node %d at time %d\n",my_rank,time1);
   MPI_Finalize();
   exit(0);
 }

 for(i=0; i<Nx; i=i++)
 {
 for(j=0; j<Ny; j=j++)
 {
 for(k=0; k<Nz; k=k++)
 {
     fprintf(output,"%e \n",velp[i][j][k]);

     //fprintf(output,"%e\n",gaussR[i][j][k]);
     //fprintf(output,"%e\n",gauss[i][j][k]);
     //fprintf(output,"%e \n",dr44dy[i][j][k] );
     //fprintf(output,"%e \n",R[i+order][j+order][k+order][4]);
     //fprintf(output,"%e \n",dxx[i]*dyy[j]*dzz[k]);
     //fprintf(output,"%e \n",dens[i][j][k]);
 }
 }
 }
 fclose(output);

 MPI_Barrier(new_comm);

 // combining all core outs into single file
 if(my_rank==0)
 {
    sprintf(file_name,"INOUT_VP_RTM");
    if(( output = fopen(file_name,"w")) ==NULL )
    {
       printf("Error 1234 opening snap file on node %d\n",my_rank);
       MPI_Finalize();
       exit(0);
    }
    for(j=0; j<my_size; j++)
    {

      sprintf(file_name,"TEMP_VEL_%d",j);
      if(( input[j] = fopen(file_name,"r")) ==NULL )
      {
          printf("Error 1212 merging file %s on node %d\n",file_name,j);
          MPI_Finalize();
          exit(0);
      }

      for(i=0;i<Nx*Ny*Nz; i++)
      {
        fscanf(input[j],"%lf \n",&a);
	aa[0]=a; //aa[1]=b;  aa[2]=c;
        fwrite(&aa, sizeof(double), 1, output);
      }

    }

    for(i=0; i<my_size; i++)
    {
      sprintf(file_name,"TEMP_VEL_%d",i);
      remove(file_name);
    }
    fclose(output);
  }

}

////////////////////////////////////////////////////////////////////////////////////////////////////
void image_dump()
{
 int i,j,k;
 float aa[1];
 char file_name[50];
 FILE *outputa,*outputb;

 sprintf(file_name,"%sF%d_%d",output3,count_snaps,my_rank);
 if(( outputa= fopen(file_name,"w")) ==NULL )
 {
   printf("Error 3777201 opening snap file on node %d at time %d\n",my_rank,time1);
   MPI_Finalize();
   exit(0);
 }

 for(i=order; i<Nx+order; i=i+LR)
 {
 for(j=order; j<Ny+order; j=j+LR)
 {
 for(k=order; k<Nz+order; k=k+LR)
 {
 
   aa[0]=uR[i][j][k][2];
   fwrite(&aa, sizeof(float), 1, outputa);

 }
 }
 }

 //fwrite(Fwd, sizeof(float), Nx*Ny*Nz, outputa);
 //fwrite(Rev, sizeof(float), Nx*Ny*Nz, outputb);

 fclose(outputa);

}


////////////////////////////////////////////////////////////////////////////////////////////////////
/*
void image_make()
{
 int i,j,k,n;
 float aa[1],bb[1],cc[1];
 char file_name[50];
 FILE *output,*input[my_size];
 FILE *inputa,*inputb;

// merging all forward node files into one
 for(n=0; n<no_snap; n++)
 {
    sprintf(file_name,"%sF%d",output3,n);
    if(( output = fopen(file_name,"w")) ==NULL )
    {
       printf("Error 475643390671 opening snap file on node %d at time %d\n",my_rank,time1);
       MPI_Finalize();
       exit(0);
    }
    for(j=0; j<my_size; j++)
    {
        sprintf(file_name,"%sF%d_%d",output3,n,j);
	if(( input[j] = fopen(file_name,"r")) ==NULL )
        {
          printf("Error 7777388561 merging file %s on node %d\n",file_name,j);
          MPI_Finalize();
          exit(1);
        }

      for(i=0;i<lr_count; i++)
      {
        fread(&aa, sizeof(float), 1, input[j]);
	bb[0]=aa[0]; 
        fwrite(&bb, sizeof(float), 1, output);
      }
      // fread(Fwd, sizeof(float), Nx*Ny*Nz, input[j]);
      //fwrite(Fwd, sizeof(float), Nx*Ny*Nz, output);

      fclose(input[j]);
    }

    for(i=0; i<my_size; i++)
    {
      sprintf(file_name,"%sF%d_%d",output3,n,i);
      remove(file_name);
    }
    fclose(output);
 }

// merging all reverse node files into one
 for(n=0; n<no_snap; n++)
 {
    sprintf(file_name,"%sR%d",output3,n);
    if(( output = fopen(file_name,"w")) ==NULL )
    {
       printf("Error 475643390672 opening snap file on node %d at time %d\n",my_rank,time1);
       MPI_Finalize();
       exit(1);
    }
    for(j=0; j<my_size; j++)
    {
        sprintf(file_name,"%sR%d_%d",output3,n,j);
	if(( input[j] = fopen(file_name,"r")) == NULL )
        {
          printf("Error 7777388562 merging file %s on node %d\n",file_name,j);
          MPI_Finalize();
          exit(1);
        }

      for(i=0;i<lr_count; i++)
      {
        fread(&aa, sizeof(float), 1, input[j]);
	bb[0]=aa[0]; 
        fwrite(&bb, sizeof(float), 1, output);
      }
       //fread(Rev, sizeof(float), Nx*Ny*Nz, input[j]);
      //fwrite(Rev, sizeof(float), Nx*Ny*Nz, output);
      fclose(input[j]);
    }

    for(i=0; i<my_size; i++)
    {
      sprintf(file_name,"%sR%d_%d",output3,n,i);
      remove(file_name);
    }
    fclose(output);
 }


// combine reverse and forward files into one image file
 for(n=0; n<no_snap; n++)
 {
    sprintf(file_name,"%sF%d",output3,n);
    if(( inputa = fopen(file_name,"r")) ==NULL )
    {
       printf("Error 47339067 opening snap file %d on node %d at time %d\n",n,my_rank,time1);
       MPI_Finalize();
       exit(1);
    }
    sprintf(file_name,"%sR%d",output3,no_snap-1-n);
    if(( inputb = fopen(file_name,"r")) ==NULL )
    {
       printf("Error 477129067 opening snap file %d on node %d at time %d\n",n,my_rank,time1);
       MPI_Finalize();
       exit(1);
    }
    sprintf(file_name,"%s%d",output3,n);
    if(( output = fopen(file_name,"w")) ==NULL )
    {
       printf("Error 4759069997 opening snap file %s%d on node %d at time %d\n",output3,n,my_rank,time1);
       MPI_Finalize();
       exit(1);
    }

    //printf("88888888888888 --- %d %d %d\n",no_snap,n,no_snap-1-n);

    for(i=0;i<lr_count*my_size; i++)
    {
        fread(&aa, sizeof(float), 1, inputa);
        fread(&bb, sizeof(float), 1, inputb);
	cc[0]=aa[0]*bb[0]; 
        fwrite(&cc, sizeof(float), 1, output);
    }
    fclose(output);
    fclose(inputa);
    fclose(inputb);
 }

 FILE *input_all[no_snap];
 sprintf(file_name,"%s_final%d",output3,shot_no);
 if(( output = fopen(file_name,"w")) ==NULL )
 {
       printf("Error 0697 opening snap file %s_final%d on node %d at time %d\n",output3,shot_no,my_rank,time1);
       MPI_Finalize();
       exit(1);
 }
 for(n=0; n<no_snap; n++)
 {
    sprintf(file_name,"%s%d",output3,n);
    if(( input_all[n] = fopen(file_name,"r")) ==NULL )
    {
       printf("Error 473067 opening snap file %s%d on node %d at time %d\n",output3,n,my_rank,time1);
       //MPI_Finalize();
       //exit(1);
    }
 }

 printf("Merging %d files of size %d floats\n",no_snap,lr_count*my_size);
 for(i=0; i<lr_count*my_size; i++)
 {
   cc[0]=0.0;
   for(n=0; n<no_snap; n++)
   {
    fread(&aa, sizeof(float), 1, input_all[n]);
    cc[0] = aa[0] + cc[0];
   }
   fwrite(&cc, sizeof(float), 1, output);
 }
 fclose(output);

 for(n=0; n<no_snap; n++)
 {
  //  sprintf(file_name,"%sF%d",output3,n);      remove(file_name);
  //  sprintf(file_name,"%sR%d",output3,n);      remove(file_name);
  //  sprintf(file_name,"%s%d",output3,n);       remove(file_name);
 }

}
////////////////////////////////////////////////////////////////////////////////////////////////////
*/

