// main routine for diff stress and velocity

// Diff stress for vel update for TTI
void update_velocityR()
{
 int i,j,k;
 double updateX,updateY,updateZ;
 double c11,c22,c33,c44,mul;
 double dxdz=(dx/dz);

// FD coefficients
 c11=(c1/dx);
 c22=(c2/dx);
 c33=(c3/dx);
 c44=(c4/dx);

 for(i=order; i<Nx+order; i++)
 {
   iup4=i+4; iup3=i+3; iup2=i+2; iup1=i+1;  ido1=i-1;  ido2=i-2;  ido3=i-3;  ido4=i-4;
 for(j=order; j<Ny+order; j++)
 {
   jup4=j+4; jup3=j+3; jup2=j+2; jup1=j+1;  jdo1=j-1;  jdo2=j-2;  jdo3=j-3;  jdo4=j-4;
 for(k=order; k<Nz+order; k++)
 {
   kup4=k+4; kup3=k+3; kup2=k+2; kup1=k+1;  kdo1=k-1;  kdo2=k-2;  kdo3=k-3;  kdo4=k-4;

   mul=dzz[k-order]*(dt/dens[i-order][j-order][k-order]);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Reverse calculations
////////////////////////////////////// TTI
// 8th order RSG of horizontal and vertical stress
// can replace with pointer arithmetic to speed up?

    dsxxdx=c11*( stressR[iup1][j][k][0]+stressR[iup1][jup1][k][0]+stressR[iup1][j][kup1][0]+stressR[iup1][jup1][kup1][0]
                -stressR[i][j][k][0]-stressR[i][jup1][k][0]-stressR[i][j][kup1][0]-stressR[i][jup1][kup1][0] )
          +c22*( stressR[iup2][jdo1][kdo1][0]+stressR[iup2][jup2][kdo1][0]+stressR[iup2][jdo1][kup2][0]+stressR[iup2][jup2][kup2][0]
                -stressR[ido1][jdo1][kdo1][0]-stressR[ido1][jup2][kdo1][0]-stressR[ido1][jdo1][kup2][0]-stressR[ido1][jup2][kup2][0] )
          +c33*( stressR[iup3][jdo2][kdo2][0]+stressR[iup3][jup3][kdo2][0]+stressR[iup3][jdo2][kup3][0]+stressR[iup3][jup3][kup3][0]
                -stressR[ido2][jdo2][kdo2][0]-stressR[ido2][jup3][kdo2][0]-stressR[ido2][jdo2][kup3][0]-stressR[ido2][jup3][kup3][0] )
          +c44*( stressR[iup4][jdo3][kdo3][0]+stressR[iup4][jup4][kdo3][0]+stressR[iup4][jdo3][kup4][0]+stressR[iup4][jup4][kup4][0]
                -stressR[ido3][jdo3][kdo3][0]-stressR[ido3][jup4][kdo3][0]-stressR[ido3][jdo3][kup4][0]-stressR[ido3][jup4][kup4][0] );

    dsxxdy=c11*( -stressR[iup1][j][k][0]+stressR[iup1][jup1][k][0]-stressR[iup1][j][kup1][0]+stressR[iup1][jup1][kup1][0]
                -stressR[i][j][k][0]+stressR[i][jup1][k][0]-stressR[i][j][kup1][0]+stressR[i][jup1][kup1][0] )
          +c22*( -stressR[iup2][jdo1][kdo1][0]+stressR[iup2][jup2][kdo1][0]-stressR[iup2][jdo1][kup2][0]+stressR[iup2][jup2][kup2][0]
                -stressR[ido1][jdo1][kdo1][0]+stressR[ido1][jup2][kdo1][0]-stressR[ido1][jdo1][kup2][0]+stressR[ido1][jup2][kup2][0] )
          +c33*( -stressR[iup3][jdo2][kdo2][0]+stressR[iup3][jup3][kdo2][0]-stressR[iup3][jdo2][kup3][0]+stressR[iup3][jup3][kup3][0]
                -stressR[ido2][jdo2][kdo2][0]+stressR[ido2][jup3][kdo2][0]-stressR[ido2][jdo2][kup3][0]+stressR[ido2][jup3][kup3][0] )
          +c44*( -stressR[iup4][jdo3][kdo3][0]+stressR[iup4][jup4][kdo3][0]-stressR[iup4][jdo3][kup4][0]+stressR[iup4][jup4][kup4][0]
                -stressR[ido3][jdo3][kdo3][0]+stressR[ido3][jup4][kdo3][0]-stressR[ido3][jdo3][kup4][0]+stressR[ido3][jup4][kup4][0] );

    dsxxdz=(dxdz)*(c11*( -stressR[iup1][j][k][0]-stressR[iup1][jup1][k][0]+stressR[iup1][j][kup1][0]+stressR[iup1][jup1][kup1][0]
                -stressR[i][j][k][0]-stressR[i][jup1][k][0]+stressR[i][j][kup1][0]+stressR[i][jup1][kup1][0] )
          +c22*(-stressR[iup2][jdo1][kdo1][0]-stressR[iup2][jup2][kdo1][0]+stressR[iup2][jdo1][kup2][0]+stressR[iup2][jup2][kup2][0]
                -stressR[ido1][jdo1][kdo1][0]-stressR[ido1][jup2][kdo1][0]+stressR[ido1][jdo1][kup2][0]+stressR[ido1][jup2][kup2][0] )
          +c33*(-stressR[iup3][jdo2][kdo2][0]-stressR[iup3][jup3][kdo2][0]+stressR[iup3][jdo2][kup3][0]+stressR[iup3][jup3][kup3][0]
                -stressR[ido2][jdo2][kdo2][0]-stressR[ido2][jup3][kdo2][0]+stressR[ido2][jdo2][kup3][0]+stressR[ido2][jup3][kup3][0] )
          +c44*(-stressR[iup4][jdo3][kdo3][0]-stressR[iup4][jup4][kdo3][0]+stressR[iup4][jdo3][kup4][0]+stressR[iup4][jup4][kup4][0]
                -stressR[ido3][jdo3][kdo3][0]-stressR[ido3][jup4][kdo3][0]+stressR[ido3][jdo3][kup4][0]+stressR[ido3][jup4][kup4][0] ) );

    dszzdx=c11*( stressR[iup1][j][k][1]+stressR[iup1][jup1][k][1]+stressR[iup1][j][kup1][1]+stressR[iup1][jup1][kup1][1]
                -stressR[i][j][k][1]-stressR[i][jup1][k][1]-stressR[i][j][kup1][1]-stressR[i][jup1][kup1][1] )
          +c22*( stressR[iup2][jdo1][kdo1][1]+stressR[iup2][jup2][kdo1][1]+stressR[iup2][jdo1][kup2][1]+stressR[iup2][jup2][kup2][1]
                -stressR[ido1][jdo1][kdo1][1]-stressR[ido1][jup2][kdo1][1]-stressR[ido1][jdo1][kup2][1]-stressR[ido1][jup2][kup2][1] )
          +c33*( stressR[iup3][jdo2][kdo2][1]+stressR[iup3][jup3][kdo2][1]+stressR[iup3][jdo2][kup3][1]+stressR[iup3][jup3][kup3][1]
                -stressR[ido2][jdo2][kdo2][1]-stressR[ido2][jup3][kdo2][1]-stressR[ido2][jdo2][kup3][1]-stressR[ido2][jup3][kup3][1] )
          +c44*( stressR[iup4][jdo3][kdo3][1]+stressR[iup4][jup4][kdo3][1]+stressR[iup4][jdo3][kup4][1]+stressR[iup4][jup4][kup4][1]
                -stressR[ido3][jdo3][kdo3][1]-stressR[ido3][jup4][kdo3][1]-stressR[ido3][jdo3][kup4][1]-stressR[ido3][jup4][kup4][1] );

    dszzdy=c11*( -stressR[iup1][j][k][1]+stressR[iup1][jup1][k][1]-stressR[iup1][j][kup1][1]+stressR[iup1][jup1][kup1][1]
                -stressR[i][j][k][1]+stressR[i][jup1][k][1]-stressR[i][j][kup1][1]+stressR[i][jup1][kup1][1] )
          +c22*( -stressR[iup2][jdo1][kdo1][1]+stressR[iup2][jup2][kdo1][1]-stressR[iup2][jdo1][kup2][1]+stressR[iup2][jup2][kup2][1]
                -stressR[ido1][jdo1][kdo1][1]+stressR[ido1][jup2][kdo1][1]-stressR[ido1][jdo1][kup2][1]+stressR[ido1][jup2][kup2][1] )
          +c33*( -stressR[iup3][jdo2][kdo2][1]+stressR[iup3][jup3][kdo2][1]-stressR[iup3][jdo2][kup3][1]+stressR[iup3][jup3][kup3][1]
                -stressR[ido2][jdo2][kdo2][1]+stressR[ido2][jup3][kdo2][1]-stressR[ido2][jdo2][kup3][1]+stressR[ido2][jup3][kup3][1] )
         +c44*( -stressR[iup4][jdo3][kdo3][1]+stressR[iup4][jup4][kdo3][1]-stressR[iup4][jdo3][kup4][1]+stressR[iup4][jup4][kup4][1]
                -stressR[ido3][jdo3][kdo3][1]+stressR[ido3][jup4][kdo3][1]-stressR[ido3][jdo3][kup4][1]+stressR[ido3][jup4][kup4][1] );

    dszzdz=(dxdz)*(c11*( -stressR[iup1][j][k][1]-stressR[iup1][jup1][k][1]+stressR[iup1][j][kup1][1]+stressR[iup1][jup1][kup1][1]
                -stressR[i][j][k][1]-stressR[i][jup1][k][1]+stressR[i][j][kup1][1]+stressR[i][jup1][kup1][1] )
          +c22*(-stressR[iup2][jdo1][kdo1][1]-stressR[iup2][jup2][kdo1][1]+stressR[iup2][jdo1][kup2][1]+stressR[iup2][jup2][kup2][1]
                -stressR[ido1][jdo1][kdo1][1]-stressR[ido1][jup2][kdo1][1]+stressR[ido1][jdo1][kup2][1]+stressR[ido1][jup2][kup2][1] )
          +c33*(-stressR[iup3][jdo2][kdo2][1]-stressR[iup3][jup3][kdo2][1]+stressR[iup3][jdo2][kup3][1]+stressR[iup3][jup3][kup3][1]
                -stressR[ido2][jdo2][kdo2][1]-stressR[ido2][jup3][kdo2][1]+stressR[ido2][jdo2][kup3][1]+stressR[ido2][jup3][kup3][1] )
          +c44*(-stressR[iup4][jdo3][kdo3][1]-stressR[iup4][jup4][kdo3][1]+stressR[iup4][jdo3][kup4][1]+stressR[iup4][jup4][kup4][1]
                -stressR[ido3][jdo3][kdo3][1]-stressR[ido3][jup4][kdo3][1]+stressR[ido3][jdo3][kup4][1]+stressR[ido3][jup4][kup4][1] ) );

// Equations 13a in Duvenck et al
   updateX =  (R[i][j][k][0]*R[i][j][k][0]+R[i][j][k][1]*R[i][j][k][1])*dsxxdx
            + (dr00dx[i-order][j-order][k-order]+dr11dx[i-order][j-order][k-order])*stressR[i][j][k][0]
            + (R[i][j][k][2]*R[i][j][k][2])*dszzdx
            + dr22dx[i-order][j-order][k-order]*stressR[i][j][k][1] ;

   updateY = (R[i][j][k][0]*R[i][j][k][3]+R[i][j][k][1]*R[i][j][k][4])*dsxxdy
            + (dr03dy[i-order][j-order][k-order]+dr14dy[i-order][j-order][k-order])*stressR[i][j][k][0]
           + (R[i][j][k][2]*R[i][j][k][5])*dszzdy
            + dr25dy[i-order][j-order][k-order]*stressR[i][j][k][1] ;

   updateZ = (R[i][j][k][0]*R[i][j][k][6]+R[i][j][k][1]*R[i][j][k][7])*dsxxdz
            + (dr06dz[i-order][j-order][k-order]+dr17dz[i-order][j-order][k-order])*stressR[i][j][k][0]
            +(R[i][j][k][2]*R[i][j][k][8])*dszzdz
            + dr28dz[i-order][j-order][k-order]*stressR[i][j][k][1] ;

   uR[i][j][k][0] = uR[i][j][k][0] + mul*(updateX+updateY+updateZ);

// Equations 13a in Duvenck et al
   updateX = (R[i][j][k][3]*R[i][j][k][0]+R[i][j][k][4]*R[i][j][k][1])*dsxxdx
           + (dr03dx[i-order][j-order][k-order]+dr14dx[i-order][j-order][k-order])*stressR[i][j][k][0]
           + (R[i][j][k][5]*R[i][j][k][2])*dszzdx
           + dr25dx[i-order][j-order][k-order]*stressR[i][j][k][1] ;

   updateY = (R[i][j][k][3]*R[i][j][k][3]+R[i][j][k][4]*R[i][j][k][4])*dsxxdy
           + (dr33dy[i-order][j-order][k-order]+dr44dy[i-order][j-order][k-order])*stressR[i][j][k][0]
           + (R[i][j][k][5]*R[i][j][k][5])*dszzdy
           + dr55dy[i-order][j-order][k-order]*stressR[i][j][k][1] ;

   updateZ = (R[i][j][k][3]*R[i][j][k][6]+R[i][j][k][4]*R[i][j][k][7])*dsxxdz 
           + (dr36dz[i-order][j-order][k-order]+dr47dz[i-order][j-order][k-order])*stressR[i][j][k][0]
           + (R[i][j][k][5]*R[i][j][k][8])*dszzdz
           + dr58dz[i-order][j-order][k-order]*stressR[i][j][k][1] ;

   uR[i][j][k][1] = uR[i][j][k][1] + mul*(updateX+updateY+updateZ);

// Equations 13a in Duvenck et al
   updateX = (R[i][j][k][0]*R[i][j][k][6]+R[i][j][k][7]*R[i][j][k][1])*dsxxdx
           + (dr06dx[i-order][j-order][k-order]+dr17dx[i-order][j-order][k-order])*stressR[i][j][k][0]
           + (R[i][j][k][8]*R[i][j][k][2])*dszzdx
           + dr28dx[i-order][j-order][k-order]*stressR[i][j][k][1] ;

   updateY = (R[i][j][k][6]*R[i][j][k][3]+R[i][j][k][7]*R[i][j][k][4])*dsxxdy 
           + (dr36dy[i-order][j-order][k-order]+dr47dy[i-order][j-order][k-order])*stressR[i][j][k][0]
           + (R[i][j][k][8]*R[i][j][k][5])*dszzdy 
           + dr58dy[i-order][j-order][k-order]*stressR[i][j][k][1] ;

   updateZ = (R[i][j][k][6]*R[i][j][k][6]+R[i][j][k][7]*R[i][j][k][7])*dsxxdz 
           + (dr66dz[i-order][j-order][k-order]+dr77dz[i-order][j-order][k-order])*stressR[i][j][k][0]
           + (R[i][j][k][8]*R[i][j][k][8])*dszzdz 
           + dr88dz[i-order][j-order][k-order]*stressR[i][j][k][1] ;

   uR[i][j][k][2] = uR[i][j][k][2] + mul*(updateX+updateY+updateZ);

////////////////////////////////////// VTI

// 8th order RSG of horizontal and vertical stressR
/*
    dsxxdx=c11*( stressR[iup1][j][k][0]+stressR[iup1][jup1][k][0]+stressR[iup1][j][kup1][0]+stressR[iup1][jup1][kup1][0]
                -stressR[i][j][k][0]-stressR[i][jup1][k][0]-stressR[i][j][kup1][0]-stressR[i][jup1][kup1][0] )
          +c22*( stressR[iup2][jdo1][kdo1][0]+stressR[iup2][jup2][kdo1][0]+stressR[iup2][jdo1][kup2][0]+stressR[iup2][jup2][kup2][0]
                -stressR[ido1][jdo1][kdo1][0]-stressR[ido1][jup2][kdo1][0]-stressR[ido1][jdo1][kup2][0]-stressR[ido1][jup2][kup2][0] )
          +c33*( stressR[iup3][jdo2][kdo2][0]+stressR[iup3][jup3][kdo2][0]+stressR[iup3][jdo2][kup3][0]+stressR[iup3][jup3][kup3][0]
                -stressR[ido2][jdo2][kdo2][0]-stressR[ido2][jup3][kdo2][0]-stressR[ido2][jdo2][kup3][0]-stressR[ido2][jup3][kup3][0] )
          +c44*( stressR[iup4][jdo3][kdo3][0]+stressR[iup4][jup4][kdo3][0]+stressR[iup4][jdo3][kup4][0]+stressR[iup4][jup4][kup4][0]
                -stressR[ido3][jdo3][kdo3][0]-stressR[ido3][jup4][kdo3][0]-stressR[ido3][jdo3][kup4][0]-stressR[ido3][jup4][kup4][0] );

    dsxxdy=c11*( -stressR[iup1][j][k][0]+stressR[iup1][jup1][k][0]-stressR[iup1][j][kup1][0]+stressR[iup1][jup1][kup1][0]
                -stressR[i][j][k][0]+stressR[i][jup1][k][0]-stressR[i][j][kup1][0]+stressR[i][jup1][kup1][0] )
          +c22*( -stressR[iup2][jdo1][kdo1][0]+stressR[iup2][jup2][kdo1][0]-stressR[iup2][jdo1][kup2][0]+stressR[iup2][jup2][kup2][0]
                 -stressR[ido1][jdo1][kdo1][0]+stressR[ido1][jup2][kdo1][0]-stressR[ido1][jdo1][kup2][0]+stressR[ido1][jup2][kup2][0] )
          +c33*( -stressR[iup3][jdo2][kdo2][0]+stressR[iup3][jup3][kdo2][0]-stressR[iup3][jdo2][kup3][0]+stressR[iup3][jup3][kup3][0]
                 -stressR[ido2][jdo2][kdo2][0]+stressR[ido2][jup3][kdo2][0]-stressR[ido2][jdo2][kup3][0]+stressR[ido2][jup3][kup3][0] )
          +c44*( -stressR[iup4][jdo3][kdo3][0]+stressR[iup4][jup4][kdo3][0]-stressR[iup4][jdo3][kup4][0]+stressR[iup4][jup4][kup4][0]
                 -stressR[ido3][jdo3][kdo3][0]+stressR[ido3][jup4][kdo3][0]-stressR[ido3][jdo3][kup4][0]+stressR[ido3][jup4][kup4][0] );

    dszzdz=(dxdz)*(c11*( -stressR[iup1][j][k][1]-stressR[iup1][jup1][k][1]+stressR[iup1][j][kup1][1]+stressR[iup1][jup1][kup1][1]
                 -stressR[i][j][k][1]-stressR[i][jup1][k][1]+stressR[i][j][kup1][1]+stressR[i][jup1][kup1][1] )
          +c22*( -stressR[iup2][jdo1][kdo1][1]-stressR[iup2][jup2][kdo1][1]+stressR[iup2][jdo1][kup2][1]+stressR[iup2][jup2][kup2][1]
                 -stressR[ido1][jdo1][kdo1][1]-stressR[ido1][jup2][kdo1][1]+stressR[ido1][jdo1][kup2][1]+stressR[ido1][jup2][kup2][1] )
          +c33*( -stressR[iup3][jdo2][kdo2][1]-stressR[iup3][jup3][kdo2][1]+stressR[iup3][jdo2][kup3][1]+stressR[iup3][jup3][kup3][1]
                 -stressR[ido2][jdo2][kdo2][1]-stressR[ido2][jup3][kdo2][1]+stressR[ido2][jdo2][kup3][1]+stressR[ido2][jup3][kup3][1] )
          +c44*( -stressR[iup4][jdo3][kdo3][1]-stressR[iup4][jup4][kdo3][1]+stressR[iup4][jdo3][kup4][1]+stressR[iup4][jup4][kup4][1]
                 -stressR[ido3][jdo3][kdo3][1]-stressR[ido3][jup4][kdo3][1]+stressR[ido3][jdo3][kup4][1]+stressR[ido3][jup4][kup4][1] ) );

   uR[i][j][k][0] = uR[i][j][k][0] + mul*(dsxxdx);

   uR[i][j][k][1] = uR[i][j][k][1] + mul*(dsxxdy);

   uR[i][j][k][2] = uR[i][j][k][2] + mul*(dszzdz);
*/
////////////////////////////////////// ACOUSTIC
// 8th order
/*    dsxxdx=c11*( stressR[iup1][j][k][0]+stressR[iup1][jup1][k][0]+stressR[iup1][j][kup1][0]+stressR[iup1][jup1][kup1][0]
                -stressR[i][j][k][0]-stressR[i][jup1][k][0]-stressR[i][j][kup1][0]-stressR[i][jup1][kup1][0] )
          +c22*( stressR[iup2][jdo1][kdo1][0]+stressR[iup2][jup2][kdo1][0]+stressR[iup2][jdo1][kup2][0]+stressR[iup2][jup2][kup2][0]
                -stressR[ido1][jdo1][kdo1][0]-stressR[ido1][jup2][kdo1][0]-stressR[ido1][jdo1][kup2][0]-stressR[ido1][jup2][kup2][0] )
          +c33*( stressR[iup3][jdo2][kdo2][0]+stressR[iup3][jup3][kdo2][0]+stressR[iup3][jdo2][kup3][0]+stressR[iup3][jup3][kup3][0]
                -stressR[ido2][jdo2][kdo2][0]-stressR[ido2][jup3][kdo2][0]-stressR[ido2][jdo2][kup3][0]-stressR[ido2][jup3][kup3][0] )
          +c44*( stressR[iup4][jdo3][kdo3][0]+stressR[iup4][jup4][kdo3][0]+stressR[iup4][jdo3][kup4][0]+stressR[iup4][jup4][kup4][0]
                -stressR[ido3][jdo3][kdo3][0]-stressR[ido3][jup4][kdo3][0]-stressR[ido3][jdo3][kup4][0]-stressR[ido3][jup4][kup4][0] );

    dsxxdy=c11*( -stressR[iup1][j][k][0]+stressR[iup1][jup1][k][0]-stressR[iup1][j][kup1][0]+stressR[iup1][jup1][kup1][0]
                 -stressR[i][j][k][0]+stressR[i][jup1][k][0]-stressR[i][j][kup1][0]+stressR[i][jup1][kup1][0] )
          +c22*( -stressR[iup2][jdo1][kdo1][0]+stressR[iup2][jup2][kdo1][0]-stressR[iup2][jdo1][kup2][0]+stressR[iup2][jup2][kup2][0]
                 -stressR[ido1][jdo1][kdo1][0]+stressR[ido1][jup2][kdo1][0]-stressR[ido1][jdo1][kup2][0]+stressR[ido1][jup2][kup2][0] )
          +c33*( -stressR[iup3][jdo2][kdo2][0]+stressR[iup3][jup3][kdo2][0]-stressR[iup3][jdo2][kup3][0]+stressR[iup3][jup3][kup3][0]
                 -stressR[ido2][jdo2][kdo2][0]+stressR[ido2][jup3][kdo2][0]-stressR[ido2][jdo2][kup3][0]+stressR[ido2][jup3][kup3][0] )
          +c44*( -stressR[iup4][jdo3][kdo3][0]+stressR[iup4][jup4][kdo3][0]-stressR[iup4][jdo3][kup4][0]+stressR[iup4][jup4][kup4][0]
                 -stressR[ido3][jdo3][kdo3][0]+stressR[ido3][jup4][kdo3][0]-stressR[ido3][jdo3][kup4][0]+stressR[ido3][jup4][kup4][0] );

    dsxxdz=(dxdz)*(c11*( -stressR[iup1][j][k][0]-stressR[iup1][jup1][k][0]+stressR[iup1][j][kup1][0]+stressR[iup1][jup1][kup1][0]
                -stressR[i][j][k][0]-stressR[i][jup1][k][0]+stressR[i][j][kup1][0]+stressR[i][jup1][kup1][0] )
          +c22*(-stressR[iup2][jdo1][kdo1][0]-stressR[iup2][jup2][kdo1][0]+stressR[iup2][jdo1][kup2][0]+stressR[iup2][jup2][kup2][0]
                -stressR[ido1][jdo1][kdo1][0]-stressR[ido1][jup2][kdo1][0]+stressR[ido1][jdo1][kup2][0]+stressR[ido1][jup2][kup2][0] )
          +c33*(-stressR[iup3][jdo2][kdo2][0]-stressR[iup3][jup3][kdo2][0]+stressR[iup3][jdo2][kup3][0]+stressR[iup3][jup3][kup3][0]
                -stressR[ido2][jdo2][kdo2][0]-stressR[ido2][jup3][kdo2][0]+stressR[ido2][jdo2][kup3][0]+stressR[ido2][jup3][kup3][0] )
          +c44*(-stressR[iup4][jdo3][kdo3][0]-stressR[iup4][jup4][kdo3][0]+stressR[iup4][jdo3][kup4][0]+stressR[iup4][jup4][kup4][0]
                -stressR[ido3][jdo3][kdo3][0]-stressR[ido3][jup4][kdo3][0]+stressR[ido3][jdo3][kup4][0]+stressR[ido3][jup4][kup4][0] ) );

   uR[i][j][k][0] = uR[i][j][k][0] + mul*(dsxxdx);

   uR[i][j][k][1] = uR[i][j][k][1] + mul*(dsxxdy);

   uR[i][j][k][2] = uR[i][j][k][2] + mul*(dsxxdz);
*/

 }
 }
 }

//printf("%d \t%d %d %d \t%d\n",my_rank,Nxx,Nyy,Nzz,order);

}


/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////
// Diff of the velocities to get the stressF

void update_stressR()
{
 int i,j,k;
 double updateX,updateY,updateZ;
 double c11,c22,c33,c44;
 double E,D,V;
 double dxdz=(dx/dz);

 // FD coefficients
 c11=c1/dx;
 c22=c2/dx;
 c33=c3/dx;
 c44=c4/dx;

 for(i=order; i<Nx+order; i++)
 {
   iup4=i+4; iup3=i+3; iup2=i+2; iup1=i+1;  ido1=i-1;  ido2=i-2;  ido3=i-3;  ido4=i-4;  
 for(j=order; j<Ny+order; j++)
 {
   jup4=j+4; jup3=j+3; jup2=j+2; jup1=j+1;  jdo1=j-1;  jdo2=j-2;  jdo3=j-3;  jdo4=j-4;  
 for(k=order; k<Nz+order; k++)
 {
   kup4=k+4; kup3=k+3; kup2=k+2; kup1=k+1;  kdo1=k-1;  kdo2=k-2;  kdo3=k-3;  kdo4=k-4;  

//////////////////////////////////////////////////////////////////////////////////////////////////////////
// REVERSE CALCULATIONS

////////////////////////////////////// TTI
// 8th order FD of velocities
// can replace with pointer arithmetic to speed up?
    dudx=  c11*( uR[i][jdo1][kdo1][0]+uR[i][j][kdo1][0]+uR[i][jdo1][k][0]+uR[i][j][k][0]
                -uR[ido1][jdo1][kdo1][0]-uR[ido1][j][kdo1][0]-uR[ido1][jdo1][k][0]-uR[ido1][j][k][0] )
          +c22*( uR[iup1][jdo2][kdo2][0]+uR[iup1][jup1][kdo2][0]+uR[iup1][jdo2][kup1][0]+uR[iup1][jup1][kup1][0]
                -uR[ido2][jdo2][kdo2][0]-uR[ido2][jup1][kdo2][0]-uR[ido2][jdo2][kup1][0]-uR[ido2][jup1][kup1][0] )
          +c33*( uR[iup2][jdo3][kdo3][0]+uR[iup2][jup2][kdo3][0]+uR[iup2][jdo3][kup2][0]+uR[iup2][jup2][kup2][0]
                -uR[ido3][jdo3][kdo3][0]-uR[ido3][jup2][kdo3][0]-uR[ido3][jdo3][kup2][0]-uR[ido3][jup2][kup2][0] )
          +c44*( uR[iup3][jdo4][kdo4][0]+uR[iup3][jup3][kdo4][0]+uR[iup3][jdo4][kup3][0]+uR[iup3][jup3][kup3][0]
                -uR[ido4][jdo4][kdo4][0]-uR[ido4][jup3][kdo4][0]-uR[ido4][jdo4][kup3][0]-uR[ido4][jup3][kup3][0] );

    dudy=  c11*( -uR[i][jdo1][kdo1][0]+uR[i][j][kdo1][0]-uR[i][jdo1][k][0]+uR[i][j][k][0]
                -uR[ido1][jdo1][kdo1][0]+uR[ido1][j][kdo1][0]-uR[ido1][jdo1][k][0]+uR[ido1][j][k][0] )
          +c22*( -uR[iup1][jdo2][kdo2][0]+uR[iup1][jup1][kdo2][0]-uR[iup1][jdo2][kup1][0]+uR[iup1][jup1][kup1][0]
                -uR[ido2][jdo2][kdo2][0]+uR[ido2][jup1][kdo2][0]-uR[ido2][jdo2][kup1][0]+uR[ido2][jup1][kup1][0] )
          +c33*( -uR[iup2][jdo3][kdo3][0]+uR[iup2][jup2][kdo3][0]-uR[iup2][jdo3][kup2][0]+uR[iup2][jup2][kup2][0]
                -uR[ido3][jdo3][kdo3][0]+uR[ido3][jup2][kdo3][0]-uR[ido3][jdo3][kup2][0]+uR[ido3][jup2][kup2][0] )
          +c44*( -uR[iup3][jdo4][kdo4][0]+uR[iup3][jup3][kdo4][0]-uR[iup3][jdo4][kup3][0]+uR[iup3][jup3][kup3][0]
                -uR[ido4][jdo4][kdo4][0]+uR[ido4][jup3][kdo4][0]-uR[ido4][jdo4][kup3][0]+uR[ido4][jup3][kup3][0] );

    dudz=(dxdz)*(c11*( -uR[i][jdo1][kdo1][0]-uR[i][j][kdo1][0]+uR[i][jdo1][k][0]+uR[i][j][k][0]
                -uR[ido1][jdo1][kdo1][0]-uR[ido1][j][kdo1][0]+uR[ido1][jdo1][k][0]+uR[ido1][j][k][0] )
          +c22*( -uR[iup1][jdo2][kdo2][0]-uR[iup1][jup1][kdo2][0]+uR[iup1][jdo2][kup1][0]+uR[iup1][jup1][kup1][0]
                -uR[ido2][jdo2][kdo2][0]-uR[ido2][jup1][kdo2][0]+uR[ido2][jdo2][kup1][0]+uR[ido2][jup1][kup1][0] )
          +c33*( -uR[iup2][jdo3][kdo3][0]-uR[iup2][jup2][kdo3][0]+uR[iup2][jdo3][kup2][0]+uR[iup2][jup2][kup2][0]
                -uR[ido3][jdo3][kdo3][0]-uR[ido3][jup2][kdo3][0]+uR[ido3][jdo3][kup2][0]+uR[ido3][jup2][kup2][0] )
          +c44*( -uR[iup3][jdo4][kdo4][0]-uR[iup3][jup3][kdo4][0]+uR[iup3][jdo4][kup3][0]+uR[iup3][jup3][kup3][0]
                -uR[ido4][jdo4][kdo4][0]-uR[ido4][jup3][kdo4][0]+uR[ido4][jdo4][kup3][0]+uR[ido4][jup3][kup3][0] ) );

    dvdx=c11*( uR[i][jdo1][kdo1][1]+uR[i][j][kdo1][1]+uR[i][jdo1][k][1]+uR[i][j][k][1]
                -uR[ido1][jdo1][kdo1][1]-uR[ido1][j][kdo1][1]-uR[ido1][jdo1][k][1]-uR[ido1][j][k][1] )
          +c22*( uR[iup1][jdo2][kdo2][1]+uR[iup1][jup1][kdo2][1]+uR[iup1][jdo2][kup1][1]+uR[iup1][jup1][kup1][1]
                -uR[ido2][jdo2][kdo2][1]-uR[ido2][jup1][kdo2][1]-uR[ido2][jdo2][kup1][1]-uR[ido2][jup1][kup1][1] )
          +c33*( uR[iup2][jdo3][kdo3][1]+uR[iup2][jup2][kdo3][1]+uR[iup2][jdo3][kup2][1]+uR[iup2][jup2][kup2][1]
                -uR[ido3][jdo3][kdo3][1]-uR[ido3][jup2][kdo3][1]-uR[ido3][jdo3][kup2][1]-uR[ido3][jup2][kup2][1] )
          +c44*( uR[iup3][jdo4][kdo4][1]+uR[iup3][jup3][kdo4][1]+uR[iup3][jdo4][kup3][1]+uR[iup3][jup3][kup3][1]
                -uR[ido4][jdo4][kdo4][1]-uR[ido4][jup3][kdo4][1]-uR[ido4][jdo4][kup3][1]-uR[ido4][jup3][kup3][1] );

    dvdy=c11*(     -uR[i][jdo1][kdo1][1]+uR[i][j][kdo1][1]-uR[i][jdo1][k][1]+uR[i][j][k][1]
                 -uR[ido1][jdo1][kdo1][1]+uR[ido1][j][kdo1][1]-uR[ido1][jdo1][k][1]+uR[ido1][j][k][1] )
          +c22*( -uR[iup1][jdo2][kdo2][1]+uR[iup1][jup1][kdo2][1]-uR[iup1][jdo2][kup1][1]+uR[iup1][jup1][kup1][1]
                 -uR[ido2][jdo2][kdo2][1]+uR[ido2][jup1][kdo2][1]-uR[ido2][jdo2][kup1][1]+uR[ido2][jup1][kup1][1] )
          +c33*( -uR[iup2][jdo3][kdo3][1]+uR[iup2][jup2][kdo3][1]-uR[iup2][jdo3][kup2][1]+uR[iup2][jup2][kup2][1]
                 -uR[ido3][jdo3][kdo3][1]+uR[ido3][jup2][kdo3][1]-uR[ido3][jdo3][kup2][1]+uR[ido3][jup2][kup2][1] )
          +c44*( -uR[iup3][jdo4][kdo4][1]+uR[iup3][jup3][kdo4][1]-uR[iup3][jdo4][kup3][1]+uR[iup3][jup3][kup3][1]
                 -uR[ido4][jdo4][kdo4][1]+uR[ido4][jup3][kdo4][1]-uR[ido4][jdo4][kup3][1]+uR[ido4][jup3][kup3][1] );

    dvdz=(dxdz)*(c11*( -uR[i][jdo1][kdo1][1]-uR[i][j][kdo1][1]+uR[i][jdo1][k][1]+uR[i][j][k][1]
                 -uR[ido1][jdo1][kdo1][1]-uR[ido1][j][kdo1][1]+uR[ido1][jdo1][k][1]+uR[ido1][j][k][1] )
          +c22*( -uR[iup1][jdo2][kdo2][1]-uR[iup1][jup1][kdo2][1]+uR[iup1][jdo2][kup1][1]+uR[iup1][jup1][kup1][1]
                 -uR[ido2][jdo2][kdo2][1]-uR[ido2][jup1][kdo2][1]+uR[ido2][jdo2][kup1][1]+uR[ido2][jup1][kup1][1] )
          +c33*( -uR[iup2][jdo3][kdo3][1]-uR[iup2][jup2][kdo3][1]+uR[iup2][jdo3][kup2][1]+uR[iup2][jup2][kup2][1]
                 -uR[ido3][jdo3][kdo3][1]-uR[ido3][jup2][kdo3][1]+uR[ido3][jdo3][kup2][1]+uR[ido3][jup2][kup2][1] )
         +c44*(  -uR[iup3][jdo4][kdo4][1]-uR[iup3][jup3][kdo4][1]+uR[iup3][jdo4][kup3][1]+uR[iup3][jup3][kup3][1]
                 -uR[ido4][jdo4][kdo4][1]-uR[ido4][jup3][kdo4][1]+uR[ido4][jdo4][kup3][1]+uR[ido4][jup3][kup3][1] ) );

    dwdx=c11*( uR[i][jdo1][kdo1][2]+uR[i][j][kdo1][2]+uR[i][jdo1][k][2]+uR[i][j][k][2]
                -uR[ido1][jdo1][kdo1][2]-uR[ido1][j][kdo1][2]-uR[ido1][jdo1][k][2]-uR[ido1][j][k][2] )
          +c22*( uR[iup1][jdo2][kdo2][2]+uR[iup1][jup1][kdo2][2]+uR[iup1][jdo2][kup1][2]+uR[iup1][jup1][kup1][2]
                -uR[ido2][jdo2][kdo2][2]-uR[ido2][jup1][kdo2][2]-uR[ido2][jdo2][kup1][2]-uR[ido2][jup1][kup1][2] )
          +c33*( uR[iup2][jdo3][kdo3][2]+uR[iup2][jup2][kdo3][2]+uR[iup2][jdo3][kup2][2]+uR[iup2][jup2][kup2][2]
                -uR[ido3][jdo3][kdo3][2]-uR[ido3][jup2][kdo3][2]-uR[ido3][jdo3][kup2][2]-uR[ido3][jup2][kup2][2] )
          +c44*( uR[iup3][jdo4][kdo4][2]+uR[iup3][jup3][kdo4][2]+uR[iup3][jdo4][kup3][2]+uR[iup3][jup3][kup3][2]
                -uR[ido4][jdo4][kdo4][2]-uR[ido4][jup3][kdo4][2]-uR[ido4][jdo4][kup3][2]-uR[ido4][jup3][kup3][2] );

    dwdy=c11*( -uR[i][jdo1][kdo1][2]+uR[i][j][kdo1][2]-uR[i][jdo1][k][2]+uR[i][j][k][2]
                -uR[ido1][jdo1][kdo1][2]+uR[ido1][j][kdo1][2]-uR[ido1][jdo1][k][2]+uR[ido1][j][k][2] )
          +c22*( -uR[iup1][jdo2][kdo2][2]+uR[iup1][jup1][kdo2][2]-uR[iup1][jdo2][kup1][2]+uR[iup1][jup1][kup1][2]
                 -uR[ido2][jdo2][kdo2][2]+uR[ido2][jup1][kdo2][2]-uR[ido2][jdo2][kup1][2]+uR[ido2][jup1][kup1][2] )
          +c33*( -uR[iup2][jdo3][kdo3][2]+uR[iup2][jup2][kdo3][2]-uR[iup2][jdo3][kup2][2]+uR[iup2][jup2][kup2][2]
                 -uR[ido3][jdo3][kdo3][2]+uR[ido3][jup2][kdo3][2]-uR[ido3][jdo3][kup2][2]+uR[ido3][jup2][kup2][2] )
          +c44*( -uR[iup3][jdo4][kdo4][2]+uR[iup3][jup3][kdo4][2]-uR[iup3][jdo4][kup3][2]+uR[iup3][jup3][kup3][2]
                 -uR[ido4][jdo4][kdo4][2]+uR[ido4][jup3][kdo4][2]-uR[ido4][jdo4][kup3][2]+uR[ido4][jup3][kup3][2] );

    dwdz=(dxdz)*(c11*( -uR[i][jdo1][kdo1][2]-uR[i][j][kdo1][2]+uR[i][jdo1][k][2]+uR[i][j][k][2]
                 -uR[ido1][jdo1][kdo1][2]-uR[ido1][j][kdo1][2]+uR[ido1][jdo1][k][2]+uR[ido1][j][k][2] )
          +c22*( -uR[iup1][jdo2][kdo2][2]-uR[iup1][jup1][kdo2][2]+uR[iup1][jdo2][kup1][2]+uR[iup1][jup1][kup1][2]
                 -uR[ido2][jdo2][kdo2][2]-uR[ido2][jup1][kdo2][2]+uR[ido2][jdo2][kup1][2]+uR[ido2][jup1][kup1][2] )
          +c33*( -uR[iup2][jdo3][kdo3][2]-uR[iup2][jup2][kdo3][2]+uR[iup2][jdo3][kup2][2]+uR[iup2][jup2][kup2][2]
                 -uR[ido3][jdo3][kdo3][2]-uR[ido3][jup2][kdo3][2]+uR[ido3][jdo3][kup2][2]+uR[ido3][jup2][kup2][2] )
         +c44*(  -uR[iup3][jdo4][kdo4][2]-uR[iup3][jup3][kdo4][2]+uR[iup3][jdo4][kup3][2]+uR[iup3][jup3][kup3][2]
                 -uR[ido4][jdo4][kdo4][2]-uR[ido4][jup3][kdo4][2]+uR[ido4][jdo4][kup3][2]+uR[ido4][jup3][kup3][2] ) );

// Equations 13a in Duvenck et al
    D=sqrt(1.0+2.0*delta[i-order][j-order][k-order]);
    E=(1.0+2.0*eps[i-order][j-order][k-order]);
    V=dt*dens[i-order][j-order][k-order]*velp[i-order][j-order][k-order]*velp[i-order][j-order][k-order];

// updating horizontal stress Euler finite-difference
    stressR[i][j][k][0] = stressR[i][j][k][0] 
                 + V*(
                 ( E*R[i][j][k][0]*R[i][j][k][0] + E*R[i][j][k][1]*R[i][j][k][1] + D*R[i][j][k][2]*R[i][j][k][2]  )*dudx +
                 ( E*R[i][j][k][3]*R[i][j][k][0] + E*R[i][j][k][4]*R[i][j][k][1] + D*R[i][j][k][5]*R[i][j][k][2]  )*dvdx +
                 ( E*R[i][j][k][6]*R[i][j][k][0] + E*R[i][j][k][7]*R[i][j][k][1] + D*R[i][j][k][8]*R[i][j][k][2]  )*dwdx +
                 ( E*R[i][j][k][0]*R[i][j][k][3] + E*R[i][j][k][1]*R[i][j][k][4] + D*R[i][j][k][2]*R[i][j][k][5]  )*dudy +
                 ( E*R[i][j][k][3]*R[i][j][k][3] + E*R[i][j][k][4]*R[i][j][k][4] + D*R[i][j][k][5]*R[i][j][k][5]  )*dvdy +
                 ( E*R[i][j][k][6]*R[i][j][k][3] + E*R[i][j][k][7]*R[i][j][k][4] + D*R[i][j][k][8]*R[i][j][k][5]  )*dwdy +
                 ( E*R[i][j][k][0]*R[i][j][k][6] + E*R[i][j][k][1]*R[i][j][k][7] + D*R[i][j][k][2]*R[i][j][k][8]  )*dudz +
                 ( E*R[i][j][k][3]*R[i][j][k][6] + E*R[i][j][k][4]*R[i][j][k][7] + D*R[i][j][k][5]*R[i][j][k][8]  )*dvdz +
                 ( E*R[i][j][k][6]*R[i][j][k][6] + E*R[i][j][k][7]*R[i][j][k][7] + D*R[i][j][k][8]*R[i][j][k][8]  )*dwdz );

// updating vertical stress Euler finite-difference
    stressR[i][j][k][1] = stressR[i][j][k][1] 
                 + V*(
                 ( D*R[i][j][k][0]*R[i][j][k][0] + D*R[i][j][k][1]*R[i][j][k][1] + R[i][j][k][2]*R[i][j][k][2]  )*dudx +
                 ( D*R[i][j][k][3]*R[i][j][k][0] + D*R[i][j][k][4]*R[i][j][k][1] + R[i][j][k][5]*R[i][j][k][2]  )*dvdx +
                 ( D*R[i][j][k][6]*R[i][j][k][0] + D*R[i][j][k][7]*R[i][j][k][1] + R[i][j][k][8]*R[i][j][k][2]  )*dwdx +
                 ( D*R[i][j][k][0]*R[i][j][k][3] + D*R[i][j][k][1]*R[i][j][k][4] + R[i][j][k][2]*R[i][j][k][5]  )*dudy +
                 ( D*R[i][j][k][3]*R[i][j][k][3] + D*R[i][j][k][4]*R[i][j][k][4] + R[i][j][k][5]*R[i][j][k][5]  )*dvdy +
                 ( D*R[i][j][k][6]*R[i][j][k][3] + D*R[i][j][k][7]*R[i][j][k][4] + R[i][j][k][8]*R[i][j][k][5]  )*dwdy +
                 ( D*R[i][j][k][0]*R[i][j][k][6] + D*R[i][j][k][1]*R[i][j][k][7] + R[i][j][k][2]*R[i][j][k][8]  )*dudz +
                 ( D*R[i][j][k][3]*R[i][j][k][6] + D*R[i][j][k][4]*R[i][j][k][7] + R[i][j][k][5]*R[i][j][k][8]  )*dvdz +
                 ( D*R[i][j][k][6]*R[i][j][k][6] + D*R[i][j][k][7]*R[i][j][k][7] + R[i][j][k][8]*R[i][j][k][8]  )*dwdz );

////////////////////////////////////// VTI
// 8th order FD of velocities
/*    dudx=  c11*( uR[i][jdo1][kdo1][0]+uR[i][j][kdo1][0]+uR[i][jdo1][k][0]+uR[i][j][k][0]
                -uR[ido1][jdo1][kdo1][0]-uR[ido1][j][kdo1][0]-uR[ido1][jdo1][k][0]-uR[ido1][j][k][0] )
          +c22*( uR[iup1][jdo2][kdo2][0]+uR[iup1][jup1][kdo2][0]+uR[iup1][jdo2][kup1][0]+uR[iup1][jup1][kup1][0]
                -uR[ido2][jdo2][kdo2][0]-uR[ido2][jup1][kdo2][0]-uR[ido2][jdo2][kup1][0]-uR[ido2][jup1][kup1][0] )
          +c33*( uR[iup2][jdo3][kdo3][0]+uR[iup2][jup2][kdo3][0]+uR[iup2][jdo3][kup2][0]+uR[iup2][jup2][kup2][0]
                -uR[ido3][jdo3][kdo3][0]-uR[ido3][jup2][kdo3][0]-uR[ido3][jdo3][kup2][0]-uR[ido3][jup2][kup2][0] )
          +c44*( uR[iup3][jdo4][kdo4][0]+uR[iup3][jup3][kdo4][0]+uR[iup3][jdo4][kup3][0]+uR[iup3][jup3][kup3][0]
                -uR[ido4][jdo4][kdo4][0]-uR[ido4][jup3][kdo4][0]-uR[ido4][jdo4][kup3][0]-uR[ido4][jup3][kup3][0] );

    dvdy=c11*(     -uR[i][jdo1][kdo1][1]+uR[i][j][kdo1][1]-uR[i][jdo1][k][1]+uR[i][j][k][1]
                 -uR[ido1][jdo1][kdo1][1]+uR[ido1][j][kdo1][1]-uR[ido1][jdo1][k][1]+uR[ido1][j][k][1] )
          +c22*( -uR[iup1][jdo2][kdo2][1]+uR[iup1][jup1][kdo2][1]-uR[iup1][jdo2][kup1][1]+uR[iup1][jup1][kup1][1]
                 -uR[ido2][jdo2][kdo2][1]+uR[ido2][jup1][kdo2][1]-uR[ido2][jdo2][kup1][1]+uR[ido2][jup1][kup1][1] )
          +c33*( -uR[iup2][jdo3][kdo3][1]+uR[iup2][jup2][kdo3][1]-uR[iup2][jdo3][kup2][1]+uR[iup2][jup2][kup2][1]
                 -uR[ido3][jdo3][kdo3][1]+uR[ido3][jup2][kdo3][1]-uR[ido3][jdo3][kup2][1]+uR[ido3][jup2][kup2][1] )
          +c44*( -uR[iup3][jdo4][kdo4][1]+uR[iup3][jup3][kdo4][1]-uR[iup3][jdo4][kup3][1]+uR[iup3][jup3][kup3][1]
                 -uR[ido4][jdo4][kdo4][1]+uR[ido4][jup3][kdo4][1]-uR[ido4][jdo4][kup3][1]+uR[ido4][jup3][kup3][1] );

    dwdz=(dxdz)*(c11*( -uR[i][jdo1][kdo1][2]-uR[i][j][kdo1][2]+uR[i][jdo1][k][2]+uR[i][j][k][2]
                 -uR[ido1][jdo1][kdo1][2]-uR[ido1][j][kdo1][2]+uR[ido1][jdo1][k][2]+uR[ido1][j][k][2] )
          +c22*( -uR[iup1][jdo2][kdo2][2]-uR[iup1][jup1][kdo2][2]+uR[iup1][jdo2][kup1][2]+uR[iup1][jup1][kup1][2]
                 -uR[ido2][jdo2][kdo2][2]-uR[ido2][jup1][kdo2][2]+uR[ido2][jdo2][kup1][2]+uR[ido2][jup1][kup1][2] )
          +c33*( -uR[iup2][jdo3][kdo3][2]-uR[iup2][jup2][kdo3][2]+uR[iup2][jdo3][kup2][2]+uR[iup2][jup2][kup2][2]
                 -uR[ido3][jdo3][kdo3][2]-uR[ido3][jup2][kdo3][2]+uR[ido3][jdo3][kup2][2]+uR[ido3][jup2][kup2][2] )
         +c44*(  -uR[iup3][jdo4][kdo4][2]-uR[iup3][jup3][kdo4][2]+uR[iup3][jdo4][kup3][2]+uR[iup3][jup3][kup3][2]
                 -uR[ido4][jdo4][kdo4][2]-uR[ido4][jup3][kdo4][2]+uR[ido4][jdo4][kup3][2]+uR[ido4][jup3][kup3][2] ) );

    D=sqrt(1.0+2.0*delta[i-order][j-order][k-order]);
    E=(1.0+2.0*eps[i-order][j-order][k-order]);
    V=dt*dens[i-order][j-order][k-order]*velp[i-order][j-order][k-order]*velp[i-order][j-order][k-order];

// updating horizontal stressF Euler finite-difference
    stressR[i][j][k][0] = stressR[i][j][k][0] + V*( E*dudx + E*dvdy + D*dwdz );

// updating vertical stressF Euler finite-difference
    stressR[i][j][k][1] = stressR[i][j][k][1] + V*( D*dudx + D*dvdy + dwdz );
*/
////////////////////////////////////// ACOUSTIC
// 8th order FD of velocities
/*    dudx=  c11*( uR[i][jdo1][kdo1][0]+uR[i][j][kdo1][0]+uR[i][jdo1][k][0]+uR[i][j][k][0]
                -uR[ido1][jdo1][kdo1][0]-uR[ido1][j][kdo1][0]-uR[ido1][jdo1][k][0]-uR[ido1][j][k][0] )
          +c22*( uR[iup1][jdo2][kdo2][0]+uR[iup1][jup1][kdo2][0]+uR[iup1][jdo2][kup1][0]+uR[iup1][jup1][kup1][0]
                -uR[ido2][jdo2][kdo2][0]-uR[ido2][jup1][kdo2][0]-uR[ido2][jdo2][kup1][0]-uR[ido2][jup1][kup1][0] )
          +c33*( uR[iup2][jdo3][kdo3][0]+uR[iup2][jup2][kdo3][0]+uR[iup2][jdo3][kup2][0]+uR[iup2][jup2][kup2][0]
                -uR[ido3][jdo3][kdo3][0]-uR[ido3][jup2][kdo3][0]-uR[ido3][jdo3][kup2][0]-uR[ido3][jup2][kup2][0] )
          +c44*( uR[iup3][jdo4][kdo4][0]+uR[iup3][jup3][kdo4][0]+uR[iup3][jdo4][kup3][0]+uR[iup3][jup3][kup3][0]
                -uR[ido4][jdo4][kdo4][0]-uR[ido4][jup3][kdo4][0]-uR[ido4][jdo4][kup3][0]-uR[ido4][jup3][kup3][0] );

    dvdy=  c11*(-uR[i][jdo1][kdo1][1]+uR[i][j][kdo1][1]-uR[i][jdo1][k][1]+uR[i][j][k][1]
                -uR[ido1][jdo1][kdo1][1]+uR[ido1][j][kdo1][1]-uR[ido1][jdo1][k][1]+uR[ido1][j][k][1] )
          +c22*(-uR[iup1][jdo2][kdo2][1]+uR[iup1][jup1][kdo2][1]-uR[iup1][jdo2][kup1][1]+uR[iup1][jup1][kup1][1]
                -uR[ido2][jdo2][kdo2][1]+uR[ido2][jup1][kdo2][1]-uR[ido2][jdo2][kup1][1]+uR[ido2][jup1][kup1][1] )
          +c33*(-uR[iup2][jdo3][kdo3][1]+uR[iup2][jup2][kdo3][1]-uR[iup2][jdo3][kup2][1]+uR[iup2][jup2][kup2][1]
                -uR[ido3][jdo3][kdo3][1]+uR[ido3][jup2][kdo3][1]-uR[ido3][jdo3][kup2][1]+uR[ido3][jup2][kup2][1] )
          +c44*(-uR[iup3][jdo4][kdo4][1]+uR[iup3][jup3][kdo4][1]-uR[iup3][jdo4][kup3][1]+uR[iup3][jup3][kup3][1]
                -uR[ido4][jdo4][kdo4][1]+uR[ido4][jup3][kdo4][1]-uR[ido4][jdo4][kup3][1]+uR[ido4][jup3][kup3][1] );

    dwdz=(dxdz)*(c11*( -uR[i][jdo1][kdo1][2]-uR[i][j][kdo1][2]+uR[i][jdo1][k][2]+uR[i][j][k][2]
                 -uR[ido1][jdo1][kdo1][2]-uR[ido1][j][kdo1][2]+uR[ido1][jdo1][k][2]+uR[ido1][j][k][2] )
          +c22*( -uR[iup1][jdo2][kdo2][2]-uR[iup1][jup1][kdo2][2]+uR[iup1][jdo2][kup1][2]+uR[iup1][jup1][kup1][2]
                 -uR[ido2][jdo2][kdo2][2]-uR[ido2][jup1][kdo2][2]+uR[ido2][jdo2][kup1][2]+uR[ido2][jup1][kup1][2] )
          +c33*( -uR[iup2][jdo3][kdo3][2]-uR[iup2][jup2][kdo3][2]+uR[iup2][jdo3][kup2][2]+uR[iup2][jup2][kup2][2]
                 -uR[ido3][jdo3][kdo3][2]-uR[ido3][jup2][kdo3][2]+uR[ido3][jdo3][kup2][2]+uR[ido3][jup2][kup2][2] )
          +c44*( -uR[iup3][jdo4][kdo4][2]-uR[iup3][jup3][kdo4][2]+uR[iup3][jdo4][kup3][2]+uR[iup3][jup3][kup3][2]
                 -uR[ido4][jdo4][kdo4][2]-uR[ido4][jup3][kdo4][2]+uR[ido4][jdo4][kup3][2]+uR[ido4][jup3][kup3][2] ) );

    V=dt*dens[i-order][j-order][k-order]*velp[i-order][j-order][k-order]*velp[i-order][j-order][k-order];

// updating horizontal stress Euler finite-difference
   stressR[i][j][k][0] = stressR[i][j][k][0] + V*(dudx + dvdy + dwdz ) ;

// setting stress equal for acoustic - delete extra array in full model
    stressR[i][j][k][1] = stressR[i][j][k][0];
*/
///////////////////////////////////////////////////////////////////////////////////////////////////////////
     //Rev[i-order][j-order][k-order]=uR[i][j][k][2];
     //Fwd[i-order][j-order][k-order]=uF[i][j][k][2];
  }
  }
  }

  for(i=order; i<Nx+order; i++)
  {
  for(j=order; j<Ny+order; j++)
  {
  for(k=order; k<Nz+order; k++)
  {
    stressR[i][j][k][0] = stressR[i][j][k][0]*dxx[i-order]*dyy[j-order]*dzz[k-order] ;
    stressR[i][j][k][1] = stressR[i][j][k][1]*dxx[i-order]*dyy[j-order]*dzz[k-order] ;

    uR[i][j][k][0] = uR[i][j][k][0]*dxx[i-order]*dyy[j-order]*dzz[k-order];
    uR[i][j][k][1] = uR[i][j][k][1]*dxx[i-order]*dyy[j-order]*dzz[k-order];
    uR[i][j][k][2] = uR[i][j][k][2]*dxx[i-order]*dyy[j-order]*dzz[k-order];
  }
  }
  }

}

/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////
