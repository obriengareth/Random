
void ReadVelFile(char *name)
{
        int i,ii,j,k,n;
	FILE *file;
	double *buffer;
	unsigned long fileLen;
        double leftvel[Ny][Nz],rightvel[Ny][Nz];

//Open file
	file = fopen(name, "rb");
	if (!file)
	{
		fprintf(stderr, "Unable to open file %s", name);
		return;
	}
	
//Get file length
	fseek(file, 0, SEEK_END);
	fileLen=ftell(file);
	fseek(file, 0, SEEK_SET);

//Allocate memory
	buffer=(double *)malloc(fileLen);

	if (!buffer)
	{
		fprintf(stderr, "Memory error!");
                                fclose(file);
		return;
	}

//Read file contents into buffer
	fread(buffer, fileLen, 1, file);
	fclose(file);

// coding check
  /*  if(my_rank==0)
    {
     for(i=fileLen/4-40; i<fileLen/4; i=i+4)
     printf("here %s  %d %lu %lf %lf %lf %lf\n",name,i,fileLen,buffer[i],buffer[i+1],buffer[i+2],buffer[i+3]);
    }*/

  /*  if(my_rank==0)
    {
     for(i=0; i<40; i=i+1)
     printf("---%d %lf\n",i,buffer[i]);
    }*/

// coding check
//printf("%zu,%zu\n", sizeof buffer, sizeof(int));

    //for(n=fileLen/4-80; n<fileLen/4-4; n=n+4)
    for(n=0; n<fileLen/4-4; n=n+4)
    {

      i=(int) ((buffer[n]-OX)/dx)+Width;
      j=(int) ((buffer[n+1]-OY)/dx)+Width;
      k=(int) Nz-Width-((buffer[n+2]-OZ)/dz);

// coding check
//if(my_rank==1)
//printf("%d %d %d \t%d \t%lf %lf %lf %lf\n",i,j,k,locate_node(i),buffer[n],buffer[n+1],buffer[n+2],buffer[n+3]);

      if(i==Width+1)
      {
        if(j>=0 && j<Ny && k>=0 && k<Nz)
        {
        leftvel[j][k]=buffer[n+3];
        }
      }

      if(i==(Nx*my_size-Width-1))
      {


       if(j>=0 && j<Ny && k>=0 && k<Nz)
       {
         rightvel[j][k]=buffer[n+3];
       }
      }

      if( locate_node(i) == my_rank )
      {
        ii=i%Nx;

        if(ii>=0 && ii<Nx && j>=0 && j<Ny && k>=0 && k<Nz)
        {
          velp[ii][j][k]=buffer[n+3];
//printf("%d %d %d %d \t%d %lf\n",i,ii,j,k,my_rank,buffer[n+3]);
        }
      }
    }

   MPI_Barrier(new_comm);

   for(i=0; i<Width; i++)
   {
   for(j=0; j<Ny; j++)
   {
   for(k=0; k<Nz; k++)
   {
     if( locate_node(i) == my_rank )
     {
       ii=i%Nx;
       velp[ii][j][k]=leftvel[j][k];

//if(i==Width-1)
//printf("------------- %d %d %lf %d\n",j,k,leftvel[j][k],my_rank);

     }
   }
   }
   }
   for(i=Nx*my_size-Width; i<Nx*my_size; i++)
   {
   for(j=0; j<Ny; j++)
   {
   for(k=0; k<Nz; k++)
   {
     if( locate_node(i) == my_rank )
     {
       ii=i%Nx;
       velp[ii][j][k]=rightvel[j][k];
     }
   }
   }
   }

   free(buffer);
}

/////////////////////////////////////////////////////////////
void ReadDenFile(char *name)
{
        int i,ii,j,k,n;
	FILE *file;
	double *buffer;
	unsigned long fileLen;
        double leftvel[Ny][Nz],rightvel[Ny][Nz];

//Open file
	file = fopen(name, "rb");
	if (!file)
	{
		fprintf(stderr, "Unable to open file %s", name);
		return;
	}
	
//Get file length
	fseek(file, 0, SEEK_END);
	fileLen=ftell(file);
	fseek(file, 0, SEEK_SET);

//Allocate memory
	buffer=(double *)malloc(fileLen);

	if (!buffer)
	{
		fprintf(stderr, "Memory error!");
                                fclose(file);
		return;
	}

//Read file contents into buffer
	fread(buffer, fileLen, 1, file);
	fclose(file);

    for(n=0; n<fileLen/4-4; n=n+4)
    {

      i=(int) ((buffer[n]-OX)/dx)+Width;
      j=(int) ((buffer[n+1]-OY)/dx)+Width;
      k=(int) Nz-Width-((buffer[n+2]-OZ)/dz);

      if(i==Width+1)
      {
        if(j>=0 && j<Ny && k>=0 && k<Nz)
        {
        leftvel[j][k]=buffer[n+3];
        }
      }

      if(i==(Nx*my_size-Width-1))
      {
       if(j>=0 && j<Ny && k>=0 && k<Nz)
       {
         rightvel[j][k]=buffer[n+3];
       }
      }

      if( locate_node(i) == my_rank )
      {
        ii=i%Nx;

        if(ii>=0 && ii<Nx && j>=0 && j<Ny && k>=0 && k<Nz)
        {
          dens[ii][j][k]=buffer[n+3];
        }
      }
    }

   MPI_Barrier(new_comm);

   for(i=0; i<Width; i++)
   {
   for(j=0; j<Ny; j++)
   {
   for(k=0; k<Nz; k++)
   {
     if( locate_node(i) == my_rank )
     {
       ii=i%Nx;
       dens[ii][j][k]=leftvel[j][k];
     }
   }
   }
   }
   for(i=Nx*my_size-Width; i<Nx*my_size; i++)
   {
   for(j=0; j<Ny; j++)
   {
   for(k=0; k<Nz; k++)
   {
     if( locate_node(i) == my_rank )
     {
       ii=i%Nx;
       dens[ii][j][k]=rightvel[j][k];
     }
   }
   }
   }

   free(buffer);
}

//////////////////////////////////////////////////////////////////////////////////////////////
// Read eps file
void ReadEPSFile(char *name)
{
        int i,ii,j,k,n;
	FILE *file;
	double *buffer;
	unsigned long fileLen;
        double leftvel[Ny][Nz],rightvel[Ny][Nz];

//Open file
	file = fopen(name, "rb");
	if (!file)
	{
		fprintf(stderr, "Unable to open file %s", name);
		return;
	}
	
//Get file length
	fseek(file, 0, SEEK_END);
	fileLen=ftell(file);
	fseek(file, 0, SEEK_SET);

//Allocate memory
	buffer=(double *)malloc(fileLen);

	if (!buffer)
	{
		fprintf(stderr, "Memory error!");
                                fclose(file);
		return;
	}

//Read file contents into buffer
	fread(buffer, fileLen, 1, file);
	fclose(file);

    for(n=0; n<fileLen/4-4; n=n+4)
    {

      i=(int) ((buffer[n]-OX)/dx)+Width;
      j=(int) ((buffer[n+1]-OY)/dx)+Width;
      k=(int) Nz-Width-((buffer[n+2]-OZ)/dz);

      if(i==Width+1)
      {
        if(j>=0 && j<Ny && k>=0 && k<Nz)
        {
        leftvel[j][k]=buffer[n+3];
        }
      }

      if(i==(Nx*my_size-Width-1))
      {
       if(j>=0 && j<Ny && k>=0 && k<Nz)
       {
         rightvel[j][k]=buffer[n+3];
       }
      }

      if( locate_node(i) == my_rank )
      {
        ii=i%Nx;

        if(ii>=0 && ii<Nx && j>=0 && j<Ny && k>=0 && k<Nz)
        {
          eps[ii][j][k]=buffer[n+3];
        }
      }
    }

   MPI_Barrier(new_comm);

   for(i=0; i<Width; i++)
   {
   for(j=0; j<Ny; j++)
   {
   for(k=0; k<Nz; k++)
   {
     if( locate_node(i) == my_rank )
     {
       ii=i%Nx;
       eps[ii][j][k]=leftvel[j][k];
     }
   }
   }
   }
   for(i=Nx*my_size-Width; i<Nx*my_size; i++)
   {
   for(j=0; j<Ny; j++)
   {
   for(k=0; k<Nz; k++)
   {
     if( locate_node(i) == my_rank )
     {
       ii=i%Nx;
       eps[ii][j][k]=rightvel[j][k];
     }
   }
   }
   }

   free(buffer);
}

void ReadDELFile(char *name)
{
        int i,ii,j,k,n;
	FILE *file;
	double *buffer;
	unsigned long fileLen;
        double leftvel[Ny][Nz],rightvel[Ny][Nz];

//Open file
	file = fopen(name, "rb");
	if (!file)
	{
		fprintf(stderr, "Unable to open file %s", name);
		return;
	}
	
//Get file length
	fseek(file, 0, SEEK_END);
	fileLen=ftell(file);
	fseek(file, 0, SEEK_SET);

//Allocate memory
	buffer=(double *)malloc(fileLen);

	if (!buffer)
	{
		fprintf(stderr, "Memory error!");
                                fclose(file);
		return;
	}

//Read file contents into buffer
	fread(buffer, fileLen, 1, file);
	fclose(file);

    for(n=0; n<fileLen/4-4; n=n+4)
    {

      i=(int) ((buffer[n]-OX)/dx)+Width;
      j=(int) ((buffer[n+1]-OY)/dx)+Width;
      k=(int) Nz-Width-((buffer[n+2]-OZ)/dz);

      if(i==Width+1)
      {
        if(j>=0 && j<Ny && k>=0 && k<Nz)
        {
        leftvel[j][k]=buffer[n+3];
        }
      }

      if(i==(Nx*my_size-Width-1))
      {
       if(j>=0 && j<Ny && k>=0 && k<Nz)
       {
         rightvel[j][k]=buffer[n+3];
       }
      }

      if( locate_node(i) == my_rank )
      {
        ii=i%Nx;

        if(ii>=0 && ii<Nx && j>=0 && j<Ny && k>=0 && k<Nz)
        {
          delta[ii][j][k]=buffer[n+3];
        }
      }
    }

   MPI_Barrier(new_comm);

   for(i=0; i<Width; i++)
   {
   for(j=0; j<Ny; j++)
   {
   for(k=0; k<Nz; k++)
   {
     if( locate_node(i) == my_rank )
     {
       ii=i%Nx;
       delta[ii][j][k]=leftvel[j][k];
     }
   }
   }
   }
   for(i=Nx*my_size-Width; i<Nx*my_size; i++)
   {
   for(j=0; j<Ny; j++)
   {
   for(k=0; k<Nz; k++)
   {
     if( locate_node(i) == my_rank )
     {
       ii=i%Nx;
       delta[ii][j][k]=rightvel[j][k];
     }
   }
   }
   }

   free(buffer);
}


//////////////////////////////////////////////////////////////////////////////////////////////
// reading in theta file
void ReadTHETAFile(char *name)
{
        int i,ii,j,k,n;
	FILE *file;
	double *buffer;
	unsigned long fileLen;
        double leftvel[Ny][Nz],rightvel[Ny][Nz];

//Open file
	file = fopen(name, "rb");
	if (!file)
	{
		fprintf(stderr, "Unable to open file %s", name);
		return;
	}
	
//Get file length
	fseek(file, 0, SEEK_END);
	fileLen=ftell(file);
	fseek(file, 0, SEEK_SET);

//Allocate memory
	buffer=(double *)malloc(fileLen);

	if (!buffer)
	{
		fprintf(stderr, "Memory error!");
                                fclose(file);
		return;
	}

//Read file contents into buffer
	fread(buffer, fileLen, 1, file);
	fclose(file);

    for(n=0; n<fileLen/4-4; n=n+4)
    {

      i=(int) ((buffer[n]-OX)/dx)+Width;
      j=(int) ((buffer[n+1]-OY)/dx)+Width;
      k=(int) Nz-Width-((buffer[n+2]-OZ)/dz);

      if(i==Width+1)
      {
        if(j>=0 && j<Ny && k>=0 && k<Nz)
        {
        leftvel[j][k]=buffer[n+3];
        }
      }

      if(i==(Nx*my_size-Width-1))
      {
       if(j>=0 && j<Ny && k>=0 && k<Nz)
       {
         rightvel[j][k]=buffer[n+3];
       }
      }

      if( locate_node(i) == my_rank )
      {
        ii=i%Nx;

        if(ii>=0 && ii<Nx && j>=0 && j<Ny && k>=0 && k<Nz)
        {
          theta[ii][j][k]=buffer[n+3];
        }
      }
    }

   MPI_Barrier(new_comm);

   for(i=0; i<Width; i++)
   {
   for(j=0; j<Ny; j++)
   {
   for(k=0; k<Nz; k++)
   {
     if( locate_node(i) == my_rank )
     {
       ii=i%Nx;
       theta[ii][j][k]=leftvel[j][k];
     }
   }
   }
   }
   for(i=Nx*my_size-Width; i<Nx*my_size; i++)
   {
   for(j=0; j<Ny; j++)
   {
   for(k=0; k<Nz; k++)
   {
     if( locate_node(i) == my_rank )
     {
       ii=i%Nx;
       theta[ii][j][k]=rightvel[j][k];
     }
   }
   }
   }

   free(buffer);
}

//////////////////////////////////////////////////////////////////////////////////////////////
// reading in theta file
void ReadPHIFile(char *name)
{
        int i,ii,j,k,n;
	FILE *file;
	double *buffer;
	unsigned long fileLen;
        double leftvel[Ny][Nz],rightvel[Ny][Nz];

//Open file
	file = fopen(name, "rb");
	if (!file)
	{
		fprintf(stderr, "Unable to open file %s", name);
		return;
	}
	
//Get file length
	fseek(file, 0, SEEK_END);
	fileLen=ftell(file);
	fseek(file, 0, SEEK_SET);

//Allocate memory
	buffer=(double *)malloc(fileLen);

	if (!buffer)
	{
		fprintf(stderr, "Memory error!");
                                fclose(file);
		return;
	}

//Read file contents into buffer
	fread(buffer, fileLen, 1, file);
	fclose(file);

    for(n=0; n<fileLen/4-4; n=n+4)
    {

      i=(int) ((buffer[n]-OX)/dx)+Width;
      j=(int) ((buffer[n+1]-OY)/dx)+Width;
      k=(int) Nz-Width-((buffer[n+2]-OZ)/dz);

      if(i==Width+1)
      {
        if(j>=0 && j<Ny && k>=0 && k<Nz)
        {
        leftvel[j][k]=buffer[n+3];
        }
      }

      if(i==(Nx*my_size-Width-1))
      {
       if(j>=0 && j<Ny && k>=0 && k<Nz)
       {
         rightvel[j][k]=buffer[n+3];
       }
      }

      if( locate_node(i) == my_rank )
      {
        ii=i%Nx;

        if(ii>=0 && ii<Nx && j>=0 && j<Ny && k>=0 && k<Nz)
        {
          phi[ii][j][k]=buffer[n+3];
        }
      }
    }

   MPI_Barrier(new_comm);

   for(i=0; i<Width; i++)
   {
   for(j=0; j<Ny; j++)
   {
   for(k=0; k<Nz; k++)
   {
     if( locate_node(i) == my_rank )
     {
       ii=i%Nx;
       phi[ii][j][k]=leftvel[j][k];
     }
   }
   }
   }
   for(i=Nx*my_size-Width; i<Nx*my_size; i++)
   {
   for(j=0; j<Ny; j++)
   {
   for(k=0; k<Nz; k++)
   {
     if( locate_node(i) == my_rank )
     {
       ii=i%Nx;
       phi[ii][j][k]=rightvel[j][k];
     }
   }
   }
   }

   free(buffer);
}

/////////////////////////////////////////////////////////////
// building model files
void build6()
{
  int i,j,k,n,ii;
  double aa[4];
  char file_name[50];
  FILE *input;

  Nxx=Nxx1;
  Nyy=Nyy1;
  Nzz=Nzz1;

  Nx=Nx1;
  Ny=Ny1;
  Nz=Nz1;
////////////////////////////////////////////////////////////////////////////////////////////
// allocating memory for material arrays

  velp = alloc3d(Nx,Ny,Nz);
  velp0 = alloc3d(Nx,Ny,Nz);
  dens  = alloc3d(Nx,Ny,Nz);
  delta = alloc3d(Nx,Ny,Nz);
  eps   = alloc3d(Nx,Ny,Nz);
  theta  = alloc3d(Nx,Ny,Nz);
  phi  = alloc3d(Nx,Ny,Nz);

  //Fwd  = alloc3df(Nx,Ny,Nz);
  //Rev  = alloc3df(Nx,Ny,Nz);

////////////////////////////////////////////////////////////////////////////////////////////
// zeroing initial grids - already done with malloc but doing again anyway
 for(i=0; i<Nx; i++)
 {
 for(j=0; j<Ny; j++)
 {
 for(k=0; k<Nz; k++)
 {
   stressR[i][j][k][0]=0.0;
   stressR[i][j][k][1]=0.0;

   uR[i][j][k][0]=0.0;
   uR[i][j][k][1]=0.0;
   uR[i][j][k][2]=0.0;

   R[i][j][k][0]=0.0;
   R[i][j][k][1]=0.0;
   R[i][j][k][2]=0.0;
   R[i][j][k][3]=0.0;
   R[i][j][k][4]=0.0;
   R[i][j][k][5]=0.0;
   R[i][j][k][6]=0.0;
   R[i][j][k][7]=0.0;
   R[i][j][k][8]=0.0;

   velp[i][j][k]=vp;
   dens[i][j][k]=rho;
   delta[i][j][k]=0.0;
   eps[i][j][k]=0.0;
   theta[i][j][k]=0.0;
   phi[i][j][k]=0.0;
 }
 }
 }
 for(i=Nx; i<Nxx; i++)
 {
 for(j=Ny; j<Nyy; j++)
 {
 for(k=Nz; k<Nzz; k++)
 {
   stressR[i][j][k][0]=0.0;
   stressR[i][j][k][1]=0.0;

   uR[i][j][k][0]=0.0;
   uR[i][j][k][1]=0.0;
   uR[i][j][k][2]=0.0;

   R[i][j][k][0]=0.0;
   R[i][j][k][1]=0.0;
   R[i][j][k][2]=0.0;
   R[i][j][k][3]=0.0;
   R[i][j][k][4]=0.0;
   R[i][j][k][5]=0.0;
   R[i][j][k][6]=0.0;
   R[i][j][k][7]=0.0;
   R[i][j][k][8]=0.0;
 }
 }
 }

////////////////////////////////////////////////////////////////////////////////////////////
// Opening and writing in models
/*
 ReadVelFile(input1);
 ReadDenFile(input2);
 ReadEPSFile(input3);
 ReadDELFile(input4);
 ReadTHETAFile(input5);
 ReadPHIFile(input9);
*/
///////////////////////////////////////////////////////////////////////////////////////////////
// Hardwire in models in here if needed

 for(i=0; i<Nx; i++)
 {
 for(j=0; j<Ny; j++)
 {
 for(k=0; k<Nz; k++)
 {
   velp[i][j][k]=vp;
   dens[i][j][k]=rho;
   eps[i][j][k]=0.3;
   delta[i][j][k]=0.2;

   theta[i][j][k]=30.0*(PI/180.0);
   phi[i][j][k]=10.0*(PI/180.0);
 }
 }
 }
///////////////////////////////////////////////////////////////

 for(i=0; i<Nx*my_size; i++)
 {
 for(j=0; j<Ny; j++)
 {
 for(k=0; k<55; k++)
 {
   if(locate_node(i)==my_rank)
   {
    ii=i%Nx;
    velp[ii][j][k]=vp*1.5;
    dens[ii][j][k]=rho*1.5;
   }
 }
 }
 }

 for(i=74; i<94; i++)
 {
 for(j=64; j<84; j++)
 {
 for(k=65; k<80; k++)
 {
   if(locate_node(i)==my_rank)
   {
    ii=i%Nx;
    velp[ii][j][k]=vp*1.2;
    dens[ii][j][k]=rho*1.2;
   }
 }
 }
 }


// smooth model
for(n=0; n<5; n++) 
{
 for(i=0; i<Nx; i++)
 {
 for(j=0; j<Ny; j++)
 {
 for(k=1; k<Nz-1; k++)
 {
    velp[i][j][k]=( velp[i][j][k-1] + velp[i][j][k+1] + velp[i][j][k] )/3.0;
    dens[i][j][k]=( dens[i][j][k-1] + dens[i][j][k+1] + dens[i][j][k] )/3.0;
 }
 }
 }
}

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

 for(i=0; i<Nx; i++)
 {
 for(j=0; j<Ny; j++)
 {
 for(k=Nz-Width; k<Nz; k++)
 {
   velp[i][j][k] = 0.0;
   dens[i][j][k] = 1.0;
   delta[i][j][k]= 0.0;
   eps[i][j][k] = 0.0;
   theta[i][j][k] = 0.0;
   phi[i][j][k] = 0.0;
 }
 }
 }

///////////////////////////////////////////////////////////////////////////////////////////////
// Extending materials into boundary zone
// Y
 for(i=0; i<Nx; i++)
 {
 for(j=0; j<Width; j++)
 {
 for(k=0; k<Nz; k++)
 {
   velp[i][j][k] =  velp[i][Width][k];
   dens[i][j][k] =  dens[i][Width][k];
   delta[i][j][k]= delta[i][Width][k];
   eps[i][j][k] =    eps[i][Width][k];
   theta[i][j][k] =theta[i][Width][k];
   phi[i][j][k] =    phi[i][Width][k];
 }
 }
 }
 for(i=0; i<Nx; i++)
 {
 for(j=Ny-Width; j<Ny; j++)
 {
 for(k=0; k<Nz; k++)
 {
   velp[i][j][k] = velp[i][Ny-Width-1][k];
   dens[i][j][k] = dens[i][Ny-Width-1][k];
   delta[i][j][k]=delta[i][Ny-Width-1][k];
   eps[i][j][k] =   eps[i][Ny-Width-1][k];
   theta[i][j][k]=theta[i][Ny-Width-1][k];
   phi[i][j][k] =   phi[i][Ny-Width-1][k];
 }
 }
 }
// Z
 for(i=0; i<Nx; i++)
 {
 for(j=0; j<Ny; j++)
 {
 for(k=0; k<=Width; k++)
 {
   velp[i][j][k] =   velp[i][j][Width+1];
   dens[i][j][k] =   dens[i][j][Width+1];
   delta[i][j][k]=  delta[i][j][Width+1];
   eps[i][j][k] =     eps[i][j][Width+1];
   theta[i][j][k] = theta[i][j][Width+1];
   phi[i][j][k] =     phi[i][j][Width+1];
 }
 }
 }
 for(i=0; i<Nx; i++)
 {
 for(j=0; j<Ny; j++)
 {
 for(k=Nz-Width; k<Nz; k++)
 {
    velp[i][j][k] = velp[i][j][Nz-Width];
    dens[i][j][k] = dens[i][j][Nz-Width];
   delta[i][j][k]= delta[i][j][Nz-Width];
     eps[i][j][k] =  eps[i][j][Nz-Width];
   theta[i][j][k] =theta[i][j][Nz-Width];
     phi[i][j][k] =  phi[i][j][Nz-Width];
 }
 }
 }

 for(i=0; i<Nx; i++)
 {
 for(j=0; j<Ny; j++)
 {
 for(k=0; k<Nz; k++)
 {
    velp0[i][j][k] = velp[i][j][k];
 }
 }
 }
///////////////////////////////////////////////////////////////////////////////////////////////
// Building R cos and sin models
  for(i=order; i<Nx+order; i++)
  {
  for(j=order; j<Ny+order; j++)
  {
  for(k=order; k<Nz+order; k++)
  {
    // Equation 7 Duveneck et al 
    R[i][j][k][0]=cos(theta[i-order][j-order][k-order])*cos(phi[i-order][j-order][k-order]);
    R[i][j][k][1]=cos(theta[i-order][j-order][k-order])*sin(phi[i-order][j-order][k-order]);
    R[i][j][k][2]=-sin(theta[i-order][j-order][k-order]);

    R[i][j][k][3]=-sin(phi[i-order][j-order][k-order]);
    R[i][j][k][4]= cos(phi[i-order][j-order][k-order]);
    R[i][j][k][5]= 0.0;

    R[i][j][k][6]=sin(theta[i-order][j-order][k-order])*cos(phi[i-order][j-order][k-order]);
    R[i][j][k][7]=sin(theta[i-order][j-order][k-order])*sin(phi[i-order][j-order][k-order]);
    R[i][j][k][8]=cos(theta[i-order][j-order][k-order]);

    // Equation 7 Duveneck et al - rotated for different matrix convention
 /*   R[i][j][k][0]=cos(theta[i-order][j-order][k-order])*cos(phi[i-order][j-order][k-order]);
    R[i][j][k][3]=cos(theta[i-order][j-order][k-order])*sin(phi[i-order][j-order][k-order]);
    R[i][j][k][6]=-sin(theta[i-order][j-order][k-order]);

    R[i][j][k][1]=-sin(phi[i-order][j-order][k-order]);
    R[i][j][k][4]= cos(phi[i-order][j-order][k-order]);
    R[i][j][k][7]= 0.0;

    R[i][j][k][2]=sin(theta[i-order][j-order][k-order])*cos(phi[i-order][j-order][k-order]);
    R[i][j][k][5]=sin(theta[i-order][j-order][k-order])*sin(phi[i-order][j-order][k-order]);
    R[i][j][k][8]=cos(theta[i-order][j-order][k-order]);
*/
  }
  }
  }
  for(i=order; i<Nx+order; i++)
  {
  for(j=0; j<order; j++)
  {
  for(k=order; k<Nz+order; k++)
  {
    // Equation 7 Duveneck et al 
    R[i][j][k][0]=R[i][order][k][0];
    R[i][j][k][1]=R[i][order][k][1];
    R[i][j][k][2]=R[i][order][k][2];

    R[i][j][k][3]=R[i][order][k][3];
    R[i][j][k][4]=R[i][order][k][4];

    R[i][j][k][5]=R[i][order][k][5];
    R[i][j][k][6]=R[i][order][k][6];
    R[i][j][k][7]=R[i][order][k][7];
    R[i][j][k][8]=R[i][order][k][8];
  }
  }
  }
  for(i=order; i<Nx+order; i++)
  {
  for(j=Ny+order; j<Ny+2*order; j++)
  {
  for(k=order; k<Nz+order; k++)
  {
    // Equation 7 Duveneck et al 
    R[i][j][k][0]=R[i][Ny+order-1][k][0];
    R[i][j][k][1]=R[i][Ny+order-1][k][1];
    R[i][j][k][2]=R[i][Ny+order-1][k][2];

    R[i][j][k][3]=R[i][Ny+order-1][k][3];
    R[i][j][k][4]=R[i][Ny+order-1][k][4];

    R[i][j][k][5]=R[i][Ny+order-1][k][5];
    R[i][j][k][6]=R[i][Ny+order-1][k][6];
    R[i][j][k][7]=R[i][Ny+order-1][k][7];
    R[i][j][k][8]=R[i][Ny+order-1][k][8];
  }
  }
  }
  for(i=order; i<Nx+order; i++)
  {
  for(j=order; j<Ny+order; j++)
  {
  for(k=0; k<order; k++)
  {
    // Equation 7 Duveneck et al 
    R[i][j][k][0]=R[i][j][order][0];
    R[i][j][k][1]=R[i][j][order][1];
    R[i][j][k][2]=R[i][j][order][2];

    R[i][j][k][3]=R[i][j][order][3];
    R[i][j][k][4]=R[i][j][order][4];

    R[i][j][k][5]=R[i][j][order][5];
    R[i][j][k][6]=R[i][j][order][6];
    R[i][j][k][7]=R[i][j][order][7];
    R[i][j][k][8]=R[i][j][order][8];
  }
  }
  }
  for(i=order; i<Nx+order; i++)
  {
  for(j=order; j<Ny+order; j++)
  {
  for(k=Nz+order; k<Nz+2*order; k++)
  {
    // Equation 7 Duveneck et al 
    R[i][j][k][0]=R[i][j][Nz+order-1][0];
    R[i][j][k][1]=R[i][j][Nz+order-1][1];
    R[i][j][k][2]=R[i][j][Nz+order-1][2];

    R[i][j][k][3]=R[i][j][Nz+order-1][3];
    R[i][j][k][4]=R[i][j][Nz+order-1][4];

    R[i][j][k][5]=R[i][j][Nz+order-1][5];
    R[i][j][k][6]=R[i][j][Nz+order-1][6];
    R[i][j][k][7]=R[i][j][Nz+order-1][7];
    R[i][j][k][8]=R[i][j][Nz+order-1][8];

  }
  }
  }
// freeing material arrays for TTI as not needed from here
  free_array3d(theta);
  free_array3d(phi);

// sending R matrix for derivative
  transfer_R();

/////////////////////////////////////////////////////////////////////
// Calculating derivatives of rotation matrix
// FD coefficients - central difference
double c11=(4.00/5.0)/dx;
double c22=(-1.0/5.0)/dx;
double c33=(4.00/105.0)/dx;
double c44=(-1.0/280.0)/dx;

// allocating dR/dx arrays
  dr00dx = alloc3d(Nx,Ny,Nz);
  dr11dx = alloc3d(Nx,Ny,Nz);
  dr22dx = alloc3d(Nx,Ny,Nz);
  dr03dx = alloc3d(Nx,Ny,Nz);
  dr14dx = alloc3d(Nx,Ny,Nz);
  dr25dx = alloc3d(Nx,Ny,Nz);
  dr06dx = alloc3d(Nx,Ny,Nz);
  dr17dx = alloc3d(Nx,Ny,Nz);
  dr28dx = alloc3d(Nx,Ny,Nz);

  dr03dy = alloc3d(Nx,Ny,Nz);
  dr14dy = alloc3d(Nx,Ny,Nz);
  dr25dy = alloc3d(Nx,Ny,Nz);
  dr33dy = alloc3d(Nx,Ny,Nz);
  dr44dy = alloc3d(Nx,Ny,Nz);
  dr55dy = alloc3d(Nx,Ny,Nz);
  dr36dy = alloc3d(Nx,Ny,Nz);
  dr47dy = alloc3d(Nx,Ny,Nz);
  dr58dy = alloc3d(Nx,Ny,Nz);

  dr06dz = alloc3d(Nx,Ny,Nz);
  dr17dz = alloc3d(Nx,Ny,Nz);
  dr28dz = alloc3d(Nx,Ny,Nz);
  dr36dz = alloc3d(Nx,Ny,Nz);
  dr47dz = alloc3d(Nx,Ny,Nz);
  dr58dz = alloc3d(Nx,Ny,Nz);
  dr66dz = alloc3d(Nx,Ny,Nz);
  dr77dz = alloc3d(Nx,Ny,Nz);
  dr88dz = alloc3d(Nx,Ny,Nz);

// calculating derivatives
  for(i=order; i<Nx+order; i++)
  {
  for(j=order; j<Ny+order; j++)
  {
  for(k=order; k<Nz+order; k++)
  {
    dr00dx[i-order][j-order][k-order] 
                    = c11*( R[i+1][j][k][0]*R[i+1][j][k][0]-R[i-1][j][k][0]*R[i-1][j][k][0] )
                    + c22*( R[i+2][j][k][0]*R[i+2][j][k][0]-R[i-2][j][k][0]*R[i-2][j][k][0] )
                    + c33*( R[i+3][j][k][0]*R[i+3][j][k][0]-R[i-3][j][k][0]*R[i-3][j][k][0] )
                    + c44*( R[i+4][j][k][0]*R[i+4][j][k][0]-R[i-4][j][k][0]*R[i-4][j][k][0] );

    dr11dx[i-order][j-order][k-order]
                    = c11*( R[i+1][j][k][1]*R[i+1][j][k][1]-R[i-1][j][k][1]*R[i-1][j][k][1] )
                    + c22*( R[i+2][j][k][1]*R[i+2][j][k][1]-R[i-2][j][k][1]*R[i-2][j][k][1] )
                    + c33*( R[i+3][j][k][1]*R[i+3][j][k][1]-R[i-3][j][k][1]*R[i-3][j][k][1] )
                    + c44*( R[i+4][j][k][1]*R[i+4][j][k][1]-R[i-4][j][k][1]*R[i-4][j][k][1] );

    dr22dx[i-order][j-order][k-order]
                    = c11*( R[i+1][j][k][2]*R[i+1][j][k][2]-R[i-1][j][k][2]*R[i-1][j][k][2] )
                    + c22*( R[i+2][j][k][2]*R[i+2][j][k][2]-R[i-2][j][k][2]*R[i-2][j][k][2] )
                    + c33*( R[i+3][j][k][2]*R[i+3][j][k][2]-R[i-3][j][k][2]*R[i-3][j][k][2] )
                    + c44*( R[i+4][j][k][2]*R[i+4][j][k][2]-R[i-4][j][k][2]*R[i-4][j][k][2] );

    dr03dx[i-order][j-order][k-order]
                    = c11*( R[i+1][j][k][0]*R[i+1][j][k][3]-R[i-1][j][k][0]*R[i-1][j][k][3] )
                    + c22*( R[i+2][j][k][0]*R[i+2][j][k][3]-R[i-2][j][k][0]*R[i-2][j][k][3] )
                    + c33*( R[i+3][j][k][0]*R[i+3][j][k][3]-R[i-3][j][k][0]*R[i-3][j][k][3] )
                    + c44*( R[i+4][j][k][0]*R[i+4][j][k][3]-R[i-4][j][k][0]*R[i-4][j][k][3] );

    dr14dx[i-order][j-order][k-order]
                    = c11*( R[i+1][j][k][1]*R[i+1][j][k][4]-R[i-1][j][k][1]*R[i-1][j][k][4] )
                    + c22*( R[i+2][j][k][1]*R[i+2][j][k][4]-R[i-2][j][k][1]*R[i-2][j][k][4] )
                    + c33*( R[i+3][j][k][1]*R[i+3][j][k][4]-R[i-3][j][k][1]*R[i-3][j][k][4] )
                    + c44*( R[i+4][j][k][1]*R[i+4][j][k][4]-R[i-4][j][k][1]*R[i-4][j][k][4] );

    dr25dx[i-order][j-order][k-order]
                    = c11*( R[i+1][j][k][2]*R[i+1][j][k][5]-R[i-1][j][k][2]*R[i-1][j][k][5] )
                    + c22*( R[i+2][j][k][2]*R[i+2][j][k][5]-R[i-2][j][k][2]*R[i-2][j][k][5] )
                    + c33*( R[i+3][j][k][2]*R[i+3][j][k][5]-R[i-3][j][k][2]*R[i-3][j][k][5] )
                    + c44*( R[i+4][j][k][2]*R[i+4][j][k][5]-R[i-4][j][k][2]*R[i-4][j][k][5] );

    dr06dx[i-order][j-order][k-order]
                    = c11*( R[i+1][j][k][0]*R[i+1][j][k][6]-R[i-1][j][k][0]*R[i-1][j][k][6] )
                    + c22*( R[i+2][j][k][0]*R[i+2][j][k][6]-R[i-2][j][k][0]*R[i-2][j][k][6] )
                    + c33*( R[i+3][j][k][0]*R[i+3][j][k][6]-R[i-3][j][k][0]*R[i-3][j][k][6] )
                    + c44*( R[i+4][j][k][0]*R[i+4][j][k][6]-R[i-4][j][k][0]*R[i-4][j][k][6] );

    dr17dx[i-order][j-order][k-order]
                    = c11*( R[i+1][j][k][1]*R[i+1][j][k][7]-R[i-1][j][k][1]*R[i-1][j][k][7] )
                    + c22*( R[i+2][j][k][1]*R[i+2][j][k][7]-R[i-2][j][k][1]*R[i-2][j][k][7] )
                    + c33*( R[i+3][j][k][1]*R[i+3][j][k][7]-R[i-3][j][k][1]*R[i-3][j][k][7] )
                    + c44*( R[i+4][j][k][1]*R[i+4][j][k][7]-R[i-4][j][k][1]*R[i-4][j][k][7] );

    dr28dx[i-order][j-order][k-order]
                    = c11*( R[i+1][j][k][2]*R[i+1][j][k][8]-R[i-1][j][k][2]*R[i-1][j][k][8] )
                    + c22*( R[i+2][j][k][2]*R[i+2][j][k][8]-R[i-2][j][k][2]*R[i-2][j][k][8] )
                    + c33*( R[i+3][j][k][2]*R[i+3][j][k][8]-R[i-3][j][k][2]*R[i-3][j][k][8] )
                    + c44*( R[i+4][j][k][2]*R[i+4][j][k][8]-R[i-4][j][k][2]*R[i-4][j][k][8] );

/////////////////////////////////////////////////////////////////////////////////////////////

    dr03dy[i-order][j-order][k-order] 
                    = c11*( R[i][j+1][k][0]*R[i][j+1][k][3]-R[i][j-1][k][0]*R[i][j-1][k][3] )
                    + c22*( R[i][j+2][k][0]*R[i][j+2][k][3]-R[i][j-2][k][0]*R[i][j-2][k][3] )
                    + c33*( R[i][j+3][k][0]*R[i][j+3][k][3]-R[i][j-3][k][0]*R[i][j-3][k][3] )
                    + c44*( R[i][j+4][k][0]*R[i][j+4][k][3]-R[i][j-4][k][0]*R[i][j-4][k][3] );

    dr14dy[i-order][j-order][k-order] 
                    = c11*( R[i][j+1][k][1]*R[i][j+1][k][4]-R[i][j-1][k][1]*R[i][j-1][k][4] )
                    + c22*( R[i][j+2][k][1]*R[i][j+2][k][4]-R[i][j-2][k][1]*R[i][j-2][k][4] )
                    + c33*( R[i][j+3][k][1]*R[i][j+3][k][4]-R[i][j-3][k][1]*R[i][j-3][k][4] )
                    + c44*( R[i][j+4][k][1]*R[i][j+4][k][4]-R[i][j-4][k][1]*R[i][j-4][k][4] );

    dr25dy[i-order][j-order][k-order] 
                    = c11*( R[i][j+1][k][2]*R[i][j+1][k][5]-R[i][j-1][k][2]*R[i][j-1][k][5] )
                    + c22*( R[i][j+2][k][2]*R[i][j+2][k][5]-R[i][j-2][k][2]*R[i][j-2][k][5] )
                    + c33*( R[i][j+3][k][2]*R[i][j+3][k][5]-R[i][j-3][k][2]*R[i][j-3][k][5] )
                    + c44*( R[i][j+4][k][2]*R[i][j+4][k][5]-R[i][j-4][k][2]*R[i][j-4][k][5] );

    dr33dy[i-order][j-order][k-order] 
                    = c11*( R[i][j+1][k][3]*R[i][j+1][k][3]-R[i][j-1][k][3]*R[i][j-1][k][3] )
                    + c22*( R[i][j+2][k][3]*R[i][j+2][k][3]-R[i][j-2][k][3]*R[i][j-2][k][3] )
                    + c33*( R[i][j+3][k][3]*R[i][j+3][k][3]-R[i][j-3][k][3]*R[i][j-3][k][3] )
                    + c44*( R[i][j+4][k][3]*R[i][j+4][k][3]-R[i][j-4][k][3]*R[i][j-4][k][3] );

    dr44dy[i-order][j-order][k-order] 
                    = c11*( R[i][j+1][k][4]*R[i][j+1][k][4]-R[i][j-1][k][4]*R[i][j-1][k][4] )
                    + c22*( R[i][j+2][k][4]*R[i][j+2][k][4]-R[i][j-2][k][4]*R[i][j-2][k][4] )
                    + c33*( R[i][j+3][k][4]*R[i][j+3][k][4]-R[i][j-3][k][4]*R[i][j-3][k][4] )
                    + c44*( R[i][j+4][k][4]*R[i][j+4][k][4]-R[i][j-4][k][4]*R[i][j-4][k][4] );

    dr55dy[i-order][j-order][k-order] 
                    = c11*( R[i][j+1][k][5]*R[i][j+1][k][5]-R[i][j-1][k][5]*R[i][j-1][k][5] )
                    + c22*( R[i][j+2][k][5]*R[i][j+2][k][5]-R[i][j-2][k][5]*R[i][j-2][k][5] )
                    + c33*( R[i][j+3][k][5]*R[i][j+3][k][5]-R[i][j-3][k][5]*R[i][j-3][k][5] )
                    + c44*( R[i][j+4][k][5]*R[i][j+4][k][5]-R[i][j-4][k][5]*R[i][j-4][k][5] );

    dr36dy[i-order][j-order][k-order] 
                    = c11*( R[i][j+1][k][3]*R[i][j+1][k][6]-R[i][j-1][k][3]*R[i][j-1][k][6] )
                    + c22*( R[i][j+2][k][3]*R[i][j+2][k][6]-R[i][j-2][k][3]*R[i][j-2][k][6] )
                    + c33*( R[i][j+3][k][3]*R[i][j+3][k][6]-R[i][j-3][k][3]*R[i][j-3][k][6] )
                    + c44*( R[i][j+4][k][3]*R[i][j+4][k][6]-R[i][j-4][k][3]*R[i][j-4][k][6] );

    dr47dy[i-order][j-order][k-order] 
                    = c11*( R[i][j+1][k][4]*R[i][j+1][k][7]-R[i][j-1][k][4]*R[i][j-1][k][7] )
                    + c22*( R[i][j+2][k][4]*R[i][j+2][k][7]-R[i][j-2][k][4]*R[i][j-2][k][7] )
                    + c33*( R[i][j+3][k][4]*R[i][j+3][k][7]-R[i][j-3][k][4]*R[i][j-3][k][7] )
                    + c44*( R[i][j+4][k][4]*R[i][j+4][k][7]-R[i][j-4][k][4]*R[i][j-4][k][7] );

    dr58dy[i-order][j-order][k-order] 
                    = c11*( R[i][j+1][k][5]*R[i][j+1][k][8]-R[i][j-1][k][5]*R[i][j-1][k][8] )
                    + c22*( R[i][j+2][k][5]*R[i][j+2][k][8]-R[i][j-2][k][5]*R[i][j-2][k][8] )
                    + c33*( R[i][j+3][k][5]*R[i][j+3][k][8]-R[i][j-3][k][5]*R[i][j-3][k][8] )
                    + c44*( R[i][j+4][k][5]*R[i][j+4][k][8]-R[i][j-4][k][5]*R[i][j-4][k][8] );

/////////////////////////////////////////////////////////////////////////////////////////////

    dr06dz[i-order][j-order][k-order]
                    = (dx/dz)*c11*( R[i][j][k+1][0]*R[i][j][k+1][6]-R[i][j][k-1][0]*R[i][j][k-1][6] )
                    + (dx/dz)*c22*( R[i][j][k+2][0]*R[i][j][k+2][6]-R[i][j][k-2][0]*R[i][j][k-2][6] )
                    + (dx/dz)*c33*( R[i][j][k+3][0]*R[i][j][k+3][6]-R[i][j][k-3][0]*R[i][j][k-3][6] )
                    + (dx/dz)*c44*( R[i][j][k+4][0]*R[i][j][k+4][6]-R[i][j][k-4][0]*R[i][j][k-4][6] );

    dr17dz[i-order][j-order][k-order]
                    = (dx/dz)*c11*( R[i][j][k+1][1]*R[i][j][k+1][7]-R[i][j][k-1][1]*R[i][j][k-1][7] )
                    + (dx/dz)*c22*( R[i][j][k+2][1]*R[i][j][k+2][7]-R[i][j][k-2][1]*R[i][j][k-2][7] )
                    + (dx/dz)*c33*( R[i][j][k+3][1]*R[i][j][k+3][7]-R[i][j][k-3][1]*R[i][j][k-3][7] )
                    + (dx/dz)*c44*( R[i][j][k+4][1]*R[i][j][k+4][7]-R[i][j][k-4][1]*R[i][j][k-4][7] );

    dr28dz[i-order][j-order][k-order]
                    = (dx/dz)*c11*( R[i][j][k+1][2]*R[i][j][k+1][8]-R[i][j][k-1][2]*R[i][j][k-1][8] )
                    + (dx/dz)*c22*( R[i][j][k+2][2]*R[i][j][k+2][8]-R[i][j][k-2][2]*R[i][j][k-2][8] )
                    + (dx/dz)*c33*( R[i][j][k+3][2]*R[i][j][k+3][8]-R[i][j][k-3][2]*R[i][j][k-3][8] )
                    + (dx/dz)*c44*( R[i][j][k+4][2]*R[i][j][k+4][8]-R[i][j][k-4][2]*R[i][j][k-4][8] );

    dr36dz[i-order][j-order][k-order]
                    = (dx/dz)*c11*( R[i][j][k+1][3]*R[i][j][k+1][6]-R[i][j][k-1][3]*R[i][j][k-1][6] )
                    + (dx/dz)*c22*( R[i][j][k+2][3]*R[i][j][k+2][6]-R[i][j][k-2][3]*R[i][j][k-2][6] )
                    + (dx/dz)*c33*( R[i][j][k+3][3]*R[i][j][k+3][6]-R[i][j][k-3][3]*R[i][j][k-3][6] )
                    + (dx/dz)*c44*( R[i][j][k+4][3]*R[i][j][k+4][6]-R[i][j][k-4][3]*R[i][j][k-4][6] );

    dr47dz[i-order][j-order][k-order]
                    = (dx/dz)*c11*( R[i][j][k+1][4]*R[i][j][k+1][7]-R[i][j][k-1][4]*R[i][j][k-1][7] )
                    + (dx/dz)*c22*( R[i][j][k+2][4]*R[i][j][k+2][7]-R[i][j][k-2][4]*R[i][j][k-2][7] )
                    + (dx/dz)*c33*( R[i][j][k+3][4]*R[i][j][k+3][7]-R[i][j][k-3][4]*R[i][j][k-3][7] )
                    + (dx/dz)*c44*( R[i][j][k+4][4]*R[i][j][k+4][7]-R[i][j][k-4][4]*R[i][j][k-4][7] );

    dr58dz[i-order][j-order][k-order]
                    = (dx/dz)*c11*( R[i][j][k+1][5]*R[i][j][k+1][8]-R[i][j][k-1][5]*R[i][j][k-1][8] )
                    + (dx/dz)*c22*( R[i][j][k+2][5]*R[i][j][k+2][8]-R[i][j][k-2][5]*R[i][j][k-2][8] )
                    + (dx/dz)*c33*( R[i][j][k+3][5]*R[i][j][k+3][8]-R[i][j][k-3][5]*R[i][j][k-3][8] )
                    + (dx/dz)*c44*( R[i][j][k+4][5]*R[i][j][k+4][8]-R[i][j][k-4][5]*R[i][j][k-4][8] );

    dr66dz[i-order][j-order][k-order]
                    = (dx/dz)*c11*( R[i][j][k+1][6]*R[i][j][k+1][6]-R[i][j][k-1][6]*R[i][j][k-1][6] )
                    + (dx/dz)*c22*( R[i][j][k+2][6]*R[i][j][k+2][6]-R[i][j][k-2][6]*R[i][j][k-2][6] )
                    + (dx/dz)*c33*( R[i][j][k+3][6]*R[i][j][k+3][6]-R[i][j][k-3][6]*R[i][j][k-3][6] )
                    + (dx/dz)*c44*( R[i][j][k+4][6]*R[i][j][k+4][6]-R[i][j][k-4][6]*R[i][j][k-4][6] );

    dr77dz[i-order][j-order][k-order]
                    = (dx/dz)*c11*( R[i][j][k+1][7]*R[i][j][k+1][7]-R[i][j][k-1][7]*R[i][j][k-1][7] )
                    + (dx/dz)*c22*( R[i][j][k+2][7]*R[i][j][k+2][7]-R[i][j][k-2][7]*R[i][j][k-2][7] )
                    + (dx/dz)*c33*( R[i][j][k+3][7]*R[i][j][k+3][7]-R[i][j][k-3][7]*R[i][j][k-3][7] )
                    + (dx/dz)*c44*( R[i][j][k+4][7]*R[i][j][k+4][7]-R[i][j][k-4][7]*R[i][j][k-4][7] );

    dr88dz[i-order][j-order][k-order]
                    = (dx/dz)*c11*( R[i][j][k+1][8]*R[i][j][k+1][8]-R[i][j][k-1][8]*R[i][j][k-1][8] )
                    + (dx/dz)*c22*( R[i][j][k+2][8]*R[i][j][k+2][8]-R[i][j][k-2][8]*R[i][j][k-2][8] )
                    + (dx/dz)*c33*( R[i][j][k+3][8]*R[i][j][k+3][8]-R[i][j][k-3][8]*R[i][j][k-3][8] )
                    + (dx/dz)*c44*( R[i][j][k+4][8]*R[i][j][k+4][8]-R[i][j][k-4][8]*R[i][j][k-4][8] );
  }
  }
  }


/////////////////////////////////////////////////////////////////////////////////////////////

no_snap=(int)ceil(Duration/no_snaps);
count_snaps=0;

/////////////////////////////////////////////////////////////////
// Counting for low resolution output
  lr_count=lr_countx=lr_county=lr_countz=0;

  for(j=0; j<Nx; j=j+LR)
  {
    lr_countx++;
    lr_countz=0;
  for(k=0; k<Nz; k=k+LR)
  {
     lr_countz++;
     lr_county=0;
  for(i=0; i<Ny; i=i+LR)
  {
     lr_count++;
     lr_county++;
  }
  }
  }

/////////////////////////////////////////////////////////////////////


}    // End routine

