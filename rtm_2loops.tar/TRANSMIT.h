/////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Transfer and domain functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
// define specific data types for transfer across domains

void create_mpi_data_type()
{

 int count = 1;
 int blocklen = Nyy1*Nzz1*2*order;
 int stride = 0;

 MPI_Type_vector(count, blocklen, stride, MPI_DOUBLE, &Xcol2);
 MPI_Type_commit(&Xcol2);

 count = 1;
 blocklen = Nyy1*Nzz1*3*order;
 stride = 0;

 MPI_Type_vector(count, blocklen, stride, MPI_DOUBLE, &Xcol1);
 MPI_Type_commit(&Xcol1);

 count = 1;
 blocklen = Nyy1*Nzz1*9*order;
 stride = 0;

 MPI_Type_vector(count, blocklen, stride, MPI_DOUBLE, &Xcol3);
 MPI_Type_commit(&Xcol3);

}

// transfer vel in halo regions
void transfer_velR()
{
 // MPI_Status status;
 MPI_Request array_of_requestsf[max_nb_of_comm];
 MPI_Status  array_of_statusesf[max_nb_of_comm];
 int index_of_comm = 0;

 if(my_rank==0)
 {
      MPI_Isend(&uR[order][0][0][0],1,Xcol1,my_size-1,51,new_comm, &array_of_requestsf[index_of_comm++]);
   MPI_Irecv(&uR[Nx+order][0][0][0],1,Xcol1,my_rank+1,51,new_comm, &array_of_requestsf[index_of_comm++]);

          MPI_Irecv(&uR[0][0][0][0],1,Xcol1,my_size-1,51,new_comm, &array_of_requestsf[index_of_comm++]);
         MPI_Isend(&uR[Nx][0][0][0],1,Xcol1,my_rank+1,51,new_comm, &array_of_requestsf[index_of_comm++]);
 }
 else if( my_rank>0 && my_rank< (my_size-1) )
 {
      MPI_Isend(&uR[order][0][0][0],1,Xcol1,my_rank-1,51,new_comm, &array_of_requestsf[index_of_comm++]);
   MPI_Irecv(&uR[Nx+order][0][0][0],1,Xcol1,my_rank+1,51,new_comm, &array_of_requestsf[index_of_comm++]);

          MPI_Irecv(&uR[0][0][0][0],1,Xcol1,my_rank-1,51,new_comm, &array_of_requestsf[index_of_comm++]);
         MPI_Isend(&uR[Nx][0][0][0],1,Xcol1,my_rank+1,51,new_comm,  &array_of_requestsf[index_of_comm++]);
 }
 else if( my_rank == (my_size-1) )
 {
   MPI_Irecv(&uR[Nx+order][0][0][0],1,Xcol1,0,51,new_comm,  &array_of_requestsf[index_of_comm++]);
      MPI_Isend(&uR[order][0][0][0],1,Xcol1,my_rank-1,51,new_comm,  &array_of_requestsf[index_of_comm++]);

         MPI_Isend(&uR[Nx][0][0][0],1,Xcol1,0,51,new_comm,  &array_of_requestsf[index_of_comm++]);
          MPI_Irecv(&uR[0][0][0][0],1,Xcol1,my_rank-1,51,new_comm, &array_of_requestsf[index_of_comm++]);
 }

 MPI_Waitall(index_of_comm, array_of_requestsf, array_of_statusesf);

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

// transfer stress in halo regions
void transfer_stressR()
{
 //MPI_Status status;
 MPI_Request array_of_requestsf[max_nb_of_comm];
 MPI_Status  array_of_statusesf[max_nb_of_comm];
 int index_of_comm = 0;

 if(my_rank==0)
 {
      MPI_Isend(&stressR[order][0][0][0],1,Xcol2,my_size-1,53,new_comm, &array_of_requestsf[index_of_comm++]);
   MPI_Irecv(&stressR[Nx+order][0][0][0],1,Xcol2,my_rank+1,53,new_comm, &array_of_requestsf[index_of_comm++]);

          MPI_Irecv(&stressR[0][0][0][0],1,Xcol2,my_size-1,53,new_comm, &array_of_requestsf[index_of_comm++] );
         MPI_Isend(&stressR[Nx][0][0][0],1,Xcol2,my_rank+1,53,new_comm, &array_of_requestsf[index_of_comm++]);
 }
 else if( my_rank>0 && my_rank< (my_size-1) )
 {
      MPI_Isend(&stressR[order][0][0][0],1,Xcol2,my_rank-1,53,new_comm, &array_of_requestsf[index_of_comm++]);
   MPI_Irecv(&stressR[Nx+order][0][0][0],1,Xcol2,my_rank+1,53,new_comm, &array_of_requestsf[index_of_comm++]);

          MPI_Irecv(&stressR[0][0][0][0],1,Xcol2,my_rank-1,53,new_comm, &array_of_requestsf[index_of_comm++]);
         MPI_Isend(&stressR[Nx][0][0][0],1,Xcol2,my_rank+1,53,new_comm,  &array_of_requestsf[index_of_comm++]);
 }
 else if( my_rank == (my_size-1) )
 {
   MPI_Irecv(&stressR[Nx+order][0][0][0],1,Xcol2,0,53,new_comm,  &array_of_requestsf[index_of_comm++]);
      MPI_Isend(&stressR[order][0][0][0],1,Xcol2,my_rank-1,53,new_comm,  &array_of_requestsf[index_of_comm++]);

         MPI_Isend(&stressR[Nx][0][0][0],1,Xcol2,0,53,new_comm,  &array_of_requestsf[index_of_comm++]);
          MPI_Irecv(&stressR[0][0][0][0],1,Xcol2,my_rank-1,53,new_comm, &array_of_requestsf[index_of_comm++]);
 }

 MPI_Waitall(index_of_comm, array_of_requestsf, array_of_statusesf);

}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////
// transfer R in halo regions (used only once)
void transfer_R()
{
 //MPI_Status status;
 MPI_Request array_of_requestsf[max_nb_of_comm];
 MPI_Status  array_of_statusesf[max_nb_of_comm];
 int index_of_comm = 0;

 if(my_rank==0)
 {
      MPI_Isend(&R[order][0][0][0],1,Xcol3,my_size-1,58,new_comm, &array_of_requestsf[index_of_comm++]);
   MPI_Irecv(&R[Nx+order][0][0][0],1,Xcol3,my_rank+1,58,new_comm, &array_of_requestsf[index_of_comm++]);

          MPI_Irecv(&R[0][0][0][0],1,Xcol3,my_size-1,58,new_comm, &array_of_requestsf[index_of_comm++] );
         MPI_Isend(&R[Nx][0][0][0],1,Xcol3,my_rank+1,58,new_comm, &array_of_requestsf[index_of_comm++]);
 }
 else if( my_rank>0 && my_rank< (my_size-1) )
 {
      MPI_Isend(&R[order][0][0][0],1,Xcol3,my_rank-1,58,new_comm, &array_of_requestsf[index_of_comm++]);
   MPI_Irecv(&R[Nx+order][0][0][0],1,Xcol3,my_rank+1,58,new_comm, &array_of_requestsf[index_of_comm++]);

          MPI_Irecv(&R[0][0][0][0],1,Xcol3,my_rank-1,58,new_comm, &array_of_requestsf[index_of_comm++]);
         MPI_Isend(&R[Nx][0][0][0],1,Xcol3,my_rank+1,58,new_comm,  &array_of_requestsf[index_of_comm++]);
 }
 else if( my_rank == (my_size-1) )
 {
   MPI_Irecv(&R[Nx+order][0][0][0],1,Xcol3,0,58,new_comm,  &array_of_requestsf[index_of_comm++]);
      MPI_Isend(&R[order][0][0][0],1,Xcol3,my_rank-1,58,new_comm,  &array_of_requestsf[index_of_comm++]);

         MPI_Isend(&R[Nx][0][0][0],1,Xcol3,0,58,new_comm,  &array_of_requestsf[index_of_comm++]);
          MPI_Irecv(&R[0][0][0][0],1,Xcol3,my_rank-1,58,new_comm, &array_of_requestsf[index_of_comm++]);
 }

 MPI_Waitall(index_of_comm, array_of_requestsf, array_of_statusesf);

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

